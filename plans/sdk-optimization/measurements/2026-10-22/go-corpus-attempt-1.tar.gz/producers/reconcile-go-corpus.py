"""Reconcile local Go results with the exact effective input contracts used by CI."""
import gzip,hashlib,json,subprocess,sys,time
from pathlib import Path

root=Path('/home/jinyongp/workspace/jinyongp/openapi-sdkgen')
base=root/'.tmp/sdk-optimization-execution';helpers=root/'.tmp/sdk-optimization-execution-helpers'
original=base/'go-corpus-candidate';output=base/'go-corpus-candidate-verified'
output.mkdir(mode=0o700,exist_ok=True)
assert not (output/'spoonacular.json').exists() and not (output/'summary.json').exists(),'completed outputs must never be overwritten'
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
groups=[('holdout-manifest.json','holdout-manifest.json.gz','.tmp/compatibility-holdout'),('regression.json','regression-manifest.json.gz','.tmp/compatibility-regression'),('production32.json','production32-manifest.json.gz','.tmp/compatibility-corpora/production32'),('modern.json','modern-manifest.json.gz','.tmp/compatibility-corpora/modern')]
old_rows=json.loads(gzip.decompress((root/'test/compatibility/ci/golang-results.json.gz').read_bytes()))['documents']
expected={row['id']:row for row in old_rows};entries={};manifests={};differences=[]
for raw_name,ci_name,directory in groups:
    raw=json.loads((root/'test/compatibility'/raw_name).read_text())
    data=gzip.decompress((root/'test/compatibility/ci'/ci_name).read_bytes())
    ci=json.loads(data);current={item['id']:item for item in ci['corpora']}
    manifest=output/raw_name;manifest.write_bytes(data)
    for item in raw['corpora']:
        other=current[item['id']]
        assert {k:v for k,v in item.items() if k!='preparation'}=={k:v for k,v in other.items() if k!='preparation'}
        if item['id']=='microsoft-graph-beta':continue
        entry=expected[item['id']];prep=other.get('preparation');proof=entry.get('inputPreparation')
        assert sha(root/directory/item['input'])==entry['inputSha256']
        if prep:
            assert proof and all(proof[k]==prep[k] for k in ['kind','sha256','operations'])
            assert proof['sourceSha256']==entry['inputSha256'] and proof['contractsVerified'] is True
        else:assert proof is None
        if item.get('preparation')!=prep:differences.append(item['id'])
        entries[item['id']]=other;manifests[item['id']]=(manifest,root/directory)
assert set(entries)==set(expected) and len(entries)==38
assert differences==['spoonacular.com'],differences
(output/'preparation-audit.json').write_text(json.dumps({'scope':'exact CI effective-input metadata; raw source pin alone is insufficient','rawManifestDifferences':differences,'manifests':{p.name:sha(p) for p in output.glob('*.json') if p.name!='preparation-audit.json'}},indent=2)+'\n')

deadline=time.monotonic()+43200
while True:
    path=original/'summary.json'
    if path.exists():
        previous=json.loads(path.read_text())
        if previous['completedDocuments']==38:break
    if time.monotonic()>deadline:raise SystemExit('original corpus incomplete; no retry started')
    time.sleep(5)
assert (base/'go-corpus-candidate-37/result.json').exists()
manifest,directory=manifests['spoonacular.com'];retry=output/'spoonacular.json'
code=subprocess.call([sys.executable,'-B',str(helpers/'run-trial.py'),str(base/'go-corpus-spoonacular-ci-prepared'),'4500','12288',str(original/'golang-compat'),'--mode','golang-generation','--verify','--server','--manifest',str(manifest),'--corpus-root',str(directory),'--document','spoonacular.com','--output',str(retry)],cwd=root)

prefixes=('cmd/','internal/','scripts/golang-compat/')
tracked=subprocess.check_output(['git','ls-files','cmd','internal','scripts/golang-compat','go.mod','go.sum'],cwd=root,text=True).splitlines()
current_hash={name:sha(root/name) for name in tracked}
policy={'timeoutSeconds':3600,'buildParallelism':1,'cpuConcurrency':4,'memoryLimit':'6GiB'}
http_tests={'loket.nl':'TestLoketHTTPContract','stripe':'TestStripeHTTPContract','cloudflare':'TestCloudflareHTTPContract','digitalocean':'TestDigitalOceanHTTPContract','spoonacular.com':'TestSpoonacularHTTPContract'}
rows=[];problems=[]
for index,row in enumerate(previous['results']):
    identity=row['id'];report=retry if identity=='spoonacular.com' else Path(row['report'])
    trial=base/('go-corpus-spoonacular-ci-prepared' if identity=='spoonacular.com' else f'go-corpus-candidate-{index:02d}')
    errors=[]
    try:
        record=json.loads((trial/'result.json').read_text());basis=json.loads((trial/'source.json').read_text())
        assert record['status']=='pass','recorder did not pass'
        assert sha(trial/'source.json')==record['sourceManifestSha256']
        observed={k:v for k,v in basis.items() if k.startswith(prefixes) or k in ['go.mod','go.sum']}
        assert observed==current_hash,'relevant source changed; rerun affected corpus'
        value=json.loads(report.read_text());entry=expected[identity];prep=entries[identity].get('preparation');proof=value.get('inputPreparation')
        assert value['id']==identity and value['input']==entry['input'] and value['inputSha256']==entry['inputSha256']
        assert value['sourceCommit']==record['head'] and value['mode']=='golang-generation' and value['addons']==['server']
        assert value['goVersion']=='go1.27.2' and record['goVersion'].startswith('go version go1.27.2 ')
        assert value['goCompilationPolicy']==policy and value['verificationRequested'] is True and not value.get('selection')
        assert value['pass'] is True and value['golang']['blocked'] is False and value['golang']['compilation']['status']=='pass'
        if prep:
            assert proof and all(proof[k]==prep[k] for k in ['kind','sha256','operations'])
            assert proof['sourceSha256']==entry['inputSha256'] and proof['contractsVerified'] is True,'prepared contract mismatch'
        else:assert proof is None,'unexpected preparation'
        test=http_tests.get(identity)
        if test:assert value['golang']['compilation'].get('contractTests')==[test],'required provider HTTP proof missing'
        assert sha(original/'golang-compat')==record['binaries'][str(original/'golang-compat')],'auditor changed'
    except (AssertionError,KeyError,OSError,ValueError) as error:
        errors.append(str(error) or type(error).__name__)
    rows.append({'id':identity,'pass':not errors,'report':str(report),'trial':str(trial),'errors':errors,'reusedUnchangedInputResult':identity!='spoonacular.com'})
    if errors:problems.append(identity)
summary={'status':'pass' if not problems and len(rows)==38 else 'fail','scope':'local native Go generation/server/full compile; exact raw pins AND CI preparation contracts; Graph separate; not public CI or performance evidence','expectedDocuments':38,'completedDocuments':len(rows),'passedDocuments':sum(row['pass'] for row in rows),'retainedInvalidPreparationResult':str(original/'13.json'),'preparationReplacement':'spoonacular.com','relevantSourceFiles':len(current_hash),'relevantSourceManifestSha256':hashlib.sha256(json.dumps(current_hash,sort_keys=True).encode()).hexdigest(),'results':rows}
(output/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:summary[k] for k in ['status','completedDocuments','passedDocuments']}),flush=True)
if problems:raise SystemExit('failed exact-input corpus validation: '+', '.join(problems))
