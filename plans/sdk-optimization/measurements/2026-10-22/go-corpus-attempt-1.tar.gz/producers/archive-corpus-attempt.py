"""Archive the complete 38-document attempt, including failures and input reconciliation."""
import hashlib, io, json, tarfile
from pathlib import Path

root = Path('/home/jinyongp/workspace/jinyongp/openapi-sdkgen')
base = root / '.tmp/sdk-optimization-execution'
helpers = root / '.tmp/sdk-optimization-execution-helpers'
destination = root / 'plans/sdk-optimization/measurements/2026-10-22/go-corpus-attempt-1.tar.gz'
assert not destination.exists()
sha = lambda path: hashlib.file_digest(path.open('rb'), 'sha256').hexdigest()
original = json.loads((base / 'go-corpus-candidate/summary.json').read_text())
verified = json.loads((base / 'go-corpus-candidate-verified/summary.json').read_text())
assert original['completedDocuments'] == verified['completedDocuments'] == 38
assert original['passedDocuments'] == 36 and verified['passedDocuments'] == 37
assert [row['id'] for row in verified['results'] if not row['pass']] == ['cloudflare']
files = {}; outcomes = {}
names = ['go-corpus-candidate-build-auditor'] + [f'go-corpus-candidate-{i:02d}' for i in range(38)] + ['go-corpus-spoonacular-ci-prepared']
for name in names:
    trial = base / name
    result = json.loads((trial / 'result.json').read_text())
    assert sha(trial / 'source.json') == result['sourceManifestSha256']
    outcomes[name] = {key: result[key] for key in ['status', 'elapsedSeconds', 'peakSessionRSSBytes', 'rssLimitMiB']}
    for path in trial.iterdir():
        assert path.is_file() and not path.is_symlink()
        files['trials/' + name + '/' + path.name] = path
for name in ['go-corpus-candidate', 'go-corpus-candidate-verified']:
    for path in (base / name).iterdir():
        assert path.is_file() and not path.is_symlink()
        if path.name != 'golang-compat':
            files['reports/' + name + '/' + path.name] = path
retained = base / 'go-corpus-cloudflare-rss-input'
for name in ['summary.json', 'files.jsonl']:
    files['cloudflare-input/' + name] = retained / name
for name in ['go.mod', 'cloudflare_http_test.go']:
    files['cloudflare-input/' + name] = retained / 'module' / name
for name in ['run-corpus-candidate.py', 'verify-corpus-inputs.py', 'reconcile-go-corpus.py',
             'retain-cloudflare-rss-input.py', 'run-trial.py', Path(__file__).name]:
    files['producers/' + name] = helpers / name
for name in ['holdout-manifest.json', 'regression.json', 'production32.json', 'modern.json']:
    files['catalog/' + name] = root / 'test/compatibility' / name
for name in ['holdout-manifest.json.gz', 'regression-manifest.json.gz', 'production32-manifest.json.gz', 'modern-manifest.json.gz', 'golang-results.json.gz']:
    files['existing-ci/' + name] = root / 'test/compatibility/ci' / name
files['producers/input-corrections.go'] = root / 'internal/compatinput/corrections.go'
index = {'scope': 'completed local Go native/server/full-compile attempt; exact CI input reconciliation 37/38; not final W09 or Graph success',
         'files': {name: {'bytes': path.stat().st_size, 'sha256': sha(path)} for name, path in sorted(files.items())},
         'outcomes': outcomes,
         'originalPassedDocuments': 36, 'exactInputPassedDocuments': 37,
         'remaining': ['cloudflare whole compile and HTTP contract after RSS protection', 'separate Graph and final repeat/integration checks'],
         'excluded': [{'path': str(retained / 'module/api'), 'reason': '976456445-byte mechanical output retained locally; complete per-file inventory and recomputed artifact hash included'},
                      {'path': str(base / 'go-corpus-candidate/golang-compat'), 'reason': 'auditor executable retained locally; build source/result/binary SHA included'},
                      {'reason': 'pinned external input documents remain at catalog locations; raw SHA/Git blob and exact CI preparations are included'},
                      {'reason': 'active TS Graph trials, private task contexts and unrelated data were never selected'}]}
with tarfile.open(destination, 'w:gz', compresslevel=6) as archive:
    for name, path in sorted(files.items()):
        archive.add(path, arcname=name, recursive=False)
    data = (json.dumps(index, indent=2) + '\n').encode()
    info = tarfile.TarInfo('index.json'); info.size = len(data); info.mode = 0o600
    archive.addfile(info, io.BytesIO(data))
with tarfile.open(destination, 'r:gz') as archive:
    assert json.load(archive.extractfile('index.json')) == index
    for name, entry in index['files'].items():
        data = archive.extractfile(name).read()
        assert len(data) == entry['bytes'] and hashlib.sha256(data).hexdigest() == entry['sha256']
print(json.dumps({'archive': str(destination), 'bytes': destination.stat().st_size,
                  'sha256': sha(destination), 'files': len(files) + 1, 'trials': len(names), 'verified': True}))
