import gzip,json,os,subprocess,sys,time
from pathlib import Path
root=Path('/home/jinyongp/workspace/jinyongp/openapi-sdkgen')
base=root/'.tmp/sdk-optimization-execution'
helper=root/'.tmp/sdk-optimization-execution-helpers'
assert (root/'.tmp/sdk-optimization-private/claims/W09.json').is_file(),'claim W09 first'
subprocess.run([sys.executable,'-B',str(helper/'verify-corpus-inputs.py')],cwd=root,check=True)
hold=helper/'corpus-prerequisite.pending';deadline=time.monotonic()+1200
while hold.exists():
    if time.monotonic()>deadline:raise SystemExit('serial diagnostic still owns heavy-trial slot; corpus not started')
    time.sleep(5)
expected={row['id']:row for row in json.loads(gzip.decompress((root/'test/compatibility/ci/golang-results.json.gz').read_bytes()))['documents']}
groups=[('holdout-manifest.json','.tmp/compatibility-holdout'),('regression.json','.tmp/compatibility-regression'),('production32.json','.tmp/compatibility-corpora/production32'),('modern.json','.tmp/compatibility-corpora/modern')]
output=base/'go-corpus-candidate'
output.mkdir(mode=0o700,exist_ok=False)
env=os.environ|{'GOMEMLIMIT':'3GiB'}
def trial(name,command,seconds=4500,rss=12288):
    return subprocess.call([sys.executable,str(helper/'run-trial.py'),str(base/name),str(seconds),str(rss),*command],cwd=root,env=env)
binary=output/'golang-compat'
if trial('go-corpus-candidate-build-auditor',['go','build','-o',str(binary),'./scripts/golang-compat'],seconds=180,rss=3072):raise SystemExit('auditor build failed')
results=[]
for name,directory in groups:
    manifest=root/'test/compatibility'/name
    for item in json.loads(manifest.read_text())['corpora']:
        if item['id']=='microsoft-graph-beta':continue
        index=len(results)
        report=output/f'{index:02d}.json'
        label=f'go-corpus-candidate-{index:02d}'
        code=trial(label,[str(binary),'--mode','golang-generation','--verify','--server','--manifest',str(manifest),'--corpus-root',str(root/directory),'--document',item['id'],'--output',str(report)])
        recorded=json.loads((base/label/'result.json').read_text())
        row={'id':item['id'],'recorderStatus':recorded['status'],'exitCode':code,'report':str(report),'pass':False}
        if report.exists():
            value=json.loads(report.read_text())
            assert value['inputSha256']==expected[item['id']]['inputSha256']
            assert value['mode']=='golang-generation' and value['addons']==['server'] and value['goVersion']=='go1.27.2'
            assert value['goCompilationPolicy']=={'timeoutSeconds':3600,'buildParallelism':1,'cpuConcurrency':4,'memoryLimit':'6GiB'}
            row['pass']=code==0 and recorded['status']=='pass' and value['pass'] and value['golang'].get('compilation',{}).get('status')=='pass'
            row['contractTests']=value['golang'].get('compilation',{}).get('contractTests',[])
            row['files']=value['golang']['files'];row['bytes']=value['golang']['bytes']
        results.append(row)
        summary={'status':'pass' if len(results)==38 and all(r['pass'] for r in results) else 'incomplete','expectedDocuments':38,'completedDocuments':len(results),'passedDocuments':sum(r['pass'] for r in results),'results':results,'scope':'fresh native Go generation and full compile with server; Graph separate; no cross-target parity claim'}
        (output/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
        print(json.dumps({k:summary[k] for k in ['completedDocuments','passedDocuments']}),flush=True)
assert len(results)==len(expected)==38 and {r['id'] for r in results}==expected.keys()
if not all(row['pass'] for row in results):
    summary['status']='fail';(output/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    raise SystemExit('one or more corpus candidates failed; inspect reports and recorder causes')
