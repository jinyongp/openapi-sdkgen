import gzip,hashlib,json
from pathlib import Path
root=Path('/home/jinyongp/workspace/jinyongp/openapi-sdkgen')
groups=[('holdout-manifest.json','.tmp/compatibility-holdout'),('regression.json','.tmp/compatibility-regression'),('production32.json','.tmp/compatibility-corpora/production32'),('modern.json','.tmp/compatibility-corpora/modern')]
original=json.loads(gzip.decompress((root/'test/compatibility/ci/golang-results.json.gz').read_bytes()))['documents']
expected={row['id']:row for row in original}
assert len(original)==len(expected)==38
seen=set()
for name,directory in groups:
    manifest=json.loads((root/'test/compatibility'/name).read_text())
    for item in [*manifest.get('files',[]),*manifest['corpora']]:
        path=root/directory/item['input']
        data=path.read_bytes()
        digest=hashlib.sha256(data).hexdigest()
        if item.get('sha256'):assert digest==item['sha256'],path
        elif item.get('gitBlob'):assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==item['gitBlob'],path
        else:raise AssertionError('unpinned source '+str(path))
        if item in manifest['corpora'] and item['id']!='microsoft-graph-beta':
            assert item['id'] not in seen,item['id']
            seen.add(item['id'])
            old=expected[item['id']]
            assert old['input']==item['input'] and old['inputSha256']==digest,item['id']
            assert old['mode']=='golang-generation' and old['addons']==['server']
            assert old['goVersion']=='go1.27.2' and old['pass']
            assert old['golang']['compilation']['status']=='pass'
assert seen==expected.keys()
print('38 candidate corpus inputs exactly match pinned original server Go compile documents; Graph separate')
