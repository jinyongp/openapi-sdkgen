"""Retain the completed RSS trial's exact compiler input, without inventing a report."""
import hashlib, json, os
from pathlib import Path

root = Path('/home/jinyongp/workspace/jinyongp/openapi-sdkgen')
base = root / '.tmp/sdk-optimization-execution'
trial = base / 'go-corpus-candidate-22'
source = Path('/tmp/sdkgen-compat-2812172191')
output = base / 'go-corpus-cloudflare-rss-input'
result = json.loads((trial / 'result.json').read_text())
assert result['status'] == 'rss_protection'
assert not output.exists() and source.parent == Path('/tmp')
assert {path.name for path in source.iterdir()} == {'api', 'go.mod', 'cloudflare_http_test.go'}
assert (trial / 'started.json').stat().st_mtime <= source.stat().st_mtime <= (trial / 'result.json').stat().st_mtime
for path in Path('/proc').glob('[0-9]*/stat'):
    try:
        assert int(path.read_text().rsplit(')', 1)[1].split()[3]) != 118542, 'original trial session still owns the input'
    except (OSError, ValueError, IndexError):
        pass
output.mkdir(mode=0o700)
destination = output / 'module'
source.rename(destination)
sha = lambda path: hashlib.file_digest(path.open('rb'), 'sha256').hexdigest()
assert sha(destination / 'cloudflare_http_test.go') == sha(root / 'test/compatibility/conformance/cloudflare_http_test.go.txt')
rows = []; aggregate = hashlib.sha256(); total = 0
with (output / 'files.jsonl').open('x') as inventory:
    for path in sorted((destination / 'api').rglob('*')):
        assert not path.is_symlink()
        if not path.is_file():
            continue
        name = str(path.relative_to(destination / 'api'))
        digest = sha(path); size = path.stat().st_size
        inventory.write(json.dumps({'path': name, 'bytes': size, 'sha256': digest}) + '\n')
        aggregate.update((name + '\0' + digest + '\n').encode())
        total += size; rows.append(name)
assert len(rows) > 10000
summary = {'status': 'retained_incomplete_rss_trial',
           'scope': 'exact compiler input retained after recorder RSS protection; no auditor final report or compile/HTTP pass',
           'originalModule': str(source), 'retainedModule': str(destination),
           'trialResultSha256': sha(trial / 'result.json'), 'sourceManifestSha256': result['sourceManifestSha256'],
           'rssLimitMiB': result['rssLimitMiB'], 'peakSessionRSSBytes': result['peakSessionRSSBytes'],
           'elapsedSeconds': result['elapsedSeconds'], 'generatedFiles': len(rows), 'generatedBytes': total,
           'recomputedArtifactSha256': aggregate.hexdigest(),
           'hashAlgorithm': 'same sorted logical-path NUL file-SHA newline framing as golang-compat; recomputed from retained output, not a captured final report',
           'inventorySha256': sha(output / 'files.jsonl'), 'goModuleSha256': sha(destination / 'go.mod'),
           'httpFixtureSha256': sha(destination / 'cloudflare_http_test.go'),
           'httpContract': 'fixture retained; execution not completed',
           'lastObservedCompilerPackage': 'example.test/corpus/api/internal/operations',
           'phaseLimit': 'last proc observation before protection; final package/stack not captured'}
(output / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({key: summary[key] for key in ['status', 'generatedFiles', 'generatedBytes', 'recomputedArtifactSha256']}))
