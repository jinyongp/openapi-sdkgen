import json,subprocess,sys
from pathlib import Path
args=sys.argv[1:]
directory,seconds,requested=args[:3]
command=args[3:]
available=int(next(line.split()[1] for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:')))//1024
budget=min(int(requested),12288,available-2048)
if budget<3072:raise SystemExit('insufficient RAM headroom; trial not started')
print(json.dumps({'rssLimitMiB':budget,'policy':'min(request, 12 GiB, current available RAM - 2 GiB)'}),flush=True)
raise SystemExit(subprocess.call(['devtools','run','preflight:perf','--output',directory,'--timeout',seconds,'--max-rss-mib',str(budget),'--input',str(Path(__file__).resolve()),'--',*command]))
