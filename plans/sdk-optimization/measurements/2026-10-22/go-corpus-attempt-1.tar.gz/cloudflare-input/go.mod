module example.test/corpus

go 1.27.0
