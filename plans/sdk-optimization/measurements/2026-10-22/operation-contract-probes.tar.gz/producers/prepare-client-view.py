"""Hardlink a read-only diagnostic fixture, leaving one source for apply_patch."""
import hashlib,json,os
from pathlib import Path
root=Path('/home/jinyongp/workspace/jinyongp/openapi-sdkgen')
base=root/'.tmp/sdk-optimization-execution'
original=base/'graph-ts-named-owner20-flat'
candidate=base/'graph-ts-named-owner20-client-view-flat'
assert not candidate.exists()
candidate.mkdir(mode=0o700)
target=Path('internal/client/types.ts')
for source in original.rglob('*'):
    relative=source.relative_to(original); destination=candidate/relative
    if relative in [target,Path('tsconfig.json'),Path('ownership-plan.json')]:continue
    assert not source.is_symlink()
    if source.is_dir():destination.mkdir(exist_ok=True)
    elif source.is_file():os.link(source,destination)
for name in ['tsconfig.json','ownership-plan.json']:
    value=json.loads((original/name).read_text())
    def replace(value):
        if isinstance(value,str):return value.replace(str(original),str(candidate))
        if isinstance(value,list):return [replace(x) for x in value]
        if isinstance(value,dict):return {k:replace(v) for k,v in value.items()}
        return value
    (candidate/name).write_text(json.dumps(replace(value),indent=2)+'\n')
print(json.dumps({'fixture':str(candidate),'originalTargetSha256':hashlib.sha256((original/target).read_bytes()).hexdigest(),'targetLeftForNativePatch':str(target)}))
