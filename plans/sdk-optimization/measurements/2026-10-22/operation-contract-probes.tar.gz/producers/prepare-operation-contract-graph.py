"""Fresh representative SDK and complete ownership before whole compiler checks."""
import hashlib, json, os, subprocess, sys
from pathlib import Path

root = Path('/home/jinyongp/workspace/jinyongp/openapi-sdkgen')
base = root / '.tmp/sdk-optimization-execution'
helpers = root / '.tmp/sdk-optimization-execution-helpers'
assert json.loads((base / 'operation-contract-projection-unit-1/result.json').read_text())['status'] == 'pass', 'resolve public contract regression first'
binary = base / 'sdkgen-operation-contracts'
sdk = base / 'graph-ts-operation-contracts'
inventory = base / 'graph-ts-operation-contracts-inventory'
plan = base / 'graph-ts-operation-contracts-project-plan'
assert not binary.exists() and not sdk.exists() and not inventory.exists() and not plan.exists()
def trial(name, command, seconds=600, rss=3072, extra=None):
    code = subprocess.call([sys.executable, '-B', str(helpers / 'run-trial.py'), str(base / name), str(seconds), str(rss), *command], cwd=root, env=os.environ | (extra or {}))
    assert code == 0, name + ' failed; later steps not started'
trial('sdkgen-operation-contracts-build', ['go', 'build', '-o', str(binary), './cmd/openapi-sdkgen'], 300)
trial('graph-ts-operation-contracts-generation', [str(binary), 'generate', '--target', 'typescript', '--typecheck', '--input', '.tmp/compatibility-regression/microsoft-graph-beta/openapi.yaml', '--output', str(sdk)], 1800, 12288, {'GOMEMLIMIT': '8GiB'})
trial('graph-ts-operation-contracts-source-config', ['node', 'scripts/perf/sdk-optimization/prepare-ts.mjs', str(sdk)])
trial('graph-ts-operation-contracts-inventory-run', ['node', '--max-old-space-size=2048', 'scripts/perf/sdk-optimization/inventory.mjs', str(sdk), str(inventory)])
trial('graph-ts-operation-contracts-project-plan-run', ['node', '--max-old-space-size=2048', 'scripts/perf/sdk-optimization/project-plan.mjs', str(inventory), str(plan), '33554432', '12000'])
trial('graph-ts-operation-contracts-membership-run', [sys.executable, '-B', str(helpers / 'verify-native-section-sets.py'), '--sdk', str(sdk), '--output', str(base / 'graph-ts-operation-contracts-membership.json')])
value = json.loads((plan / 'plan.json').read_text())
print(json.dumps({'status': 'pass', 'scope': 'fresh full Graph generation, complete source ownership and frozen membership; compiler checks pending', 'files': value['files'], 'projects': len(value['groups']), 'sdkManifestSha256': hashlib.sha256((sdk / '.openapi-sdkgen-manifest.json').read_bytes()).hexdigest()}), flush=True)
