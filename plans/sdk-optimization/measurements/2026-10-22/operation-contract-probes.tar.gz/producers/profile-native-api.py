"""Read-only, intrusive per-file checker diagnosis using the bundled async API."""
import argparse,concurrent.futures,hashlib,json,os,subprocess,threading,time
from pathlib import Path
parser=argparse.ArgumentParser(description=__doc__)
for key in ['config','plan','target','output']:parser.add_argument('--'+key,type=Path,required=True)
parser.add_argument('--owner',type=int,default=19)
parser.add_argument('--seconds',type=int,default=120)
parser.add_argument('--method',choices=['semantic','declaration','bind'],default='semantic')
parser.add_argument('--all-files',action='store_true',help='diagnose the whole loaded program instead of one file; not an emit check')
args=parser.parse_args()
root=Path('/home/jinyongp/workspace/jinyongp/openapi-sdkgen')
output=args.output.resolve();output.mkdir(mode=0o700,parents=True,exist_ok=False)
config=args.config.resolve();plan=json.loads(args.plan.read_text());sdk=Path(plan['root'])
expected={str(sdk/name) for name in plan['groups'][args.owner]['files']}
report={'status':'incomplete','scope':'async native API CPU/heap diagnosis, not CLI/full source/declaration/public consumer success','target':'loaded program' if args.all_files else str(args.target.resolve()),'configSha256':hashlib.sha256(config.read_bytes()).hexdigest(),'heap':os.environ.get('GOMEMLIMIT'),'events':[]}
def save():(output/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
save()
command=['node',str(root/'test/typescript/node_modules/typescript/lib/tsc.js'),'--api','--async','--cwd',str(root)]
process=subprocess.Popen(command,stdin=subprocess.PIPE,stdout=subprocess.PIPE,cwd=root)
pending={};lock=threading.Lock();sequence=0
def read():
    try:
        while True:
            header={}
            while True:
                line=process.stdout.readline()
                if not line:raise EOFError('native API exited')
                if line in [b'\r\n',b'\n']:break
                key,value=line.decode().split(':',1);header[key.lower()]=value.strip()
            message=json.loads(process.stdout.read(int(header['content-length'])))
            if 'id' not in message:continue
            with lock:future=pending.pop(message['id'],None)
            if future is not None:
                if 'error' in message:future.set_exception(RuntimeError(json.dumps(message['error'])))
                else:future.set_result(message.get('result'))
    except Exception as error:
        with lock:
            for future in pending.values():future.set_exception(error)
            pending.clear()
threading.Thread(target=read,daemon=True).start()
def call(method,params=None,timeout=90,wait=True):
    global sequence
    sequence+=1;future=concurrent.futures.Future()
    message={'jsonrpc':'2.0','id':sequence,'method':method}
    if params is not None:message['params']=params
    data=json.dumps(message).encode()
    with lock:pending[sequence]=future
    process.stdin.write(b'Content-Length: '+str(len(data)).encode()+b'\r\n\r\n'+data);process.stdin.flush()
    report['events'].append({'method':method,'sentAt':time.time()});save()
    return future.result(timeout=timeout) if wait else future
try:
    report['initialize']=call('initialize')
    selected={'GOMEMLIMIT','GOMAXPROCS','GOGC','GODEBUG'}
    report['compilerRuntimeEnvironment']={}
    for value in Path('/proc',str(process.pid),'environ').read_bytes().split(b'\0'):
        if b'=' not in value:continue
        key,value=value.split(b'=',1)
        if key.decode() in selected:report['compilerRuntimeEnvironment'][key.decode()]=value.decode()
    save()
    state=call('updateSnapshot',{'openProjects':[str(config)]},timeout=240)
    project=next(p for p in state['projects'] if p['configFileName']==str(config))
    assert project['compilerOptions'].get('strict') is True
    assert project['compilerOptions'].get('noCheck',False) is False
    report['compilerOptions']=project['compilerOptions']
    context={'snapshot':state['snapshot'],'project':project['id']}
    files=call('getSourceFileNames',context)
    actual={str(Path(p)) for p in files if Path(p).is_relative_to(sdk) and p.endswith('.ts') and not p.endswith('.d.ts')}
    report.update(project=str(project['id']),programFiles=len(files),expectedOwnedSources=len(expected),observedOwnedSources=len(actual),ownershipMatch=actual==expected)
    (output/'program-files.json').write_text(json.dumps(files,indent=2)+'\n');save()
    assert actual==expected,'API source ownership differs from CLI owner'
    profiles=output/'profiles';profiles.mkdir()
    call('startCPUProfile',{'dir':str(profiles)})
    method={'semantic':'getSemanticDiagnostics','declaration':'getDeclarationDiagnostics','bind':'getBindDiagnostics'}[args.method]
    report['diagnosticMethod']=method;save()
    parameters=context if args.all_files else {**context,'file':str(args.target.resolve())}
    checking=call(method,parameters,wait=False)
    started=time.monotonic()
    while not checking.done() and time.monotonic()-started<args.seconds:time.sleep(0.25)
    cpu=call('stopCPUProfile',timeout=90)['file']
    heap=call('saveHeapProfile',{'dir':str(profiles)},timeout=90)['file']
    report['profileIntervalSeconds']=time.monotonic()-started
    report['diagnosticsFinished']=checking.done()
    if checking.done():
        diagnostics=checking.result()
        report['diagnosticCount']=len(diagnostics)
        (output/'diagnostics.json').write_text(json.dumps(diagnostics,indent=2)+'\n')
        report['diagnosticsFile']='diagnostics.json'
    report['profiles']=[cpu,heap]
    for file in report['profiles']:
        subprocess.run(['go','tool','pprof','-top','-nodecount=1',file],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
    report['status']='diagnostic_complete';save()
    print(json.dumps({k:report[k] for k in ['status','target','programFiles','ownershipMatch','diagnosticsFinished','profileIntervalSeconds']}),flush=True)
finally:
    if process.poll() is None:process.kill()
    process.wait();save()
