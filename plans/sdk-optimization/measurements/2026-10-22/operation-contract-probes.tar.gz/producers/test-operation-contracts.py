"""Check canonical ID projection against existing public compatibility contracts."""
import os, subprocess, sys
from pathlib import Path
root = Path('/home/jinyongp/workspace/jinyongp/openapi-sdkgen')
base = root / '.tmp/sdk-optimization-execution'
helpers = root / '.tmp/sdk-optimization-execution-helpers'
tests = '^Test(ResourceSurfaceReusesCanonicalParameterCall|SourceArtifactsGenerateNestedResourceTree|RegistryModulesKeepCrossChunkLinksAndOrderedPublicMaps|SectionIndexesPreserveCanonicalGenericContracts|SourceArtifactsGenerateExactRouteWithoutOperationID)$'
command = [sys.executable, '-B', str(helpers / 'run-trial.py'), str(base / 'operation-contract-projection-unit-1'), '1200', '3072', sys.executable, '-B', str(helpers / 'observe-contract-compiler.py'), str(base / 'operation-contract-projection-unit-1-processes.jsonl'), 'env', 'GOMAXPROCS=1', 'go', 'test', '-p=1', '-v', './internal/target/typescript', '-run', tests, '-count=1', '-timeout=15m']
raise SystemExit(subprocess.call(command, cwd=root, env=os.environ | {'GOMEMLIMIT': '1GiB'}))
