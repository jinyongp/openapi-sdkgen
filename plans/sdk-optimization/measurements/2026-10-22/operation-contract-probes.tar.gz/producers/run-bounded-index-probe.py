"""Diagnose explicit canonical key bounds without changing product source."""
import hashlib, json, os, subprocess, sys
from pathlib import Path

root = Path('/home/jinyongp/workspace/jinyongp/openapi-sdkgen')
base = root / '.tmp/sdk-optimization-execution'
helpers = root / '.tmp/sdk-optimization-execution-helpers'
flat = base / 'graph-ts-named-owner20-bounded-index-flat'
original = base / 'graph-ts-named-owner20-flat'
preparation = json.loads((base / 'graph-ts-named-owner20-bounded-index-preparation.json').read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
for name, digest in preparation['originalSourceSha256'].items():
    assert sha(original / name) == digest
    assert (flat / name).stat().st_ino != (original / name).stat().st_ino
available = int(next(line.split()[1] for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:'))) // 1024
hard = min(9216, available - 2048)
assert hard >= 8192, '8GiB minimum plus 2GiB headroom unavailable; no child started'
name = 'graph-ts-named-owner20-bounded-index-file'
command = ['devtools', 'run', 'preflight:perf', '--output', str(base / (name + '-run')),
           '--timeout', '600', '--max-rss-mib', str(hard), '--input', str(Path(__file__).resolve()),
           '--input', str(helpers / 'profile-native-api.py')]
for relative in preparation['originalSourceSha256']:
    command += ['--input', str(flat / relative)]
command += ['--', sys.executable, '-B', str(helpers / 'profile-native-api.py'),
            '--config', str(flat / 'tsconfig.json'), '--plan', str(flat / 'ownership-plan.json'),
            '--target', str(flat / 'internal/client/types.ts'), '--output', str(base / name),
            '--owner', '20', '--seconds', '120']
code = subprocess.call(command, cwd=root, env=os.environ | {'GOMEMLIMIT': '6GiB', 'GOGC': '100', 'GOMAXPROCS': '4', 'GODEBUG': 'gctrace=1'})
assert all(sha(original / name) == digest for name, digest in preparation['originalSourceSha256'].items())
raise SystemExit(code)
