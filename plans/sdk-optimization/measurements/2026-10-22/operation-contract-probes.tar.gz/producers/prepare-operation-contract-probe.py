"""Copy immutable diagnostic inputs; source edits are applied separately."""
import hashlib, json, os, shutil
from pathlib import Path

root = Path('/home/jinyongp/workspace/jinyongp/openapi-sdkgen')
base = root / '.tmp/sdk-optimization-execution'
original = base / 'graph-ts-named-owner20-flat'
candidate = base / 'graph-ts-named-owner20-operation-contract-flat'
targets = ['internal/client/types.ts', 'internal/client/registry-contracts.ts', 'internal/routes/index.ts']
assert not candidate.exists()
candidate.mkdir(mode=0o700)
for source in original.rglob('*'):
    relative = source.relative_to(original)
    destination = candidate / relative
    if str(relative) in targets + ['tsconfig.json', 'ownership-plan.json']:
        continue
    assert not source.is_symlink()
    if source.is_dir():
        destination.mkdir(exist_ok=True)
    else:
        os.link(source, destination)
for name in targets:
    shutil.copy2(original / name, candidate / name)
    assert (original / name).stat().st_ino != (candidate / name).stat().st_ino
def relocate(value):
    if isinstance(value, str): return value.replace(str(original), str(candidate))
    if isinstance(value, list): return [relocate(item) for item in value]
    if isinstance(value, dict): return {key: relocate(item) for key, item in value.items()}
    return value
for name in ['tsconfig.json', 'ownership-plan.json']:
    (candidate / name).write_text(json.dumps(relocate(json.loads((original / name).read_text())), indent=2) + '\n')
report = {'originalSourceSha256': {name: hashlib.sha256((original / name).read_bytes()).hexdigest() for name in targets}, 'scope': 'mechanical copy; subsequent native patch defines isolated diagnostic candidate'}
(base / 'graph-ts-named-owner20-operation-contract-preparation.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'fixture': str(candidate), 'independentSourceFiles': len(targets)}), flush=True)
