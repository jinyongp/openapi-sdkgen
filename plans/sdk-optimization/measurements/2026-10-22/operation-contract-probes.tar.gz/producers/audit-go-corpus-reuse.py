"""Audit correctness-only reuse when only reviewed TypeScript emitters changed."""
import hashlib, json, os, subprocess, sys
from pathlib import Path

root = Path('/home/jinyongp/workspace/jinyongp/openapi-sdkgen')
base = root / '.tmp/sdk-optimization-execution'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
previous = json.loads((base / 'go-corpus-candidate-22/source.json').read_text())
tracked = subprocess.check_output(['git', 'ls-files', 'cmd', 'internal', 'scripts/golang-compat', 'go.mod', 'go.sum'], cwd=root, text=True).splitlines()
current = {name: sha(root / name) for name in tracked}
prior = {name: digest for name, digest in previous.items() if name.startswith(('cmd/', 'internal/', 'scripts/golang-compat/')) or name in ['go.mod', 'go.sum']}
assert current.keys() == prior.keys(), 'source inventory changed; review added/deleted dependencies'
changed = [name for name in sorted(current) if current[name] != prior[name]]
allowed = {'internal/target/typescript/public_type_modules.go', 'internal/target/typescript/client_registry_modules.go'}
assert set(changed) <= allowed, 'changes exceed reviewed TS emitter function bodies'
go = Path.home() / 'go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.linux-amd64/bin/go'
env = os.environ | {'GOTOOLCHAIN': 'local', 'GOWORK': 'off', 'CGO_ENABLED': '0', 'GOOS': 'linux', 'GOARCH': 'amd64', 'GOAMD64': 'v1'}
version = subprocess.check_output([str(go), 'version'], env=env, text=True).strip()
assert version.startswith('go version go1.27.2 ')
data = subprocess.check_output([str(go), 'list', '-deps', '-json', './internal/target/golang', './internal/compiler', './internal/generator', './internal/compatinput'], cwd=root, env=env, text=True)
decoder = json.JSONDecoder(); packages = []; files = set()
while data.strip():
    value, end = decoder.raw_decode(data.lstrip()); data = data.lstrip()[end:]
    directory = Path(value['Dir'])
    if not directory.is_relative_to(root):
        continue
    assert not value['ImportPath'].startswith('openapi-sdkgen/internal/target/typescript')
    packages.append(value['ImportPath'])
    for key in ['GoFiles', 'CgoFiles', 'EmbedFiles', 'SFiles', 'HFiles', 'CFiles']:
        for name in value.get(key, []):
            file = directory / name
            assert file.is_relative_to(root) and file.is_file()
            files.add(str(file.relative_to(root)))
assert files and set(changed).isdisjoint(files)
for name in sorted(files):
    assert sha(root / name) == previous[name], 'Go generation dependency changed: ' + name
# The unchanged auditor calls TypeScript only in parity mode (main.go:274).
# Both excluded files change emitter function bodies only; no imports/init/global
# initialization changed. This is a reviewed reachability claim, not inferred
# solely from the package list. The fixed old auditor binary is retained.
for name in changed:
    assert '\nfunc init(' not in (root / name).read_text()
binary = base / 'go-corpus-candidate/golang-compat'
old = json.loads((base / 'go-corpus-candidate-22/result.json').read_text())
assert sha(binary) == old['binaries'][str(binary)]
report = {'status': 'pass', 'scope': 'correctness-only Go native generation reuse; not current whole-repository identity, timing, TS parity, or a missing compile pass', 'goVersion': version, 'auditorSha256': sha(binary), 'reviewedUnreachableTypeScriptEmitterChanges': {name: {'previous': prior[name], 'current': current[name]} for name in changed}, 'reviewedAuditorBranch': 'scripts/golang-compat/main.go:274 excludes TypeScript emission in --mode golang-generation; changed files contain only TS emitter function-body changes', 'unchangedTrackedInputs': len(current) - len(changed), 'unchangedGoDependencyFiles': {name: sha(root / name) for name in sorted(files)}, 'goDependencyPackages': sorted(packages), 'priorVerifiedSummarySha256': sha(base / 'go-corpus-candidate-verified/summary.json')}
output = base / (sys.argv[1] if len(sys.argv) > 1 else 'go-corpus-typescript-emitter-reuse-1.json')
with output.open('x') as stream:
    json.dump(report, stream, indent=2); stream.write('\n')
print(json.dumps({'status': 'pass', 'unchangedTrackedInputs': report['unchangedTrackedInputs'], 'goDependencyFiles': len(files), 'excludedChangedFiles': changed, 'timingReuse': False}), flush=True)
