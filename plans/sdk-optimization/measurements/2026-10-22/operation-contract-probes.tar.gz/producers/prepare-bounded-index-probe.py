"""Clone diagnostic inputs; source content changes are left to native apply_patch."""
import hashlib, json, os, shutil
from pathlib import Path

root = Path('/home/jinyongp/workspace/jinyongp/openapi-sdkgen')
base = root / '.tmp/sdk-optimization-execution'
original = base / 'graph-ts-named-owner20-flat'
candidate = base / 'graph-ts-named-owner20-bounded-index-flat'
targets = [Path(name) for name in ['internal/client/types.ts', 'internal/client/registry-contracts.ts', 'internal/routes/index.ts']]
assert not candidate.exists()
candidate.mkdir(mode=0o700)
for source in original.rglob('*'):
    relative = source.relative_to(original); destination = candidate / relative
    if relative in targets or relative in [Path('tsconfig.json'), Path('ownership-plan.json')]:
        continue
    assert not source.is_symlink()
    if source.is_dir():
        destination.mkdir(exist_ok=True)
    elif source.is_file():
        os.link(source, destination)
for name in targets:
    shutil.copy2(original / name, candidate / name)
    assert (original / name).stat().st_ino != (candidate / name).stat().st_ino
def relocate(value):
    if isinstance(value, str): return value.replace(str(original), str(candidate))
    if isinstance(value, list): return [relocate(item) for item in value]
    if isinstance(value, dict): return {key: relocate(item) for key, item in value.items()}
    return value
for name in ['tsconfig.json', 'ownership-plan.json']:
    (candidate / name).write_text(json.dumps(relocate(json.loads((original / name).read_text())), indent=2) + '\n')
report = {'fixture': str(candidate), 'originalSourceSha256': {str(name): hashlib.sha256((original / name).read_bytes()).hexdigest() for name in targets},
          'scope': 'three independent inodes copied without content changes; native patch follows; product source unchanged'}
(base / 'graph-ts-named-owner20-bounded-index-preparation.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
