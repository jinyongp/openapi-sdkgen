"""Match the new two-file attribution budget; never mutate the original SDK."""
import hashlib,json,os,subprocess,sys,time
from pathlib import Path
root=Path('/home/jinyongp/workspace/jinyongp/openapi-sdkgen');base=root/'.tmp/sdk-optimization-execution';helpers=root/'.tmp/sdk-optimization-execution-helpers'
for label in ['client-types','registry-contracts']:
    result=base/('graph-ts-named-owner20-file-'+label+'-run/result.json')
    assert result.exists(),'prior diagnostic still owns serial slot'
flat=base/'graph-ts-named-owner20-client-view-flat';original=base/'graph-ts-named-owner20-flat';relative=Path('internal/client/types.ts')
before=hashlib.sha256((original/relative).read_bytes()).hexdigest()
assert (flat/relative).stat().st_ino!=(original/relative).stat().st_ino
available=int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))//1024
assert available-2048>=9216,'9GiB + 2GiB headroom unavailable; no child started'
name='graph-ts-named-owner20-client-view'
code=subprocess.call(['devtools','run','preflight:perf','--output',str(base/(name+'-run')),'--timeout','600','--max-rss-mib','9216','--input',str(helpers/'run-client-view-probe.py'),'--input',str(flat/relative),'--',sys.executable,'-B',str(helpers/'profile-native-api.py'),'--config',str(flat/'tsconfig.json'),'--plan',str(flat/'ownership-plan.json'),'--target',str(flat/relative),'--output',str(base/name),'--owner','20','--seconds','120'],cwd=root,env=os.environ|{'GOMEMLIMIT':'6GiB','GOGC':'100','GOMAXPROCS':'4','GODEBUG':'gctrace=1'})
assert hashlib.sha256((original/relative).read_bytes()).hexdigest()==before,'original source changed'
raise SystemExit(code)
