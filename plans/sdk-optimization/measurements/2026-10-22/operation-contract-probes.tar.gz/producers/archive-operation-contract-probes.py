"""Preserve completed diagnoses and their limits; never include active compilers."""
import hashlib, io, json, subprocess, tarfile
from pathlib import Path

root = Path('/home/jinyongp/workspace/jinyongp/openapi-sdkgen')
base = root / '.tmp/sdk-optimization-execution'
helpers = root / '.tmp/sdk-optimization-execution-helpers'
destination = root / 'plans/sdk-optimization/measurements/2026-10-22/operation-contract-probes.tar.gz'
assert not destination.exists()
sha = lambda p: hashlib.file_digest(p.open('rb'), 'sha256').hexdigest()
names = ['graph-ts-named-owner20-file-client-types', 'graph-ts-named-owner20-file-registry-contracts', 'graph-ts-named-owner20-client-view', 'graph-ts-named-owner20-bounded-index-program', 'graph-ts-named-owner20-bounded-index-file'] + ['graph-ts-named-owner20-operation-contract-' + label for label in ['client', 'registry', 'routes']]
files = {}; outcomes = {}
for name in names:
    trial = base / (name + '-run')
    record = json.loads((trial / 'result.json').read_text())
    assert sha(trial / 'source.json') == record['sourceManifestSha256']
    outcomes[name] = {key: record[key] for key in ['status', 'elapsedSeconds', 'peakSessionRSSBytes', 'rssLimitMiB']}
    diagnostic = base / name
    value = json.loads((diagnostic / 'summary.json').read_text())
    outcomes[name].update({key: value.get(key) for key in ['diagnosticsFinished', 'diagnosticCount', 'ownershipMatch', 'profileIntervalSeconds']})
    for directory, prefix in [(trial, 'trials/' + name), (diagnostic, 'diagnostics/' + name)]:
        for path in directory.rglob('*'):
            if path.is_file():
                assert not path.is_symlink()
                files[prefix + '/' + str(path.relative_to(directory))] = path
fixture_names = ['graph-ts-named-owner20-flat', 'graph-ts-named-owner20-client-view-flat', 'graph-ts-named-owner20-bounded-index-flat', 'graph-ts-named-owner20-operation-contract-flat']
for name in fixture_names:
    fixture = base / name
    assert fixture.is_dir(), 'resolve exact existing fixture name before archiving'
    for relative in ['internal/client/types.ts', 'internal/client/registry-contracts.ts', 'internal/routes/index.ts', 'tsconfig.json', 'ownership-plan.json']:
        files['inputs/' + name + '/' + relative] = fixture / relative
for name in ['profile-native-api.py', 'prepare-client-view.py', 'run-client-view-probe.py', 'prepare-bounded-index-probe.py', 'run-bounded-index-probe.py', 'prepare-operation-contract-probe.py', 'run-operation-contract-probe.py', 'test-operation-contracts.py', 'prepare-operation-contract-graph.py', 'audit-go-corpus-reuse.py', Path(__file__).name]:
    files['producers/' + name] = helpers / name
for name in ['go-corpus-typescript-emitter-reuse-1.json', 'go-corpus-typescript-emitter-reuse-2.json', 'graph-ts-named-owner20-bounded-index-preparation.json', 'graph-ts-named-owner20-operation-contract-preparation.json', 'operation-contract-projection-unit-1-processes.jsonl']:
    files['reports/' + name] = base / name
unit = base / 'operation-contract-projection-unit-1'
assert json.loads((unit / 'result.json').read_text())['status'] == 'pass'
for path in unit.iterdir():
    assert path.is_file() and not path.is_symlink()
    files['unit/' + path.name] = path
patch = subprocess.check_output(['git', 'diff', '--binary', '--', 'internal/target/typescript/client_registry_modules.go', 'internal/target/typescript/client_registry_modules_test.go', 'internal/target/typescript/public_type_modules.go'], cwd=root)
assert patch, 'capture uncommitted candidate patch before the unit commit'
index = {'scope': 'intrusive local API diagnosis and small public contract unit; not complete Graph/CLI/source/server/declaration acceptance or public performance evidence', 'outcomes': outcomes, 'files': {name: {'bytes': path.stat().st_size, 'sha256': sha(path)} for name, path in sorted(files.items())}, 'patchBase': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(), 'patchSha256': hashlib.sha256(patch).hexdigest(), 'postUnitDelta': 'Restored original Operations JSDoc only; type-producing code unchanged, verified by reversing exactly that comment-output branch against recorded unit source SHA.', 'excluded': ['Full mechanically generated SDK/declaration trees remain locally at recorded paths; selected changed TS inputs, full program-file lists, ownership configs and original generation provenance are retained. This archive does not contain every original compiler input byte.', 'Compiler/auditor executable contents are excluded; recorder binary hashes and pinned toolchain/package versions identify them.', 'Private task contexts, personal CPU headers, active Graph trials and unrelated processes were never selected.']}
with tarfile.open(destination, 'w:gz', compresslevel=6) as archive:
    for name, path in sorted(files.items()):
        archive.add(path, arcname=name, recursive=False)
    for name, data in [('candidate.patch', patch), ('index.json', (json.dumps(index, indent=2) + '\n').encode())]:
        info = tarfile.TarInfo(name); info.size = len(data); info.mode = 0o600
        archive.addfile(info, io.BytesIO(data))
with tarfile.open(destination) as archive:
    assert json.load(archive.extractfile('index.json')) == index
    assert archive.extractfile('candidate.patch').read() == patch
    for name, entry in index['files'].items():
        data = archive.extractfile(name).read()
        assert len(data) == entry['bytes'] and hashlib.sha256(data).hexdigest() == entry['sha256']
print(json.dumps({'archive': str(destination), 'bytes': destination.stat().st_size, 'sha256': sha(destination), 'entries': len(files) + 2, 'diagnosticTrials': len(names), 'unitTrials': 1, 'verified': True}), flush=True)
