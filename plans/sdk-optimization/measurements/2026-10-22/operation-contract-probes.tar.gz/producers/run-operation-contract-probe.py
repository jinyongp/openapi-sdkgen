"""Diagnose bounded canonical ID contracts on immutable full Graph inputs."""
import hashlib, json, os, subprocess, sys
from pathlib import Path

root = Path('/home/jinyongp/workspace/jinyongp/openapi-sdkgen')
base = root / '.tmp/sdk-optimization-execution'
helpers = root / '.tmp/sdk-optimization-execution-helpers'
original = base / 'graph-ts-named-owner20-flat'
flat = base / 'graph-ts-named-owner20-operation-contract-flat'
preparation = json.loads((base / 'graph-ts-named-owner20-operation-contract-preparation.json').read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
for name, digest in preparation['originalSourceSha256'].items():
    assert sha(original / name) == digest
    assert (flat / name).stat().st_ino != (original / name).stat().st_ino
for label, name in [('client', 'internal/client/types.ts'), ('registry', 'internal/client/registry-contracts.ts'), ('routes', 'internal/routes/index.ts')]:
    available = int(next(line.split()[1] for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:'))) // 1024
    hard = min(9216, available - 2048)
    assert hard >= 8192, '8GiB minimum plus 2GiB headroom unavailable; no child started'
    output = base / ('graph-ts-named-owner20-operation-contract-' + label)
    command = ['devtools', 'run', 'preflight:perf', '--output', str(output) + '-run', '--timeout', '600', '--max-rss-mib', str(hard), '--input', str(Path(__file__).resolve()), '--input', str(helpers / 'profile-native-api.py')]
    for relative in preparation['originalSourceSha256']:
        command += ['--input', str(flat / relative)]
    command += ['--', sys.executable, '-B', str(helpers / 'profile-native-api.py'), '--config', str(flat / 'tsconfig.json'), '--plan', str(flat / 'ownership-plan.json'), '--target', str(flat / name), '--output', str(output), '--owner', '20', '--seconds', '120']
    code = subprocess.call(command, cwd=root, env=os.environ | {'GOMEMLIMIT': '6GiB', 'GOGC': '100', 'GOMAXPROCS': '4', 'GODEBUG': 'gctrace=1'})
    assert all(sha(original / source) == digest for source, digest in preparation['originalSourceSha256'].items())
    if code:
        raise SystemExit(code)
    report = json.loads((output / 'summary.json').read_text())
    print(json.dumps({'case': label, **{key: report.get(key) for key in ['ownershipMatch', 'diagnosticsFinished', 'diagnosticCount', 'profileIntervalSeconds']}}), flush=True)
    assert report['diagnosticsFinished'] and report['diagnosticCount'] == 0, 'candidate did not finish this semantic check; no later case started'
