import {provider as p0} from "/home/jinyongp/workspace/jinyongp/openapi-sdkgen/.tmp/sdk-optimization-preflight/graph-ts-strict/internal/executions/access-review-decisions/by-access-review-decision-id/get.ts";
import {provider as p1} from "/home/jinyongp/workspace/jinyongp/openapi-sdkgen/.tmp/sdk-optimization-preflight/graph-ts-strict/internal/executions/access-review-decisions/get.ts";
export const providers=[p0,p1];
