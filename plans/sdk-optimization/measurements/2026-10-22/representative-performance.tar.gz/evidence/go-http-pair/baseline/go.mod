module example.test/goperf

go 1.27.0
