package api_test

import (
	"context"
	"fmt"
	"io"
	"net/http"
	"runtime"
	"strings"
	"sync/atomic"
	"testing"

	api "example.test/goperf/api"
	"example.test/goperf/api/types"
)

type githubTransport struct {
	path, body     string
	opened, closed atomic.Int64
}
type githubBody struct {
	*strings.Reader
	closed *atomic.Int64
}

func (body *githubBody) Close() error { body.closed.Add(1); return nil }
func (*githubTransport) Capabilities() types.TransportCapabilities {
	return types.TransportCapabilities{}
}
func (transport *githubTransport) Do(request *http.Request, _ types.TransportOptions) (*http.Response, error) {
	if request.Method != "GET" || request.URL.Host != "example.test" || request.URL.EscapedPath() != transport.path {
		return nil, fmt.Errorf("unexpected prepared request: %s %s", request.Method, request.URL)
	}
	transport.opened.Add(1)
	return &http.Response{StatusCode: 200, Header: http.Header{"Content-Type": {"application/json"}}, Body: &githubBody{Reader: strings.NewReader(transport.body), closed: &transport.closed}, Request: request}, nil
}

var _ io.ReadCloser = (*githubBody)(nil)

func BenchmarkGitHubHTTP(b *testing.B) {
	for _, name := range []string{"git-ref", "issues"} {
		b.Run(name, func(b *testing.B) {
			transport := &githubTransport{}
			client, err := api.NewClient(api.ClientOptions{BaseURL: "https://example.test", Transport: transport})
			if err != nil {
				b.Fatal(err)
			}
			var invoke func(context.Context) error
			if name == "git-ref" {
				transport.path = "/repos/sdkgen/bench/git/ref/heads%2Fmain"
				transport.body = `{"ref":"refs/heads/main","node_id":"node","url":"https://example.test/ref","object":{"type":"commit","sha":"0123456789012345678901234567890123456789","url":"https://example.test/commit"}}`
				call := client.Operations.GitGetRef(api.GitGetRefInput{Path: api.GitGetRefPath{Owner: "sdkgen", Repo: "bench", Ref: "heads/main"}})
				invoke = func(ctx context.Context) error { _, err := call.Do(ctx); return err }
			} else {
				transport.path = "/repos/sdkgen/bench/issues"
				transport.body = "[]"
				call := client.Operations.IssuesListForRepo(api.IssuesListForRepoInput{Path: api.IssuesListForRepoPath{Owner: "sdkgen", Repo: "bench"}})
				invoke = func(ctx context.Context) error { _, err := call.Do(ctx); return err }
			}
			ctx := context.Background()
			var before, after runtime.MemStats
			runtime.ReadMemStats(&before)
			b.ReportAllocs()
			for b.Loop() {
				if err := invoke(ctx); err != nil {
					b.Fatal(err)
				}
			}
			b.StopTimer()
			runtime.ReadMemStats(&after)
			b.ReportMetric(float64(after.NumGC-before.NumGC)/float64(b.N), "gc/op")
			if transport.opened.Load() == 0 || transport.opened.Load() != transport.closed.Load() {
				b.Fatal("HTTP response ownership", transport.opened.Load(), transport.closed.Load())
			}
		})
	}
}
