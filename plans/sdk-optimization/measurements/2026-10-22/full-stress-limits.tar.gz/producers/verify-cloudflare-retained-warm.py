"""One bounded, non-Graph correctness check of the exact completed native SDK."""
import hashlib, json, os, subprocess, sys
from pathlib import Path

root = Path('/home/jinyongp/workspace/jinyongp/openapi-sdkgen')
base = root / '.tmp/sdk-optimization-execution'
helpers = root / '.tmp/sdk-optimization-execution-helpers'
module = Path('/tmp/sdkgen-compat-3271393760')
sdk = module / 'api'
original = base / 'go-corpus-cloudflare-rss-input'
output = base / 'go-corpus-cloudflare-retained-warm-1.json'
assert not output.exists()
sha = lambda p: hashlib.file_digest(p.open('rb'), 'sha256').hexdigest()
failed = json.loads((base / 'go-corpus-cloudflare-full-retry-1/result.json').read_text())
assert failed['status'] == 'rss_protection'
expected = [json.loads(line) for line in (original / 'files.jsonl').read_text().splitlines()]
paths = {entry['path'] for entry in expected}
assert {str(path.relative_to(sdk)) for path in sdk.rglob('*') if path.is_file()} == paths
for entry in expected:
    path = sdk / entry['path']; assert not path.is_symlink() and path.stat().st_size == entry['bytes'] and sha(path) == entry['sha256'], entry['path']
retained = json.loads((original / 'summary.json').read_text())
assert sha(module / 'go.mod') == retained['goModuleSha256']
assert sha(module / 'cloudflare_http_test.go') == retained['httpFixtureSha256']
manifest = json.loads((base / 'go-corpus-candidate-verified/regression.json').read_text())
pin = next(row for row in manifest['corpora'] if row['id'] == 'cloudflare')
document = root / '.tmp/compatibility-regression' / pin['input']
assert sha(document) == pin['sha256']
available = int(next(line.split()[1] for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:'))) // 1024
hard = min(11832, available - 2048)
assert hard >= 10240, '10GiB plus2GiB headroom unavailable; compiler not started'
report = {'status': 'incomplete', 'scope': 'exact completed native Cloudflare SDK; warm-cache full compile plus real loopback HTTP contract under lower soft heap; not a regenerated auditor final report or performance comparison', 'module': str(module), 'generatedFiles': len(expected), 'generatedBytes': sum(entry['bytes'] for entry in expected), 'allFilesMatchPriorNativeInventory': True, 'artifactSha256': retained['recomputedArtifactSha256'], 'originalInventorySha256': sha(original / 'files.jsonl'), 'inputSha256': pin['sha256'], 'goModuleSha256': sha(module / 'go.mod'), 'httpFixtureSha256': sha(module / 'cloudflare_http_test.go'), 'policy': {'timeoutSeconds': 600, 'rssLimitMiB': hard, 'softMemoryLimit': '3GiB', 'GOMAXPROCS': 4, 'buildParallelism': 1, 'codeGenerationFlagsUnchanged': True}, 'generationAuditorFinalReportMissing': True}
with output.open('x') as stream:json.dump(report, stream, indent=2);stream.write('\n')
trial = base / 'go-corpus-cloudflare-retained-warm-1-run'
command = ['devtools', 'run', 'preflight:perf', '--output', str(trial), '--timeout', '600', '--max-rss-mib', str(hard), '--input', str(Path(__file__).resolve()), '--input', str(output), '--input', str(module / 'go.mod'), '--input', str(module / 'cloudflare_http_test.go'), '--', sys.executable, '-B', str(helpers / 'go-build-observer.py'), '--memory-details', '--output', str(base / 'go-corpus-cloudflare-retained-warm-1-processes.jsonl'), '--', 'go', '-C', str(module), 'test', '-p=1', '-count=1', '-timeout=8m', '-run', '^TestCloudflareHTTPContract$', './...']
code = subprocess.call(command, cwd=root, env=os.environ | {'GOMEMLIMIT': '3GiB', 'GOGC': '100', 'GODEBUG': '', 'GOFLAGS': '', 'GOEXPERIMENT': '', 'CGO_ENABLED': '0', 'GOWORK': 'off', 'GOPROXY': 'off', 'GOSUMDB': 'off'})
record = json.loads((trial / 'result.json').read_text())
report.update(status='pass' if code == 0 and record['status'] == 'pass' else 'fail', recorderStatus=record['status'], recorderResultSha256=sha(trial / 'result.json'))
assert sha(module / 'go.mod') == report['goModuleSha256'] and sha(module / 'cloudflare_http_test.go') == report['httpFixtureSha256']
output.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({key: report[key] for key in ['status', 'recorderStatus', 'generationAuditorFinalReportMissing', 'scope']}), flush=True)
raise SystemExit(0 if report['status'] == 'pass' else 1)
