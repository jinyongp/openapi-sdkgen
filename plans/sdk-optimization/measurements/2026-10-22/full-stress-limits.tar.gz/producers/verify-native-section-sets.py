"""Compare all native C membership literals with the frozen declaration oracle."""
import argparse,hashlib,json,re
from pathlib import Path
root=Path('/home/jinyongp/workspace/jinyongp/openapi-sdkgen');base=root/'.tmp/sdk-optimization-execution'
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--sdk',type=Path,default=base/'graph-ts-section-index')
parser.add_argument('--output',type=Path,default=base/'graph-ts-section-index-membership.json')
args=parser.parse_args();sdk=args.sdk.resolve();oracle=base/'graph-ts-flat-root/internal/routes/diagnostic-section-index.ts'
fixture=base/'graph-ts-section-index-probe/fixture.json';metadata=json.loads(fixture.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(oracle)==metadata['sourceSha256']
names=['RouteSourcesBySection','OperationIDsBySection','ResourceRoutesBySection']
sections=['path','query','querystring','header','cookie','body']
def index(text,name):
    match=re.search(r'^(?:export )?interface '+name+r' \{\n(.*?)^\}',text,re.M|re.S)
    assert match,'missing interface '+name
    result={}
    for line in match[1].splitlines():
        field=re.fullmatch(r'  readonly (\w+): (.*)',line);assert field,line
        section,value=field.groups();assert section in sections and section not in result
        keys=[]
        if value!='never':
            while value:
                key,end=json.JSONDecoder().raw_decode(value);assert isinstance(key,str);keys.append(key)
                value=value[end:].strip()
                if value:assert value.startswith('|');value=value[1:].strip();assert value
        assert len(keys)==len(set(keys)),'duplicate membership in '+name
        result[section]=set(keys)
    assert set(result)==set(sections)
    return result
expected={name:index(oracle.read_text(),'Diagnostic'+name) for name in names}
actual={name:{section:set() for section in sections} for name in names}
manifest=sdk/'.openapi-sdkgen-manifest.json';owned=json.loads(manifest.read_text())['files']
parts=[]
for name,digest in owned.items():
    if not name.startswith('internal/routes/contracts/') or not name.endswith('.ts'):continue
    file=sdk/name;assert sha(file)==digest,'stale/unowned contract part';text=file.read_text()
    for contract in names:
        members=index(text,contract)
        for section in sections:
            assert not actual[contract][section]&members[section],'duplicate part ownership'
            actual[contract][section]|=members[section]
    parts.append({'path':name,'sha256':digest})
assert parts,'native C contract parts absent'
for name in names:
    for section in sections:
        assert actual[name][section]==expected[name][section],(name,section,len(actual[name][section]^expected[name][section]))
report={'status':'pass','scope':'all route/ID/resource membership sets match frozen original operation declarations; not compiler/runtime proof','sourceManifestSha256':sha(manifest),'oracleSourceSha256':sha(oracle),'oracleFixtureSha256':sha(fixture),'parts':parts,'counts':{name:{section:len(actual[name][section]) for section in sections} for name in names}}
out=args.output
with out.open('x') as stream:json.dump(report,stream,indent=2);stream.write('\n')
print(json.dumps({k:report[k] for k in ['status','scope','counts']}))
