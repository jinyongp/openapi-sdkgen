import argparse,json,os,re,subprocess,time
from pathlib import Path
parser=argparse.ArgumentParser()
parser.add_argument('--output',type=Path,required=True)
parser.add_argument('--memory-details',action='store_true',help='also sample owned process virtual/data/swap bytes; no environment or foreign process details')
parser.add_argument('command',nargs=argparse.REMAINDER)
args=parser.parse_args()
command=args.command[1:] if args.command[:1]==['--'] else args.command
if not command:parser.error('build command required')
session=os.getsid(0)
started=time.monotonic()
with args.output.open('x') as log:
    def write(value):log.write(json.dumps({'elapsedSeconds':time.monotonic()-started,**value})+'\n');log.flush()
    process=subprocess.Popen(command)
    write({'event':'started','scope':'owned session compiler package/RSS sampling; no compiler arguments or environment logged'})
    previous=None
    while process.poll() is None:
        rows=[]
        for file in Path('/proc').glob('[0-9]*/stat'):
            try:
                fields=file.read_text().rsplit(')',1)[1].split()
                if int(fields[3])!=session:continue
                argv=[os.fsdecode(s) for s in (file.parent/'cmdline').read_bytes().split(b'\0') if s]
                if not argv:continue
                name=Path(argv[0]).name
                expanded=argv
                if name=='compile':
                    for argument in argv[1:]:
                        if argument.startswith('@'):
                            with Path(argument[1:]).open() as response:
                                expanded=[line.rstrip('\n') for _,line in zip(range(100),response)]
                            break
                package=None
                if name=='compile':
                    package=expanded[expanded.index('-p')+1] if '-p' in expanded else next((value[3:] for value in expanded if value.startswith('-p=')),None)
                if package:
                    package=package.strip('"')
                    if not re.fullmatch(r'[A-Za-z0-9_./-]+',package):package='unparsed'
                if name in ('go','compile','link'):
                    row={'pid':int(file.parent.name),'tool':name,'package':package,'rssBytes':int(fields[21])*os.sysconf('SC_PAGE_SIZE')}
                    if args.memory_details:
                        status={line.split(':',1)[0]:line.split(':',1)[1].split() for line in (file.parent/'status').read_text().splitlines() if ':' in line}
                        for source,target in [('VmSize','virtualBytes'),('VmData','dataBytes'),('VmSwap','swapBytes')]:
                            if source in status:row[target]=int(status[source][0])*1024
                    rows.append(row)
            except (OSError,ValueError,IndexError):continue
        identity=[(row['pid'],row['tool'],row['package']) for row in rows]
        write({'event':'sample','processes':rows,'membershipChanged':identity!=previous})
        previous=identity
        time.sleep(1)
    write({'event':'finished','exitCode':process.returncode})
raise SystemExit(process.returncode)
