"""Replay an already recorded manifest comparison; added later, not the original producer."""
import argparse, hashlib, json
from pathlib import Path
parser = argparse.ArgumentParser()
parser.add_argument('old', type=Path); parser.add_argument('new', type=Path)
args = parser.parse_args()
def read(root): return json.loads((root / '.openapi-sdkgen-manifest.json').read_text())['files']
old, new = read(args.old), read(args.new)
assert old.keys() == new.keys()
changed = [name for name in new if old[name] != new[name]]
old_fingerprint = 'ce9cc3c2b1d5d277767b7985ffda5093ff337e5acaf4b79c54099f9fcbc73553'
new_fingerprint = 'd31a71b84b8a1a105da2f593b1cd52ec9f1d8fe403d527de4f4b8fbac5ae6405'
structural, fingerprint, unexpected = [], [], []
for name in changed:
    before, after = (args.old / name).read_bytes(), (args.new / name).read_bytes()
    assert hashlib.sha256(before).hexdigest() == old[name] and hashlib.sha256(after).hexdigest() == new[name]
    if name.startswith('internal/routes/contracts/') or name in ['internal/routes/index.ts', 'internal/client/types.ts', 'internal/client/registry-contracts.ts']:
        structural.append(name)
    elif before.replace(old_fingerprint.encode(), new_fingerprint.encode()) == after:
        fingerprint.append(name)
    else: unexpected.append(name)
assert len(structural) == 119 and len(fingerprint) == 88744 and not unexpected
print(json.dumps({'status': 'pass', 'changedFiles': len(changed), 'structuralFiles': len(structural), 'fingerprintOnlyFiles': len(fingerprint), 'unexpected': unexpected}))
