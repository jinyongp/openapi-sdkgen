"""Retry only the unresolved native Go corpus member, preserving original failures."""
import hashlib, json, os, subprocess, sys
from pathlib import Path

root = Path('/home/jinyongp/workspace/jinyongp/openapi-sdkgen')
base = root / '.tmp/sdk-optimization-execution'
helpers = root / '.tmp/sdk-optimization-execution-helpers'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
trial = base / 'go-corpus-cloudflare-full-retry-1'
output = base / 'go-corpus-cloudflare-full-retry-1-report.json'
assert not trial.exists() and not output.exists(), 'completed or active trial must not be overwritten'
assert (base / 'operation-contract-projection-unit-1/result.json').exists(), 'serial TS contract tests must end first'
available = int(next(line.split()[1] for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:'))) // 1024
hard = min(11832, available - 2048)
assert hard >= 10240, '10GiB minimum plus 2GiB headroom unavailable; no child started'
previous = json.loads((base / 'go-corpus-candidate-22/source.json').read_text())
tracked = subprocess.check_output(['git', 'ls-files', 'cmd', 'internal', 'scripts/golang-compat', 'go.mod', 'go.sum'], cwd=root, text=True).splitlines()
current = {name: sha(root / name) for name in tracked}
prior = {name: digest for name, digest in previous.items() if name.startswith(('cmd/', 'internal/', 'scripts/golang-compat/')) or name in ['go.mod', 'go.sum']}
assert current.keys() == prior.keys()
reuse_path = base / 'go-corpus-typescript-emitter-reuse-2.json'
reuse = json.loads(reuse_path.read_text())
changed = {name for name in current if current[name] != prior[name]}
assert reuse['status'] == 'pass' and changed == set(reuse['reviewedUnreachableTypeScriptEmitterChanges'])
assert all(current[name] == row['current'] and prior[name] == row['previous'] for name, row in reuse['reviewedUnreachableTypeScriptEmitterChanges'].items())
assert all(sha(root / name) == digest for name, digest in reuse['unchangedGoDependencyFiles'].items())
binary = base / 'go-corpus-candidate/golang-compat'
old_result = json.loads((base / 'go-corpus-candidate-22/result.json').read_text())
assert sha(binary) == old_result['binaries'][str(binary)]
manifest = base / 'go-corpus-candidate-verified/regression.json'
entry = next(row for row in json.loads(manifest.read_text())['corpora'] if row['id'] == 'cloudflare')
corpus = root / '.tmp/compatibility-regression'
document = corpus / entry['input']
assert sha(document) == entry['sha256']
command = ['devtools', 'run', 'preflight:perf', '--output', str(trial), '--timeout', '4500', '--max-rss-mib', str(hard), '--input', str(Path(__file__).resolve()), '--input', str(manifest), '--input', str(reuse_path), '--', str(binary), '--mode', 'golang-generation', '--verify', '--server', '--manifest', str(manifest), '--corpus-root', str(corpus), '--document', 'cloudflare', '--output', str(output)]
code = subprocess.call(command, cwd=root, env=os.environ | {'GOMEMLIMIT': '3GiB'})
assert {name: sha(root / name) for name in tracked} == current
if code:
    raise SystemExit(code)
report = json.loads(output.read_text())
record = json.loads((trial / 'result.json').read_text())
assert record['status'] == 'pass' and report['pass'] is True
assert report['inputSha256'] == sha(document) and report['addons'] == ['server'] and report['verificationRequested'] is True
assert report['goVersion'] == 'go1.27.2'
assert report['goCompilationPolicy'] == {'timeoutSeconds': 3600, 'buildParallelism': 1, 'cpuConcurrency': 4, 'memoryLimit': '6GiB'}
assert report['golang']['compilation']['status'] == 'pass'
assert report['golang']['compilation']['contractTests'] == ['TestCloudflareHTTPContract']
print(json.dumps({'status': 'pass', 'scope': 'Cloudflare native generation/full compile/server HTTP; separate Graph and final corpus aggregation still required', 'trial': str(trial), 'report': str(output)}), flush=True)
