"""Preserve ended full-size trials as optional limit evidence without running another one."""
import hashlib, io, json, tarfile
from pathlib import Path
root = Path('/home/jinyongp/workspace/jinyongp/openapi-sdkgen')
base = root / '.tmp/sdk-optimization-execution'
helpers = root / '.tmp/sdk-optimization-execution-helpers'
destination = root / 'plans/sdk-optimization/measurements/2026-10-22/full-stress-limits.tar.gz'
assert not destination.exists()
def sha(path):
    with path.open('rb') as stream: return hashlib.file_digest(stream, 'sha256').hexdigest()
files = {}; outcomes = {}
def add_tree(directory, prefix):
    for path in directory.rglob('*'):
        if path.is_file():
            assert not path.is_symlink(); files[prefix + '/' + str(path.relative_to(directory))] = path
for name in ['graph-ts-operation-contracts-generation', 'graph-ts-operation-contracts-source-config', 'graph-ts-operation-contracts-inventory-run', 'graph-ts-operation-contracts-project-plan-run', 'graph-ts-operation-contracts-membership-run', 'graph-ts-operation-contracts-native-full-1-run', 'go-corpus-cloudflare-full-retry-1', 'go-corpus-cloudflare-retained-warm-1-run', 'go-corpus-cloudflare-retained-warm-2-run']:
    directory = base / name; report = json.loads((directory / 'result.json').read_text())
    outcomes[name] = {key: report[key] for key in ['status', 'elapsedSeconds', 'peakSessionRSSBytes', 'rssLimitMiB'] if key in report}
    add_tree(directory, 'trials/' + name)
check = base / 'graph-ts-operation-contracts-native-full-1'
files['checker/result.json'] = check / 'result.json'
add_tree(check / 'configs', 'checker/configs')
for project in sorted(check.glob('project-*')): add_tree(project, 'checker/' + project.name)
for name in ['graph-ts-operation-contracts-inventory', 'graph-ts-operation-contracts-project-plan']:
    add_tree(base / name, 'ownership/' + name)
for name in ['graph-ts-operation-contracts-membership.json', 'graph-ts-operation-contracts-output-diff.json', 'go-corpus-cloudflare-retained-warm-1.json', 'go-corpus-cloudflare-retained-warm-2.json', 'go-corpus-cloudflare-retained-warm-2-basis.json', 'go-corpus-cloudflare-retained-warm-2-processes.jsonl', 'go-corpus-typescript-emitter-reuse-2.json']:
    files['reports/' + name] = base / name
for variant in ['graph-ts-named-resource-bases', 'graph-ts-operation-contracts']:
    files['manifests/' + variant + '.json'] = base / variant / '.openapi-sdkgen-manifest.json'
for name in ['prepare-operation-contract-graph.py', 'check-operation-contract-graph-native.py', 'bound-optional-graph-check.py', 'verify-native-section-sets.py', 'retry-cloudflare-full.py', 'verify-cloudflare-retained-warm.py', 'verify-cloudflare-retained-warm-2.py', 'go-build-observer.py', 'replay-operation-contract-output-diff.py', Path(__file__).name]:
    files['producers/' + name] = helpers / name
index = {'scope': 'optional full Graph/Cloudflare failure and source-ownership evidence; not mandatory selected SDK acceptance', 'outcomes': outcomes, 'files': {name: {'bytes': path.stat().st_size, 'sha256': sha(path)} for name, path in sorted(files.items())}, 'replayHelper': 'replay-operation-contract-output-diff.py was added after the original inline read-only comparison; it is a replay recipe, not the original executed producer.', 'excluded': ['Full mechanically generated Graph/Cloudflare trees, emitted declarations/build-info and executables. Their exact input/source/ownership/manifest and binary hashes are retained; this archive alone does not contain all compiler input bytes.', 'Private task contexts and active final integration trial were not selected.'], 'classification': {'fullGraph': '20 of 29 projects completed, next project RSS protection; no final public consumer success', 'cloudflareFull': 'RSS protection; generation completed, compilation/HTTP not proved; final auditor report absent', 'cloudflareWarm1': 'Preflight toolchain resolution blocked by misplaced GOSUMDB=off; no compiler ran', 'cloudflareWarm2': 'Actual retained identical module; internal/operations compiler RSS protection; no final HTTP success'}}
with tarfile.open(destination, 'w:gz', compresslevel=6) as archive:
    for name, path in sorted(files.items()): archive.add(path, arcname=name, recursive=False)
    data = (json.dumps(index, indent=2) + '\n').encode(); entry = tarfile.TarInfo('index.json'); entry.size = len(data); entry.mode = 0o600
    archive.addfile(entry, io.BytesIO(data))
with tarfile.open(destination) as archive:
    assert json.load(archive.extractfile('index.json')) == index
    for name, row in index['files'].items():
        data = archive.extractfile(name).read(); assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
print(json.dumps({'archive': str(destination), 'bytes': destination.stat().st_size, 'sha256': sha(destination), 'entries': len(files) + 1, 'verified': True}), flush=True)
