"""Retry the preflight-blocked attempt; one actual warm compiler budget remains."""
import hashlib, json, os, subprocess, sys
from pathlib import Path

root = Path('/home/jinyongp/workspace/jinyongp/openapi-sdkgen')
base = root / '.tmp/sdk-optimization-execution'
helpers = root / '.tmp/sdk-optimization-execution-helpers'
module = Path('/tmp/sdkgen-compat-3271393760')
original = base / 'go-corpus-cloudflare-rss-input'
sha = lambda p: hashlib.file_digest(p.open('rb'), 'sha256').hexdigest()
previous = json.loads((base / 'go-corpus-cloudflare-retained-warm-1-run/result.json').read_text())
assert previous['status'] == 'blocked', 'only a preflight-blocked trial may be retried here'
report = json.loads((base / 'go-corpus-cloudflare-retained-warm-1.json').read_text())
entries = [json.loads(line) for line in (original / 'files.jsonl').read_text().splitlines()]
assert {str(p.relative_to(module / 'api')) for p in (module / 'api').rglob('*') if p.is_file()} == {row['path'] for row in entries}
for entry in entries:
    path = module / 'api' / entry['path']; assert not path.is_symlink() and path.stat().st_size == entry['bytes'] and sha(path) == entry['sha256']
assert sha(module / 'go.mod') == report['goModuleSha256'] and sha(module / 'cloudflare_http_test.go') == report['httpFixtureSha256']
available = int(next(line.split()[1] for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:'))) // 1024
hard = min(11832, available - 2048)
assert hard >= 10240, '10GiB plus2GiB headroom unavailable; compiler not started'
for name in ['recorderStatus', 'recorderResultSha256']:
    report.pop(name, None)
report.update(status='incomplete', priorPreflightBlockedWithoutCompiler=True)
report['policy']['rssLimitMiB'] = hard
basis = base / 'go-corpus-cloudflare-retained-warm-2-basis.json'
with basis.open('x') as stream:json.dump(report, stream, indent=2);stream.write('\n')
trial = base / 'go-corpus-cloudflare-retained-warm-2-run'
command = ['devtools', 'run', 'preflight:perf', '--output', str(trial), '--timeout', '600', '--max-rss-mib', str(hard), '--input', str(Path(__file__).resolve()), '--input', str(basis), '--input', str(module / 'go.mod'), '--input', str(module / 'cloudflare_http_test.go'), '--', sys.executable, '-B', str(helpers / 'go-build-observer.py'), '--memory-details', '--output', str(base / 'go-corpus-cloudflare-retained-warm-2-processes.jsonl'), '--', 'env', 'GOPROXY=off', 'GOSUMDB=off', 'go', '-C', str(module), 'test', '-p=1', '-count=1', '-timeout=8m', '-run', '^TestCloudflareHTTPContract$', './...']
environment = os.environ | {'GOMEMLIMIT': '3GiB', 'GOGC': '100', 'GODEBUG': '', 'GOFLAGS': '', 'GOEXPERIMENT': '', 'CGO_ENABLED': '0', 'GOWORK': 'off'}
environment.pop('GOPROXY', None); environment.pop('GOSUMDB', None)
code = subprocess.call(command, cwd=root, env=environment)
record = json.loads((trial / 'result.json').read_text())
report.update(status='pass' if code == 0 and record['status'] == 'pass' else 'fail', recorderStatus=record['status'], recorderResultSha256=sha(trial / 'result.json'))
assert sha(module / 'go.mod') == report['goModuleSha256'] and sha(module / 'cloudflare_http_test.go') == report['httpFixtureSha256']
output = base / 'go-corpus-cloudflare-retained-warm-2.json'
with output.open('x') as stream:json.dump(report, stream, indent=2);stream.write('\n')
print(json.dumps({key: report[key] for key in ['status', 'recorderStatus', 'generationAuditorFinalReportMissing', 'scope']}), flush=True)
raise SystemExit(0 if report['status'] == 'pass' else 1)
