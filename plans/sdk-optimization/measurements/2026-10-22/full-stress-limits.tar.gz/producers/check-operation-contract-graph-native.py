"""Whole-source strict/declaration/public check; keep the original 3600s budget."""
import json, os, subprocess, sys
from pathlib import Path

root = Path('/home/jinyongp/workspace/jinyongp/openapi-sdkgen')
base = root / '.tmp/sdk-optimization-execution'
helpers = root / '.tmp/sdk-optimization-execution-helpers'
for name in ['graph-ts-operation-contracts-generation', 'graph-ts-operation-contracts-source-config', 'graph-ts-operation-contracts-inventory-run', 'graph-ts-operation-contracts-project-plan-run', 'graph-ts-operation-contracts-membership-run']:
    assert json.loads((base / name / 'result.json').read_text())['status'] == 'pass', 'preparation incomplete: ' + name
available = int(next(line.split()[1] for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:'))) // 1024
assert available >= 12288, '10GiB minimum hard budget plus 2GiB headroom unavailable; no compiler started'
name = 'graph-ts-operation-contracts-native-full-1'
command = [sys.executable, '-B', str(helpers / 'run-trial.py'), str(base / (name + '-run')), '3700', '3072', sys.executable, '-B', 'scripts/perf/sdk-optimization/check-projects.py', '--plan', str(base / 'graph-ts-operation-contracts-project-plan/plan.json'), '--output', str(base / name), '--compiler', 'test/typescript/node_modules/typescript/lib/tsc.js', '--reference', str(base / 'graph-public-contract-v2.json'), '--usage-consumer', 'plans/sdk-optimization/probes/graph-public-usage.mts', '--max-rss-mib', '12288', '--node-heap-mib', '11264', '--timeout', '3600', '--remove-declaration-comments', '--isolated-declarations']
raise SystemExit(subprocess.call(command, cwd=root, env=os.environ | {'GOMEMLIMIT': '6GiB', 'GOGC': '100', 'GOMAXPROCS': '4', 'GODEBUG': ''}))
