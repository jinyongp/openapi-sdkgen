"""Collect at most five more minutes after the user's explicit Graph scope change."""
import json, os, signal, time
from pathlib import Path

root = Path('/home/jinyongp/workspace/jinyongp/openapi-sdkgen')
output = root / '.tmp/sdk-optimization-execution/graph-ts-operation-contracts-native-full-1'
deadline = 1792637040.1363466 + 300
while not (output / 'result.json').exists() and time.time() < deadline:
    time.sleep(1)
if (output / 'result.json').exists():
    print(json.dumps({'action': 'completed_before_scope_deadline', 'result': str(output / 'result.json')}), flush=True)
    raise SystemExit(0)
groups = set()
for stat in Path('/proc').glob('[0-9]*/stat'):
    try:
        args = [os.fsdecode(part) for part in (stat.parent / 'cmdline').read_bytes().split(b'\0') if part]
        if not any(arg.startswith(str(output / 'configs') + '/') for arg in args):
            continue
        values = stat.read_text().rsplit(')', 1)[1].split()
        group, session = int(values[2]), int(values[3])
        assert group == session and group != os.getpgrp(), 'unexpected compiler process ownership'
        groups.add(group)
    except (OSError, ValueError):
        continue
assert len(groups) <= 1, 'ambiguous active compiler; no process stopped'
note = output / 'user-scope-cancellation.json'
with note.open('x') as stream:
    json.dump({'scope': 'user approved full Graph as optional stress reference, no further full Graph gate', 'reason': 'five-minute result collection after the explicit scope decision exhausted', 'classifiedAs': 'user_scope_change_interruption; not compiler error, natural timeout, RSS protection or a pass', 'signal': 'SIGTERM', 'ownedProcessGroups': sorted(groups), 'time': time.time()}, stream, indent=2)
    stream.write('\n')
for group in groups:
    try:
        os.killpg(group, signal.SIGTERM)
    except ProcessLookupError:
        pass
print(json.dumps({'action': 'stopped_owned_optional_compiler', 'groups': sorted(groups), 'note': str(note)}), flush=True)
