import type { Client, OperationRoutes, OperationMethod } from "../api/index.js";
type Equal<A, B> = [A] extends [B] ? [B] extends [A] ? true : false : false;
type Assert<T extends true> = T;
type Expected_routes = "POST /auth/poll" | "POST /auth/start" | "GET /auth/validate" | "POST /scrobble/episodes" | "PUT /scrobble/episodes/{episode_id}" | "POST /scrobble/shows" | "GET /scrobble/shows/{show_id}" | "GET /user/episodes" | "DELETE /user/episodes/{episode_id}" | "GET /user/episodes/{episode_id}" | "PUT /user/episodes/{episode_id}" | "GET /user/follows/networks" | "DELETE /user/follows/networks/{network_id}" | "GET /user/follows/networks/{network_id}" | "PUT /user/follows/networks/{network_id}" | "GET /user/follows/people" | "DELETE /user/follows/people/{person_id}" | "GET /user/follows/people/{person_id}" | "PUT /user/follows/people/{person_id}" | "GET /user/follows/shows" | "DELETE /user/follows/shows/{show_id}" | "GET /user/follows/shows/{show_id}" | "PUT /user/follows/shows/{show_id}" | "GET /user/follows/webchannels" | "DELETE /user/follows/webchannels/{webchannel_id}" | "GET /user/follows/webchannels/{webchannel_id}" | "PUT /user/follows/webchannels/{webchannel_id}" | "GET /user/tags" | "POST /user/tags" | "DELETE /user/tags/{tag_id}" | "PATCH /user/tags/{tag_id}" | "GET /user/tags/{tag_id}/shows" | "DELETE /user/tags/{tag_id}/shows/{show_id}" | "PUT /user/tags/{tag_id}/shows/{show_id}" | "GET /user/votes/episodes" | "DELETE /user/votes/episodes/{episode_id}" | "GET /user/votes/episodes/{episode_id}" | "PUT /user/votes/episodes/{episode_id}" | "GET /user/votes/shows" | "DELETE /user/votes/shows/{show_id}" | "GET /user/votes/shows/{show_id}" | "PUT /user/votes/shows/{show_id}";
export type Check_routes = Assert<Equal<keyof Client["$routes"], Expected_routes>>;
type Expected_operations = never;
export type Check_operations = Assert<Equal<keyof Client["$operations"], Expected_operations>>;
interface ExpectedOperationRoutes {

}
export type CheckOperationRoutes = Assert<Equal<OperationRoutes, ExpectedOperationRoutes>>;
interface ExpectedLegacyRouteCalls {
readonly "POST /auth/poll": OperationMethod<"POST /auth/poll">;
readonly "POST /auth/start": OperationMethod<"POST /auth/start">;
readonly "GET /auth/validate": OperationMethod<"GET /auth/validate">;
readonly "POST /scrobble/episodes": OperationMethod<"POST /scrobble/episodes">;
readonly "PUT /scrobble/episodes/{episode_id}": OperationMethod<"PUT /scrobble/episodes/{episode_id}">;
readonly "POST /scrobble/shows": OperationMethod<"POST /scrobble/shows">;
readonly "GET /scrobble/shows/{show_id}": OperationMethod<"GET /scrobble/shows/{show_id}">;
readonly "GET /user/episodes": OperationMethod<"GET /user/episodes">;
readonly "DELETE /user/episodes/{episode_id}": OperationMethod<"DELETE /user/episodes/{episode_id}">;
readonly "GET /user/episodes/{episode_id}": OperationMethod<"GET /user/episodes/{episode_id}">;
readonly "PUT /user/episodes/{episode_id}": OperationMethod<"PUT /user/episodes/{episode_id}">;
readonly "GET /user/follows/networks": OperationMethod<"GET /user/follows/networks">;
readonly "DELETE /user/follows/networks/{network_id}": OperationMethod<"DELETE /user/follows/networks/{network_id}">;
readonly "GET /user/follows/networks/{network_id}": OperationMethod<"GET /user/follows/networks/{network_id}">;
readonly "PUT /user/follows/networks/{network_id}": OperationMethod<"PUT /user/follows/networks/{network_id}">;
readonly "GET /user/follows/people": OperationMethod<"GET /user/follows/people">;
readonly "DELETE /user/follows/people/{person_id}": OperationMethod<"DELETE /user/follows/people/{person_id}">;
readonly "GET /user/follows/people/{person_id}": OperationMethod<"GET /user/follows/people/{person_id}">;
readonly "PUT /user/follows/people/{person_id}": OperationMethod<"PUT /user/follows/people/{person_id}">;
readonly "GET /user/follows/shows": OperationMethod<"GET /user/follows/shows">;
readonly "DELETE /user/follows/shows/{show_id}": OperationMethod<"DELETE /user/follows/shows/{show_id}">;
readonly "GET /user/follows/shows/{show_id}": OperationMethod<"GET /user/follows/shows/{show_id}">;
readonly "PUT /user/follows/shows/{show_id}": OperationMethod<"PUT /user/follows/shows/{show_id}">;
readonly "GET /user/follows/webchannels": OperationMethod<"GET /user/follows/webchannels">;
readonly "DELETE /user/follows/webchannels/{webchannel_id}": OperationMethod<"DELETE /user/follows/webchannels/{webchannel_id}">;
readonly "GET /user/follows/webchannels/{webchannel_id}": OperationMethod<"GET /user/follows/webchannels/{webchannel_id}">;
readonly "PUT /user/follows/webchannels/{webchannel_id}": OperationMethod<"PUT /user/follows/webchannels/{webchannel_id}">;
readonly "GET /user/tags": OperationMethod<"GET /user/tags">;
readonly "POST /user/tags": OperationMethod<"POST /user/tags">;
readonly "DELETE /user/tags/{tag_id}": OperationMethod<"DELETE /user/tags/{tag_id}">;
readonly "PATCH /user/tags/{tag_id}": OperationMethod<"PATCH /user/tags/{tag_id}">;
readonly "GET /user/tags/{tag_id}/shows": OperationMethod<"GET /user/tags/{tag_id}/shows">;
readonly "DELETE /user/tags/{tag_id}/shows/{show_id}": OperationMethod<"DELETE /user/tags/{tag_id}/shows/{show_id}">;
readonly "PUT /user/tags/{tag_id}/shows/{show_id}": OperationMethod<"PUT /user/tags/{tag_id}/shows/{show_id}">;
readonly "GET /user/votes/episodes": OperationMethod<"GET /user/votes/episodes">;
readonly "DELETE /user/votes/episodes/{episode_id}": OperationMethod<"DELETE /user/votes/episodes/{episode_id}">;
readonly "GET /user/votes/episodes/{episode_id}": OperationMethod<"GET /user/votes/episodes/{episode_id}">;
readonly "PUT /user/votes/episodes/{episode_id}": OperationMethod<"PUT /user/votes/episodes/{episode_id}">;
readonly "GET /user/votes/shows": OperationMethod<"GET /user/votes/shows">;
readonly "DELETE /user/votes/shows/{show_id}": OperationMethod<"DELETE /user/votes/shows/{show_id}">;
readonly "GET /user/votes/shows/{show_id}": OperationMethod<"GET /user/votes/shows/{show_id}">;
readonly "PUT /user/votes/shows/{show_id}": OperationMethod<"PUT /user/votes/shows/{show_id}">;
}
interface ExpectedLegacyOperationCalls {

}
export type CheckLegacyRouteCalls = Assert<Equal<Client["$routes"], ExpectedLegacyRouteCalls>>;
export type CheckLegacyOperationCalls = Assert<Equal<Client["$operations"], ExpectedLegacyOperationCalls>>;
export type CheckAbsentLinks = Assert<Equal<Extract<"$links", keyof Client>, never>>;
declare const client: Client;
// @ts-expect-error unknown operation must stay rejected
client.$operations.__sdkgen_missing_operation_contract__;
// @ts-expect-error unknown exact route must stay rejected
client.$routes["GET /__sdkgen_missing_route_contract__"];
