module example.test/matched

go 1.27.0
