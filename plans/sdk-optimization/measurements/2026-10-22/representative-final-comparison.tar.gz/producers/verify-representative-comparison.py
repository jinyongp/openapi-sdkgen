"""Verify the complete matched study and preserve its reproducible evidence."""
import hashlib
import io
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import tarfile

ROOT = Path.cwd()
STUDY = ROOT / '.tmp/sdk-representative-final'
OUT = STUDY / 'verification'
OUT.mkdir(exist_ok=False)


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def dump(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


provenance = json.loads((STUDY / 'provenance.json').read_text())
summary = json.loads((STUDY / 'summary.json').read_text())
rows = json.loads((STUDY / 'trials.json').read_text())
assert provenance['status'] == summary['status'] == 'pass'
assert len(rows) == 180 and summary['failures'] == 0
assert len(summary['inventories']) == 60
assert len({(r['provider'], r['target'], r['pair'], r['variant'], r['phase']) for r in rows}) == 180
assert sha(ROOT / 'scripts/perf/sdk-optimization/compare-apis.py') == provenance['producerSha256']
assert sha(ROOT / 'scripts/perf/sdk-optimization/record.py') == provenance['recorderSha256']
before = json.loads((STUDY / 'recovery/before-trials.json').read_text())
assert len(before) == 171 and rows[:len(before)] == before
assert sha(ROOT / 'scripts/perf/sdk-optimization/resume-apis.py') == provenance['recovery']['producerSha256']
assert provenance['recovery']['workerSha256'] == provenance['producerSha256']
for variant, revision in provenance['revisions'].items():
    assert sha(STUDY / ('sdkgen-' + variant)) == provenance[variant]['binarySha256']
    archive = subprocess.check_output(['git', 'archive', revision, 'cmd', 'internal', 'go.mod', 'go.sum'])
    assert hashlib.sha256(archive).hexdigest() == provenance[variant]['archiveSha256']
    with tarfile.open(fileobj=io.BytesIO(archive)) as stream:
        for entry in stream:
            if entry.isfile():
                data = stream.extractfile(entry).read()
                assert (STUDY / (variant + '-source') / entry.name).read_bytes() == data
for value in provenance['inputs'].values():
    assert sha(value['path']) == value['sha256']
for row in rows:
    result = json.loads(Path(row['recorder']).read_text())
    assert result['status'] == row['status'] == 'pass' and row['exitCode'] == result['exitCode'] == 0
    assert row['seconds'] > 0 and row['peakProcessRSSBytes'] > 0
    measured = json.loads(Path(result['argv'][result['argv'].index('_child') + 1]).read_text())
    assert all(row[key] == value for key, value in measured.items())
    assert row['peakSessionRSSBytes'] == result['peakSessionRSSBytes']
    for stream in ['stdout.log', 'stderr.log']:
        assert sha(Path(row['recorder']).with_name(stream)) == result[stream + 'Sha256']

determinism = []
for provider in provenance['inputs']:
    for target in ['typescript', 'golang']:
        for variant in provenance['revisions']:
            first = None
            for pair in range(5):
                case = STUDY / f'{provider}-{target}-{pair}-{variant}'
                sdk = case / 'api'
                files = json.loads((sdk / '.openapi-sdkgen-manifest.json').read_text())['files']
                assert all(sha(sdk / name) == digest for name, digest in files.items())
                if first is None:
                    first = files
                assert files == first, 'managed output differs between repeated generations'
            determinism.append({'provider': provider, 'target': target, 'variant': variant,
                                'repetitions': 5, 'identicalManagedHashes': True})
dump(OUT / 'determinism.json', determinism)

spec = importlib.util.spec_from_file_location('matched_study', ROOT / 'scripts/perf/sdk-optimization/compare-apis.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
without_boundary_pair = [row for row in rows if not
    (row['provider'] == 'github' and row['target'] == 'golang' and row['pair'] == 3)]
dump(OUT / 'recovery-sensitivity.json', {
    'scope': 'Secondary sensitivity only: omit the pair crossing the controller interruption. '
             'Primary results retain all five pairs; no sample selected by timing or performance.',
    'summaries': [item for item in module.summarize(without_boundary_pair)
                  if item['provider'] == 'github' and item['target'] == 'golang']})

auditor = OUT / 'audit-go'
subprocess.run(['go', 'build', '-p=1', '-trimpath', '-buildvcs=false', '-o', str(auditor),
                './scripts/perf/sdk-optimization/audit-go'], check=True)
canonical = ROOT / 'plans/sdk-optimization/go-operation-additions.json'
# Adapt the independently reviewed helper contracts to this study's fixed import root.
# This substitution is fixed before comparison and is not derived from differences.
allowed = json.loads(canonical.read_text().replace('example.test/graph/api', 'example.test/matched/api'))
dump(OUT / 'allowed-additions.json', allowed)
contracts = []
for provider in provenance['inputs']:
    for variant in provenance['revisions']:
        sdk = STUDY / f'{provider}-golang-0-{variant}/api'
        subprocess.run([str(auditor), '-root', str(sdk), '-max-file-bytes', '0',
                        '-output', str(OUT / f'{provider}-{variant}.jsonl')], check=True)
    command = ['python3', '-B', str(ROOT / 'scripts/perf/sdk-optimization/compare-go.py'),
               '--baseline', str(OUT / f'{provider}-baseline.jsonl'),
               '--candidate', str(OUT / f'{provider}-final.jsonl'),
               '--baseline-manifest', str(STUDY / f'{provider}-golang-0-baseline/api/.openapi-sdkgen-manifest.json'),
               '--candidate-manifest', str(STUDY / f'{provider}-golang-0-final/api/.openapi-sdkgen-manifest.json'),
               '--allow-additions', str(OUT / 'allowed-additions.json'),
               '--output', str(OUT / f'{provider}-contracts.json')]
    subprocess.run(command, check=True)
    report = json.loads((OUT / f'{provider}-contracts.json').read_text())
    assert report['differentContracts'] == 0 and len(report['acceptedAdditions']) == 8
    contracts.append({'provider': provider, 'differentExistingContracts': 0, 'acceptedReviewedAdditions': 8})
dump(OUT / 'summary.json', {'status': 'pass', 'successfulMeasuredCommands': 180,
     'determinismGroups': len(determinism), 'goContracts': contracts,
     'canonicalAdditionsSha256': sha(canonical), 'derivedAdditionsSha256': sha(OUT / 'allowed-additions.json'),
     'adaptation': 'Only fixed import root example.test/graph/api -> example.test/matched/api.',
     'scope': 'all emitted managed hashes across repeats; full Go AST contracts; '
              '180 successful generation/typecheck/build commands; no HTTP execution claim'})

destination = ROOT / 'plans/sdk-optimization/measurements/2026-10-22/representative-final-comparison.tar.gz'
assert not destination.exists()
paths = []
for directory, names, files in os.walk(STUDY):
    names[:] = [name for name in names if name not in ['cache', 'baseline-source', 'final-source']]
    if 'api' in Path(directory).relative_to(STUDY).parts:
        names[:] = []
    for filename in files:
        path = Path(directory) / filename
        relative = path.relative_to(STUDY)
        if 'api' in relative.parts:
            if path.name not in ['.openapi-sdkgen-manifest.json', 'tsconfig.optimization.json', 'package.json']:
                continue
        elif path.suffix not in ['.json', '.jsonl', '.log', '.mts', '.mod', '.sum']:
            continue
        paths.append((path, 'study/' + relative.as_posix()))
for name in ['compare-apis.py', 'compare-apis_test.py', 'resume-apis.py', 'record.py', 'prepare-ts.mjs',
             'public-consumer.mjs', 'compare-go.py', 'audit-go/main.go']:
    paths.append((ROOT / 'scripts/perf/sdk-optimization' / name, 'producers/' + name))
paths.append((Path(__file__), 'producers/verify-representative-comparison.py'))
paths.append((canonical, 'producers/canonical-go-additions.json'))
paths.append((ROOT / 'internal/tscheck/strict-options.json', 'producers/strict-options.json'))
for path in (ROOT / '.tmp/sdk-representative-final-record').iterdir():
    if path.is_file():
        paths.append((path, 'outer-record/' + path.name))
for path in (ROOT / '.tmp/sdk-representative-resume-record').iterdir():
    if path.is_file():
        paths.append((path, 'outer-resume-record/' + path.name))
for provider, value in provenance['inputs'].items():
    path = Path(value['path'])
    paths.append((path, 'inputs/' + provider + path.suffix))
index = {'scope': 'Local final/original real-API study; no public Actions benchmark.',
         'exclusions': ['Go caches', 'build-info', 'executables', 'full generated SDK source',
                        'full product source archives recoverable from pinned Git revisions'],
         'entries': [{'path': name, 'bytes': path.stat().st_size, 'sha256': sha(path)} for path, name in paths]}
with tarfile.open(destination, 'w:gz') as archive:
    for path, name in paths:
        archive.add(path, arcname=name, recursive=False)
    data = (json.dumps(index, indent=2) + '\n').encode()
    entry = tarfile.TarInfo('index.json')
    entry.size = len(data)
    archive.addfile(entry, io.BytesIO(data))
with tarfile.open(destination) as archive:
    for row in index['entries']:
        data = archive.extractfile(row['path']).read()
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
print(json.dumps({'status': 'pass', 'archive': str(destination), 'bytes': destination.stat().st_size,
                  'sha256': sha(destination), 'entries': len(index['entries']) + 1}), flush=True)
