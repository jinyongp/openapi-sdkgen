import { createClient, type Client } from "./small-ts/index.js";
const client: Client = createClient({ baseURL: "https://example.test" });
client.$operations.missingOperation;
