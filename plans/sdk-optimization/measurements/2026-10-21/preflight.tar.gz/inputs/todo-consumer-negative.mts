import { createClient, type Client } from "./ts-todo/index.js";
const client: Client = createClient({ baseURL: "https://example.test" });
client.$operations.missingOperation;
