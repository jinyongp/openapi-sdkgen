import { createClient, type Client } from "./small-ts/index.js";
const client: Client = createClient({ baseURL: "https://example.test" });
const call: Client["$operations"]["todo"] = client.$operations.todo;
void call;
