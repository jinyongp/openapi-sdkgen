import { createClient, type Client } from "./ts-todo/index.js";
const client: Client = createClient({ baseURL: "https://example.test" });
const call: Client["$operations"]["listTodos"] = client.$operations.listTodos;
void call;
