"""Retain release/current/previous binaries; clean task-owned build artifacts only."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
keep = {HERE / path for path in ['bin/openapi-sdkgen', 'unit04/bin/openapi-sdkgen', 'unit04/bin/profile-go',
                                 'unit06/bin/openapi-sdkgen', 'unit06/bin/profile-go']}
assert all(p.is_file() and not p.is_symlink() for p in keep)
folders = [HERE / path for path in ['bin', 'unit02/bin', 'unit03/bin', 'unit04/bin',
                                   'unit04/original-source-prototype/bin', 'unit05/bin', 'unit06/bin']]
removed, retained = [], []
paths = set()
for folder in folders:
    for path in folder.rglob('*'):
        if not path.is_file() or path.is_symlink(): continue
        with path.open('rb') as stream:
            if stream.read(4) != b'\x7fELF': continue
        assert path.is_relative_to(HERE)
        paths.add(path)
for path in sorted(paths):
    with path.open('rb') as stream: digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    row = {'path': str(path.relative_to(HERE)), 'bytes': path.stat().st_size, 'sha256': digest}
    if path in keep:
        retained.append(row)
    else:
        removed.append(row)
manifest = HERE / 'unit06/binary-retention.json'
with manifest.open('x') as stream:
    json.dump({'removed': removed, 'retained': retained}, stream, indent=2)
    stream.write('\n')
for row in removed:
    path = HERE / row['path']
    assert path.stat().st_size == row['bytes']
    path.unlink()
print(json.dumps({'removedFiles': len(removed), 'removedBytes': sum(row['bytes'] for row in removed),
                  'retainedFiles': len(retained), 'retainedBytes': sum(row['bytes'] for row in retained)}))
