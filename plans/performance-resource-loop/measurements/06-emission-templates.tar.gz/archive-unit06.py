"""Archive bounded emission-template measurements and compatibility checks."""
import hashlib
import io
import json
from pathlib import Path
import tarfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
files = {HERE / name for name in ['archive-unit06.py', 'run-observed-pair.py',
                                  'verify-observed-unit.py', 'integrate-observed-unit.py',
                                  'clean-obsolete-binaries.py']}
for folder in ['unit06', 'unit04/candidate-generator-build-2', 'unit05/profile',
               'unit05/profile-record', 'unit05/template-allocation-attribution', 'unit05/template-cpu-attribution']:
    for path in (HERE / folder).rglob('*'):
        if path.is_file() and path.relative_to(HERE / folder).parts[0] != 'bin': files.add(path)
for name in ['internal/target/golang/emit.go', 'internal/target/golang/generator_test.go',
             'scripts/perf/sdk-optimization/profile-go/main.go', 'scripts/perf/sdk-optimization/record.py',
             'scripts/perf/sdk-optimization/compare-apis.py']:
    files.add(ROOT / name)
assert not list((HERE / 'unit06').glob('*-pair-*/*/api'))
assert not list((HERE / 'unit06/cli-integration').glob('*/api'))
verification = json.loads((HERE / 'unit06/verification.json').read_text())
assert verification['status'] == 'pass' and verification['samples'] == 10
for provider in ['github', 'tvmaze', 'listennotes']:
    checked = json.loads((HERE / f'unit06/cli-integration/{provider}/verified.json').read_text())
    assert checked['actualOutputMatchesObservedCandidate']
    with (HERE / 'unit06/bin/openapi-sdkgen').open('rb') as stream:
        assert hashlib.file_digest(stream, 'sha256').hexdigest() == checked['candidateBinarySha256']
    source = HERE / f'unit06/{provider}-pair-0/candidate/phases.jsonl.files.jsonl'
    assert hashlib.sha256(source.read_bytes()).hexdigest() == checked['referenceInventorySha256']
for row in json.loads((HERE / 'unit06/binary-retention.json').read_text())['retained']:
    with (HERE / row['path']).open('rb') as stream:
        assert hashlib.file_digest(stream, 'sha256').hexdigest() == row['sha256']
destination = ROOT / 'plans/performance-resource-loop/measurements/06-emission-templates.tar.gz'
index, content, unique_bytes = {}, {}, 0
with tarfile.open(destination, 'x:gz') as archive:
    for path in sorted(files):
        assert not path.is_symlink()
        data = path.read_bytes()
        if path.suffix == '.log': assert not any(line.startswith(b'cpu: ') for line in data.splitlines())
        name = str(path.relative_to(HERE)) if path.is_relative_to(HERE) else 'source/' + str(path.relative_to(ROOT))
        digest = hashlib.sha256(data).hexdigest()
        index[name] = {'bytes': len(data), 'sha256': digest}
        member = tarfile.TarInfo(name)
        member.mode = 0o600
        if digest in content:
            member.type, member.linkname = tarfile.LNKTYPE, content[digest]
            archive.addfile(member)
        else:
            unique_bytes += len(data)
            assert unique_bytes < 64 * 1024**2
            member.size = len(data)
            archive.addfile(member, io.BytesIO(data))
            content[digest] = name
    data = json.dumps(index, indent=2).encode()
    member = tarfile.TarInfo('evidence-index.json')
    member.size, member.mode = len(data), 0o600
    archive.addfile(member, io.BytesIO(data))
with tarfile.open(destination) as archive:
    expected = json.load(archive.extractfile('evidence-index.json'))
    assert len(archive.getmembers()) == len(expected) + 1
    for name, entry in expected.items():
        data = archive.extractfile(name).read()
        assert len(data) == entry['bytes'] and hashlib.sha256(data).hexdigest() == entry['sha256']
print(json.dumps({'entries': len(index), 'uniqueUncompressedBytes': unique_bytes,
                  'bytes': destination.stat().st_size,
                  'sha256': hashlib.sha256(destination.read_bytes()).hexdigest()}))
