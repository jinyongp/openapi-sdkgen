"""Reusable bounded pair for generation observers; never copies Go caches."""
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
PERF = ROOT / 'scripts/perf/sdk-optimization'
sys.dont_write_bytecode = True
spec = importlib.util.spec_from_file_location('fixed_provider_inputs', PERF / 'compare-apis.py')
apis = importlib.util.module_from_spec(spec)
spec.loader.exec_module(apis)


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def inventory(path):
    return {row['path']: (row['bytes'], row['sha256']) for row in
            (json.loads(line) for line in path.read_text().splitlines())}


def main():
    unit, provider, pair, baseline, candidate, frozen = sys.argv[1:]
    pair = int(pair)
    assert re.fullmatch(r'unit[0-9]{2}', unit) and provider in apis.PROVIDERS and 0 <= pair < 5
    binaries = {'baseline': (ROOT / baseline).resolve(), 'candidate': (ROOT / candidate).resolve()}
    assert all(path.is_relative_to(HERE) for path in binaries.values())
    destination = HERE / unit / f'{provider}-pair-{pair}'
    destination.mkdir(exist_ok=False)
    source = ROOT / apis.PROVIDERS[provider][0]
    assert sha(source) == apis.PROVIDERS[provider][1]
    save(destination / 'provenance.json', {'producerSha256': sha(Path(__file__)), 'sourceSha256': sha(source),
         'binaries': {name: {'path': str(path), 'sha256': sha(path)} for name, path in binaries.items()},
         'scope': 'same phase observer without CPU/heap profiling; not pure CLI timings'})
    reference = inventory(ROOT / frozen) if frozen != '-' else None
    rows = []
    for variant in (['baseline', 'candidate'] if pair % 2 == 0 else ['candidate', 'baseline']):
        case = destination / variant
        case.mkdir()
        output, phases, metrics = case / 'api', case / 'phases.jsonl', case / 'metrics.json'
        command = [str(binaries[variant]), '-input', str(source), '-output', str(output), '-report', str(phases)]
        subprocess.run([sys.executable, str(PERF / 'record.py'), '--output', str(case / 'record'),
                        '--timeout', '180', '--max-rss-mib', '3072', '--input', str(Path(__file__)), '--',
                        sys.executable, str(PERF / 'compare-apis.py'), '_child', str(metrics), *command], cwd=ROOT, check=True)
        measured = json.loads(metrics.read_text())
        record = json.loads((case / 'record/result.json').read_text())
        assert measured['exitCode'] == 0 and record['status'] == 'pass'
        checkpoints = [json.loads(line) for line in phases.read_text().splitlines()]
        assert checkpoints[-1]['phase'] == 'publish-finished'
        actual = inventory(Path(str(phases) + '.files.jsonl'))
        if reference is None:
            reference = actual
        assert actual == reference
        managed = json.loads((output / '.openapi-sdkgen-manifest.json').read_text())['files']
        assert managed == {name: entry[1] for name, entry in reference.items()}
        assert all(sha(output / name) == digest for name, digest in managed.items())
        row = {'provider': provider, 'pair': pair, 'variant': variant, **measured,
               'allocatedBytes': checkpoints[-1]['totalAllocBytes'], 'files': len(actual),
               'bytes': checkpoints[-1]['bytes'], 'outputMatches': True}
        save(case / 'verified.json', row)
        shutil.rmtree(output)
        rows.append(row)
        print(json.dumps(row), flush=True)
    save(destination / 'summary.json', {'status': 'pass', 'rows': rows})


if __name__ == '__main__':
    main()
