"""Verify a generation-observer unit and keep runtime source scope explicit."""
import hashlib
import itertools
import json
import math
from pathlib import Path
import statistics
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def load(path):
    return json.loads(path.read_text())


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def main():
    unit, baseline_build, candidate_build = sys.argv[1:4]
    expected_changes = set(sys.argv[4:] or ['internal/target/golang/partition.go'])
    directory = HERE / unit
    rows = []
    for provider, pairs in [('github', 3), ('tvmaze', 1), ('listennotes', 1)]:
        reference = None
        for pair in range(pairs):
            case = directory / f'{provider}-pair-{pair}'
            result, provenance = load(case / 'summary.json'), load(case / 'provenance.json')
            assert result['status'] == 'pass' and len(result['rows']) == 2
            assert provenance['producerSha256'] == sha(HERE / 'run-observed-pair.py')
            for row in result['rows']:
                variant = row['variant']
                child = case / variant
                record = load(child / 'record/result.json')
                assert row == load(child / 'verified.json')
                assert row['pair'] == pair and row['provider'] == provider and row['outputMatches']
                assert record['status'] == 'pass' and record['exitCode'] == row['exitCode'] == 0
                assert all(row[key] == value for key, value in load(child / 'metrics.json').items())
                binary = provenance['binaries'][variant]
                assert sha(Path(binary['path'])) == binary['sha256'] == record['commandFiles'][binary['path']]
                assert record['inputs'][str(HERE / 'run-observed-pair.py')] == provenance['producerSha256']
                assert record['sourceManifestSha256'] == sha(child / 'record/source.json')
                assert all(sha(child / 'record' / name) == record[name + 'Sha256'] for name in ('stdout.log', 'stderr.log'))
                source = Path(record['argv'][record['argv'].index('-input') + 1])
                assert sha(source) == provenance['sourceSha256']
                phases = [json.loads(line) for line in (child / 'phases.jsonl').read_text().splitlines()]
                assert phases[-1]['phase'] == 'publish-finished' and phases[-1]['totalAllocBytes'] == row['allocatedBytes']
                inventory = {entry['path']: (entry['bytes'], entry['sha256']) for entry in
                             (json.loads(line) for line in (child / 'phases.jsonl.files.jsonl').read_text().splitlines())}
                assert len(inventory) == row['files'] and sum(item[0] for item in inventory.values()) == row['bytes']
                if reference is None:
                    reference = inventory
                assert reference == inventory
                rows.append(row)
    assert len(rows) == 10 and len({(r['provider'], r['pair'], r['variant']) for r in rows}) == 10
    baseline, candidate = load(ROOT / baseline_build / 'source.json'), load(ROOT / candidate_build / 'source.json')
    runtime = {name for name in baseline.keys() | candidate.keys() if (name.startswith(('cmd/', 'internal/')) or name in ('go.mod', 'go.sum'))
               and not name.endswith('_test.go')}
    changed = {name for name in runtime if baseline.get(name) != candidate.get(name)}
    assert changed == expected_changes
    observer = 'scripts/perf/sdk-optimization/profile-go/main.go'
    assert baseline[observer] == candidate[observer] == sha(ROOT / observer)
    assert all(sha(ROOT / name) == candidate[name] if name in candidate else not (ROOT / name).exists() for name in runtime)
    summary = {'status': 'pass', 'samples': 10, 'githubPairs': 3, 'smallApiPairs': 2,
               'changedRuntimeFiles': sorted(changed), 'rows': rows}
    for variant in ('baseline', 'candidate'):
        selected = [row for row in rows if row['provider'] == 'github' and row['variant'] == variant]
        summary[variant] = {key: {'median': statistics.median(row[key] for row in selected),
                                 'min': min(row[key] for row in selected), 'max': max(row[key] for row in selected)}
                            for key in ('seconds', 'allocatedBytes', 'peakProcessRSSBytes')}
        summary[variant]['medianCPUSeconds'] = statistics.median(row['userSeconds'] + row['systemSeconds'] for row in selected)
    paired = {variant: sorted([row for row in rows if row['provider'] == 'github' and row['variant'] == variant], key=lambda row: row['pair'])
              for variant in ('baseline', 'candidate')}
    ratios = [b['seconds']/a['seconds'] for a, b in zip(paired['baseline'], paired['candidate'])]
    logs = [math.log(ratio) for ratio in ratios]
    resampled = sorted(math.exp(statistics.mean(values)) for values in itertools.product(logs, repeat=3))
    def percentile(fraction):
        rank = (len(resampled) - 1) * fraction
        low, high = math.floor(rank), math.ceil(rank)
        return resampled[low] + (resampled[high] - resampled[low]) * (rank - low)
    summary['pairedTime'] = {'ratios': ratios, 'geometricMean': math.exp(statistics.mean(logs)),
                             'bootstrapPercentile95Exact27': [percentile(.025), percentile(.975)]}
    with (directory / 'verification.json').open('w') as stream:
        json.dump(summary, stream, indent=2)
        stream.write('\n')
    print(json.dumps({key: value for key, value in summary.items() if key != 'rows'}))


if __name__ == '__main__':
    main()
