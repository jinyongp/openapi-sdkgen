"""Verify retained raw samples and exact output inventories before archiving."""
import hashlib
import itertools
import json
from pathlib import Path
import tarfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def load(path):
    return json.loads(path.read_text())


def main():
    directory = HERE / 'comparison'
    provenance = load(directory / 'provenance.json')
    rows = load(directory / 'trials.json')
    expected = set(itertools.product(provenance['inputs'], range(5), provenance['binaries']))
    assert len(rows) == len(expected) == 30
    assert {(row['provider'], row['pair'], row['variant']) for row in rows} == expected
    for variant, digest in provenance['binaries'].items():
        name = 'openapi-sdkgen' if variant == 'baseline' else 'candidate-sdkgen'
        assert sha(HERE / 'bin' / name) == digest
    for entry in provenance['inputs'].values():
        assert sha(ROOT / entry['path']) == entry['sha256']
    reference = {}
    for row in rows:
        case = directory / f"{row['provider']}-{row['pair']}-{row['variant']}"
        record = load(case / 'record/result.json')
        metrics = load(case / 'metrics.json')
        assert row['recorderExit'] == row['exitCode'] == record['exitCode'] == 0
        assert row['outputMatches'] and record['status'] == 'pass'
        assert all(row[key] == value for key, value in metrics.items())
        assert all(sha(case / 'record' / name) == record[name + 'Sha256'] for name in ('stdout.log', 'stderr.log'))
        assert sha(case / 'record/source.json') == record['sourceManifestSha256']
        assert record['commandFiles'][str(HERE / 'bin' / ('openapi-sdkgen' if row['variant'] == 'baseline' else 'candidate-sdkgen'))] == provenance['binaries'][row['variant']]
        inventory = load(case / 'inventory.json')
        assert len(inventory) == row['files']
        assert inventory == reference.setdefault(row['provider'], inventory)
    with tarfile.open(HERE / 'comparison-before-resume.tar.gz') as archive:
        original = json.load(archive.extractfile('comparison/trials.json'))
        assert hashlib.sha256(archive.extractfile('compare-generation.py').read()).hexdigest() == provenance['producerSha256']
    assert sha(HERE / 'compare-generation.py') == provenance['resumeProducerSha256']
    assert rows[:24] == original[:24]
    excluded = load(directory / 'excluded-attempts.json')['rows']
    assert len(excluded) == 1 and excluded[0]['recorderExit'] == 120 and excluded[0]['exitCode'] == 0
    assert original[-1]['seconds'] == excluded[0]['seconds']
    baseline = load(HERE / 'baseline-build/source.json')
    candidate = load(HERE / 'candidate-build/source.json')
    product = {name for name in baseline if name.startswith(('cmd/', 'internal/')) or name in ('go.mod', 'go.sum')}
    changed = {name for name in product if baseline[name] != candidate[name]}
    assert changed == {'internal/target/golang/partition.go', 'internal/target/golang/partition_test.go'}
    assert all(sha(ROOT / name) == candidate[name] for name in product)
    result = {'status': 'pass', 'samples': len(rows), 'excludedAttempts': len(excluded),
              'preservedOriginalSamples': 24, 'exactInventories': len(reference),
              'productSourceDifferences': sorted(changed),
              'trialsSha256': sha(directory / 'trials.json'),
              'provenanceSha256': sha(directory / 'provenance.json')}
    with (HERE / 'verification.json').open('w') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps(result))


if __name__ == '__main__':
    main()
