"""Archive bounded evidence, excluding SDK outputs, binaries and Go caches."""
import hashlib
import io
import json
from pathlib import Path
import tarfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
directories = ['baseline-build', 'candidate-build', 'baseline-profile-run', 'partition-unit-tests',
               'partition-unit-tests-cgo', 'pack-integration-tests', 'comparison', 'comparison-driver',
               'comparison-resume-driver', 'comparison-resume-batch1', 'comparison-resume-batch2',
               'comparison-resume-batch3']
names = ['compare-generation.py', 'verify-comparison.py', 'summarize-pairs.py', 'archive-unit01.py',
         'baseline-profile.jsonl', 'baseline-profile.jsonl.files.jsonl', 'baseline.cpu.pprof',
         'paired-analysis.json', 'verification.json', 'comparison-before-resume.tar.gz',
         'comparison-interrupted-case.tar.gz']
files = {HERE / name for name in names}
for directory in directories:
    files.update(path for path in (HERE / directory).rglob('*') if path.is_file())
sources = ['internal/target/golang/partition.go', 'internal/target/golang/partition_test.go',
           'scripts/perf/sdk-optimization/profile-go/main.go', 'scripts/perf/sdk-optimization/compare-apis.py',
           'scripts/perf/sdk-optimization/record.py']
files.update(ROOT / name for name in sources)
assert sum(path.stat().st_size for path in files) < 64 * 1024**2
destination = ROOT / 'plans/performance-resource-loop/measurements/01-partition-format.tar.gz'
destination.parent.mkdir(exist_ok=True)
entries = {}
contents = {}
with tarfile.open(destination, 'x:gz') as archive:
    for path in sorted(files):
        assert not path.is_symlink()
        name = str(path.relative_to(HERE)) if path.is_relative_to(HERE) else 'source/' + str(path.relative_to(ROOT))
        data = path.read_bytes()
        entries[name] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
        member = tarfile.TarInfo(name)
        member.size, member.mode = len(data), 0o600
        digest = entries[name]['sha256']
        if digest in contents:
            member.type, member.size, member.linkname = tarfile.LNKTYPE, 0, contents[digest]
            archive.addfile(member)
        else:
            archive.addfile(member, io.BytesIO(data))
            contents[digest] = name
    data = json.dumps(entries, indent=2).encode()
    member = tarfile.TarInfo('evidence-index.json')
    member.size, member.mode = len(data), 0o600
    archive.addfile(member, io.BytesIO(data))
with tarfile.open(destination) as archive:
    index = json.load(archive.extractfile('evidence-index.json'))
    assert len(archive.getmembers()) == len(index) + 1
    for name, expected in index.items():
        data = archive.extractfile(name).read()
        assert len(data) == expected['bytes'] and hashlib.sha256(data).hexdigest() == expected['sha256']
print(json.dumps({'path': str(destination.relative_to(ROOT)), 'files': len(entries),
                  'bytes': destination.stat().st_size,
                  'sha256': hashlib.sha256(destination.read_bytes()).hexdigest()}))
