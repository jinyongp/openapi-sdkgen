"""Generation-only paired trials. No SDK compilation or per-trial Go cache."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import statistics
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
PERF = ROOT / 'scripts/perf/sdk-optimization'
spec = importlib.util.spec_from_file_location('matched_apis', PERF / 'compare-apis.py')
apis = importlib.util.module_from_spec(spec)
spec.loader.exec_module(apis)


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(path, data):
    with path.open('w') as stream:
        json.dump(data, stream, indent=2)
        stream.write('\n')


def disk_bytes(path):
    return sum(p.stat().st_blocks * 512 for p in path.rglob('*') if p.is_file())


def main():
    batch = None
    for argument in list(sys.argv[1:]):
        if argument.startswith('--batch='):
            batch = int(argument.split('=', 1)[1])
            sys.argv.remove(argument)
    resume = '--resume' in sys.argv
    if resume:
        sys.argv.remove('--resume')
    destination = HERE / sys.argv[1]
    destination.mkdir(exist_ok=resume)
    pairs = int(sys.argv[2])
    providers = sys.argv[3:]
    binaries = {'baseline': HERE / 'bin/openapi-sdkgen', 'candidate': HERE / 'bin/candidate-sdkgen'}
    environment = dict(os.environ, GOCACHE=str(HERE / 'cache'), GOTMPDIR=str(HERE / 'go-tmp'),
                       GOMEMLIMIT='2GiB', GOMAXPROCS='4', GOFLAGS='-p=2')
    provenance = {'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
                  'binaries': {name: sha(path) for name, path in binaries.items()},
                  'producerSha256': sha(Path(__file__)), 'pairs': pairs,
                  'scope': 'fresh full Go generation including server; no SDK compilation',
                  'worker': {'path': str(PERF / 'compare-apis.py'), 'sha256': sha(PERF / 'compare-apis.py')},
                  'environment': {name: environment[name] for name in ['GOCACHE', 'GOTMPDIR', 'GOMEMLIMIT', 'GOMAXPROCS', 'GOFLAGS']},
                  'inputs': {name: {'path': apis.PROVIDERS[name][0], 'sha256': apis.PROVIDERS[name][1]} for name in providers}}
    if resume:
        original = json.loads((destination / 'provenance.json').read_text())
        for key in ('head', 'binaries', 'inputs', 'pairs', 'worker', 'environment'):
            if original[key] != provenance[key]:
                raise ValueError('resume condition changed: ' + key)
        original['resumeProducerSha256'] = provenance['producerSha256']
        provenance = original
    save(destination / 'provenance.json', provenance)
    rows = json.loads((destination / 'trials.json').read_text()) if resume else []
    invalid = [row for row in rows if row.get('recorderExit') != 0 or row.get('exitCode') != 0]
    if invalid:
        exclusion = destination / 'excluded-attempts.json'
        if exclusion.exists():
            raise ValueError('review additional failed attempts before resuming')
        save(exclusion, {'reason': 'failed recorder boundary; excluded, original command metrics retained', 'rows': invalid})
        for row in invalid:
            case = destination / f"{row['provider']}-{row['pair']}-{row['variant']}"
            case.rename(case.with_name(case.name + '-excluded'))
            shutil.rmtree(case.with_name(case.name + '-excluded') / 'api')
        rows = [row for row in rows if row not in invalid]
        save(destination / 'trials.json', rows)
    completed = {(row['provider'], row['pair'], row['variant']): row for row in rows}
    if len(completed) != len(rows):
        raise ValueError('duplicate original trial')
    references = {}
    started = time.monotonic()
    new_trials = 0
    for provider in providers:
        input_path = ROOT / apis.PROVIDERS[provider][0]
        if sha(input_path) != apis.PROVIDERS[provider][1]:
            raise ValueError('pinned input changed: ' + provider)
        for pair in range(pairs):
            for variant in (['baseline', 'candidate'] if pair % 2 == 0 else ['candidate', 'baseline']):
                if time.monotonic() - started > 900:
                    raise TimeoutError('900 second measurement budget exhausted')
                if disk_bytes(HERE / 'cache') > 4 * 1024**3:
                    raise RuntimeError('task cache exceeds 4 GiB; stop before next trial')
                if disk_bytes(HERE / 'go-tmp') > 2 * 1024**3:
                    raise RuntimeError('Go temporary files exceed 2 GiB')
                case = destination / f'{provider}-{pair}-{variant}'
                previous = completed.get((provider, pair, variant))
                if previous is not None and previous.get('outputMatches'):
                    inventory = json.loads((case / 'inventory.json').read_text())
                    if provider in references and references[provider] != inventory:
                        raise ValueError('retained output inventory changed')
                    references.setdefault(provider, inventory)
                    continue
                case.mkdir(exist_ok=previous is not None)
                sdk = case / 'api'
                metrics = case / 'metrics.json'
                command = [str(binaries[variant]), 'generate', '--target', 'golang', '--with', 'server',
                           '--input', str(input_path), '--output', str(sdk),
                           '--go-import-path', 'example.test/matched/api']
                invocation = [sys.executable, str(PERF / 'record.py'), '--output', str(case / 'record'),
                              '--timeout', '180', '--max-rss-mib', '3072', '--input', str(Path(__file__)),
                              '--', sys.executable, str(PERF / 'compare-apis.py'), '_child', str(metrics), *command]
                result = subprocess.run(invocation, cwd=ROOT, env=environment) if previous is None else None
                measured = json.loads(metrics.read_text()) if metrics.exists() else {}
                if previous is None:
                    row = {'provider': provider, 'pair': pair, 'variant': variant, 'recorderExit': result.returncode, **measured}
                    rows.append(row)
                else:
                    row = previous
                    for key, value in measured.items():
                        if row[key] != value:
                            raise ValueError('original measurement changed: ' + key)
                    row['verificationResumed'] = True
                save(destination / 'trials.json', rows)
                if row['recorderExit'] or measured.get('exitCode') != 0:
                    raise RuntimeError('failed generation: ' + str(case))
                manifest = json.loads((sdk / '.openapi-sdkgen-manifest.json').read_text())
                files = manifest['files']
                for name, digest in files.items():
                    if sha(sdk / name) != digest:
                        raise ValueError('output content differs from its manifest: ' + name)
                save(case / 'inventory.json', files)
                if provider in references and files != references[provider]:
                    original = references[provider]
                    differences = [name for name in sorted(files.keys() | original.keys()) if files.get(name) != original.get(name)]
                    save(case / 'differences.json', differences)
                    raise ValueError(f'output differs: {len(differences)} files; first: {differences[:5]}')
                references.setdefault(provider, files)
                row.update(files=len(files), bytes=sum((sdk / name).stat().st_size for name in files), outputMatches=True)
                save(destination / 'trials.json', rows)
                shutil.rmtree(sdk)
                print(json.dumps(row), flush=True)
                new_trials += 1
                if batch and new_trials >= batch and len(rows) < len(providers) * pairs * 2:
                    save(destination / 'progress.json', {'status': 'in_progress', 'rows': len(rows), 'requested': len(providers) * pairs * 2})
                    return
    summaries = []
    for provider in providers:
        summary = {'provider': provider, 'pairs': pairs}
        for variant in binaries:
            selected = [row for row in rows if row['provider'] == provider and row['variant'] == variant]
            summary[variant] = {metric: {'median': statistics.median(row[metric] for row in selected),
                                       'min': min(row[metric] for row in selected),
                                       'max': max(row[metric] for row in selected)}
                                for metric in ['seconds', 'peakProcessRSSBytes', 'userSeconds', 'systemSeconds']}
        summary['timeChangePercent'] = (summary['candidate']['seconds']['median'] / summary['baseline']['seconds']['median'] - 1) * 100
        summaries.append(summary)
    save(destination / 'summary.json', {'status': 'pass', 'rows': len(rows), 'summaries': summaries})


if __name__ == '__main__':
    main()
