"""Deterministic paired-bootstrap summaries over five complete sample pairs."""
import itertools
import json
import math
from pathlib import Path
import statistics

HERE = Path(__file__).resolve().parent
rows = json.loads((HERE / 'comparison/trials.json').read_text())
result = []
for provider in ('tvmaze', 'listennotes', 'github'):
    sides = {variant: [row for row in rows if row['provider'] == provider and row['variant'] == variant]
             for variant in ('baseline', 'candidate')}
    assert all(len(side) == 5 for side in sides.values())
    logs = [math.log(next(row['seconds'] for row in sides['candidate'] if row['pair'] == pair) /
                     next(row['seconds'] for row in sides['baseline'] if row['pair'] == pair)) for pair in range(5)]
    values = sorted(math.exp(statistics.mean(sample)) for sample in itertools.product(logs, repeat=5))

    def quantile(fraction):
        position = (len(values) - 1) * fraction
        index = int(position)
        return values[index] + (values[min(index + 1, len(values) - 1)] - values[index]) * (position - index)

    summary = {'provider': provider, 'pairs': 5, 'pairedGeometricTimeRatio': math.exp(statistics.mean(logs)),
               'pairedPercentile95': [quantile(.025), quantile(.975)]}
    for variant, side in sides.items():
        summary[variant] = {'medianSeconds': statistics.median(row['seconds'] for row in side),
                            'rangeSeconds': [min(row['seconds'] for row in side), max(row['seconds'] for row in side)],
                            'medianPeakProcessRSSMiB': statistics.median(row['peakProcessRSSBytes'] for row in side) / 2**20,
                            'medianCPUSeconds': statistics.median(row['userSeconds'] + row['systemSeconds'] for row in side),
                            'files': side[0]['files'], 'bytes': side[0]['bytes']}
    result.append(summary)
with (HERE / 'paired-analysis.json').open('w') as stream:
    json.dump({'status': 'pass', 'bootstrapResamplesPerProvider': 5**5, 'summaries': result}, stream, indent=2)
    stream.write('\n')
