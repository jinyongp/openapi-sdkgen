"""Preserve bounded native pprof summaries and their exact command provenance."""
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'scripts/perf'))
from resources import owned_process

unit = ROOT / '.tmp/perf-resource-loop/unit09'
binary = ROOT / '.tmp/perf-resource-loop/unit06/bin/profile-go'
tasks = {
    'cpu-top': ['-top', '-nodecount=35', binary, unit / 'cpu.pprof'],
    'allocation-top': ['-top', '-sample_index=alloc_space', '-nodecount=35', binary, unit / 'heap.pprof'],
    'retained-top': ['-top', '-sample_index=inuse_space', '-nodecount=15', binary, unit / 'heap.pprof'],
    'product-cpu': ['-top', '-cum', '-nodecount=25', '-focus=openapi-sdkgen/internal/target/golang', binary, unit / 'cpu.pprof'],
    'product-allocation': ['-top', '-cum', '-sample_index=alloc_space', '-nodecount=25', '-focus=openapi-sdkgen/internal/target/golang', binary, unit / 'heap.pprof'],
    'format-cpu': ['-list=formatPartitionFile', binary, unit / 'cpu.pprof'],
    'format-allocation': ['-list=formatPartitionFile', '-sample_index=alloc_space', binary, unit / 'heap.pprof'],
    'bindings-cpu': ['-list=bindPartitionImports', binary, unit / 'cpu.pprof'],
    'emission-allocation': ['-list=golang.Generator.EmitTo', '-sample_index=alloc_space', binary, unit / 'heap.pprof'],
}
rows = []
for name, flags in tasks.items():
    command = ['go', 'tool', 'pprof', *map(str, flags)]
    with (unit / f'{name}.txt').open('x') as out, (unit / f'{name}.stderr').open('x') as err:
        with owned_process(command, cwd=ROOT, stdout=out, stderr=err) as process:
            status = process.wait(timeout=60)
    rows.append({'name': name, 'command': command, 'exitCode': status,
                 'sha256': hashlib.sha256((unit / f'{name}.txt').read_bytes()).hexdigest()})
    assert status == 0
with (unit / 'summaries.json').open('x') as stream:
    json.dump(rows, stream, indent=2)
    stream.write('\n')
print(json.dumps({'status': 'pass', 'summaries': len(rows)}))
