"""Preserve current attribution, rejected experiment and verified facade views."""
import hashlib
import io
import json
from pathlib import Path
import tarfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
unit = HERE / 'unit09'
files = {Path(__file__).resolve()}
files.update(HERE / name for name in ['profile-unit09.py', 'summarize-unit09.py', 'batch-unit09.py',
    'final-checks-unit09.py', 'clean-unit09.py', 'run-observed-pair.py',
    'verify-observed-unit.py', 'integrate-observed-unit.py'])
files.update(p for p in unit.rglob('*') if p.is_file() and not p.is_relative_to(unit / 'bin'))
for name in ('unit09-profile-driver', 'unit09-summary-driver', 'unit06/candidate-generator-build'):
    files.update(p for p in (HERE / name).rglob('*') if p.is_file())
files.add(HERE / 'unit06/github-pair-0/candidate/phases.jsonl.files.jsonl')
files.update(ROOT / name for name in ['internal/target/golang/partition.go',
    'internal/target/golang/partition_test.go', 'internal/target/golang/emit.go',
    'scripts/perf/resources.py', 'scripts/perf/sdk-optimization/profile-go/main.go',
    'scripts/perf/sdk-optimization/record.py', 'scripts/perf/sdk-optimization/compare-apis.py',
    'scripts/lib/redact.py', '.tmp/compatibility-regression/github/api.github.com.2022-11-28.json'])


def sha(data):
    return hashlib.sha256(data).hexdigest()


verified = json.loads((unit / 'verification.json').read_text())
assert verified['status'] == 'pass' and verified['samples'] == 10
assert verified['changedRuntimeFiles'] == ['internal/target/golang/partition.go']
for name in ('final-checks-driver', 'final-emission-tests', 'final-ownership-race',
             'github-pair-0-driver', 'batch-driver'):
    assert json.loads((unit / name / 'result.json').read_text())['status'] == 'pass'
for provider in ('github', 'tvmaze', 'listennotes'):
    integration = json.loads((unit / 'cli-integration' / provider / 'verified.json').read_text())
    assert integration['actualOutputMatchesObservedCandidate']
    assert not (unit / 'cli-integration' / provider / 'api').exists()
for name in ('candidate-partition-tests', 'isolated-rendered-binding-failure', 'facade-view-tests'):
    assert json.loads((unit / name / 'result.json').read_text())['status'] == 'fail'
with tarfile.open(unit / 'rejected-source.tar.gz') as rejected:
    original = json.loads((unit / 'isolated-rendered-binding-failure/source.json').read_text())
    for name in ('emit.go', 'partition.go', 'partition_test.go'):
        key = 'internal/target/golang/' + name
        assert sha(rejected.extractfile(key).read()) == original[key]

# Recover the first AST snapshot fixture exactly, with its original hash. This
# forensic archive entry is not applied to or executed in the current source.
unstable = (ROOT / 'internal/target/golang/partition_test.go').read_text()
unstable = unstable.replace('\t"reflect"\n', '', 1)
unstable = unstable.replace('''\t\tscope := file.Scope
\t\tobjects := make(map[string]*ast.Object, len(scope.Objects))
\t\tfor name, object := range scope.Objects {
\t\t\tobjects[name] = object
\t\t}
''', '', 1)
unstable = unstable.replace('''\t\t\t// ast.Fprint visits map keys in unspecified order. Check the scope
\t\t\t// map separately while retaining object links in the syntax snapshot.
\t\t\tif err := ast.Fprint(&buffer, set, file, func(name string, _ reflect.Value) bool { return name != "Objects" }); err != nil {''',
    '\t\t\tif err := ast.Fprint(&buffer, set, file, nil); err != nil {', 1)
unstable = unstable.replace('!bytes.Equal(before, snapshot()) || file.Scope != scope || !reflect.DeepEqual(objects, scope.Objects)',
                            '!bytes.Equal(before, snapshot())', 1).encode()
first_source = json.loads((unit / 'facade-view-tests/source.json').read_text())
assert sha(unstable) == first_source['internal/target/golang/partition_test.go']
assert sha((ROOT / 'internal/target/golang/partition.go').read_bytes()) == first_source['internal/target/golang/partition.go']

destination = ROOT / 'plans/performance-resource-loop/measurements/09-current-profile.tar.gz'
blobs = {str(path.relative_to(HERE)) if path.is_relative_to(HERE) else
         'source/' + str(path.relative_to(ROOT)): path.read_bytes() for path in sorted(files)}
blobs['unit09/unstable-snapshot-partition_test.go'] = unstable
index, content, unique_bytes = {}, {}, 0
with tarfile.open(destination, 'x:gz') as archive:
    for name, data in sorted(blobs.items()):
        assert not data.startswith(b'\x7fELF')
        digest = sha(data)
        index[name] = {'bytes': len(data), 'sha256': digest}
        member = tarfile.TarInfo(name)
        member.mode = 0o600
        if digest in content:
            member.type, member.linkname = tarfile.LNKTYPE, content[digest]
            archive.addfile(member)
        else:
            unique_bytes += len(data)
            assert unique_bytes < 64 * 1024**2
            member.size = len(data)
            archive.addfile(member, io.BytesIO(data))
            content[digest] = name
    data = json.dumps(index, indent=2).encode()
    member = tarfile.TarInfo('evidence-index.json')
    member.size, member.mode = len(data), 0o600
    archive.addfile(member, io.BytesIO(data))
with tarfile.open(destination) as archive:
    expected = json.load(archive.extractfile('evidence-index.json'))
    assert len(archive.getmembers()) == len(expected) + 1
    for name, entry in expected.items():
        data = archive.extractfile(name).read()
        assert len(data) == entry['bytes'] and sha(data) == entry['sha256']
print(json.dumps({'entries': len(index), 'uniqueUncompressedBytes': unique_bytes,
                  'bytes': destination.stat().st_size, 'sha256': sha(destination.read_bytes())}))
