"""Profile the current emitter once; verify every output and discard the SDK."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys

ROOT = Path(__file__).resolve().parents[2]
HERE = ROOT / '.tmp/perf-resource-loop/unit09'
sys.path.insert(0, str(ROOT / 'scripts/perf'))
from resources import cancellation_signals, owned_process


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def main():
    HERE.mkdir(exist_ok=False)
    source = ROOT / '.tmp/compatibility-regression/github/api.github.com.2022-11-28.json'
    assert sha(source) == 'd39842ee4d43d701e8a8c5483b4afa7c23218518f943dea2e42d36a3798cbdcc'
    binary = ROOT / '.tmp/perf-resource-loop/unit06/bin/profile-go'
    expected_path = ROOT / '.tmp/perf-resource-loop/unit06/github-pair-0/candidate/phases.jsonl.files.jsonl'
    sdk, phases = HERE / 'api', HERE / 'phases.jsonl'
    metrics = HERE / 'metrics.json'
    command = [str(binary), '-input', str(source), '-output', str(sdk), '-report', str(phases),
               '-profile', str(HERE / 'cpu.pprof'), '-heap', str(HERE / 'heap.pprof')]
    environment = {**os.environ, 'GOTOOLCHAIN': 'local', 'GOWORK': 'off', 'CGO_ENABLED': '0',
                   'GOMAXPROCS': '4', 'GOMEMLIMIT': '2GiB'}
    perf = ROOT / 'scripts/perf/sdk-optimization'
    invocation = [sys.executable, str(perf / 'record.py'), '--output', str(HERE / 'record'),
        '--timeout', '180', '--max-rss-mib', '3072', '--input', str(source), '--input', str(Path(__file__)),
        '--', sys.executable, str(perf / 'compare-apis.py'), '_child', str(metrics), *command]
    save(HERE / 'provenance.json', {'producerSha256': sha(Path(__file__)),
        'inputSha256': sha(source), 'observerSha256': sha(binary),
        'expectedInventorySha256': sha(expected_path),
        'scope': 'intrusive attribution only; no matched speed sample'})
    with cancellation_signals(), owned_process(invocation, cwd=ROOT, env=environment) as process:
        assert process.wait() == 0
    assert json.loads((HERE / 'record/result.json').read_text())['status'] == 'pass'
    result = json.loads(metrics.read_text())
    assert result['exitCode'] == 0
    def inventory(path):
        return {row['path']: (row['bytes'], row['sha256'])
                for row in map(json.loads, path.read_text().splitlines())}
    actual = inventory(Path(str(phases) + '.files.jsonl'))
    assert actual == inventory(expected_path)
    manifest = json.loads((sdk / '.openapi-sdkgen-manifest.json').read_text())['files']
    assert manifest == {name: entry[1] for name, entry in actual.items()}
    assert all(sha(sdk / name) == digest for name, digest in manifest.items())
    checkpoints = list(map(json.loads, phases.read_text().splitlines()))
    assert checkpoints[-1]['phase'] == 'publish-finished'
    verified = {'status': 'pass', 'files': len(actual), 'bytes': sum(v[0] for v in actual.values()),
                'metrics': result, 'allocatedBytes': checkpoints[-1]['totalAllocBytes']}
    save(HERE / 'verified.json', verified)
    shutil.rmtree(sdk)
    print(json.dumps(verified), flush=True)


if __name__ == '__main__':
    main()
