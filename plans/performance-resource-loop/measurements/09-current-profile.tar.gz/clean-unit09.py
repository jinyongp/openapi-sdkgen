"""Retain release, current and previous product binaries after final validation."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
report = json.loads((HERE / 'unit09/verification.json').read_text())
assert report['status'] == 'pass' and report['samples'] == 10
assert json.loads((HERE / 'unit09/final-checks-driver/result.json').read_text())['status'] == 'pass'
previous = json.loads((HERE / 'unit06/binary-retention.json').read_text())
known = {row['path']: row for row in previous['retained']}
removed, retained = [], []
for name in ('unit04/bin/openapi-sdkgen', 'unit04/bin/profile-go'):
    path = HERE / name
    assert path.is_file() and not path.is_symlink()
    with path.open('rb') as stream:
        assert stream.read(4) == b'\x7fELF'
        stream.seek(0)
        row = {'path': name, 'bytes': path.stat().st_size, 'sha256': hashlib.file_digest(stream, 'sha256').hexdigest()}
    assert row == known[name]
    removed.append(row)
for name in ('bin/openapi-sdkgen', 'unit06/bin/openapi-sdkgen', 'unit06/bin/profile-go',
             'unit09/bin/openapi-sdkgen', 'unit09/bin/profile-go'):
    path = HERE / name
    with path.open('rb') as stream:
        retained.append({'path': name, 'bytes': path.stat().st_size, 'sha256': hashlib.file_digest(stream, 'sha256').hexdigest()})
with (HERE / 'unit09/binary-retention.json').open('x') as stream:
    json.dump({'removed': removed, 'retained': retained}, stream, indent=2)
    stream.write('\n')
for row in removed:
    (HERE / row['path']).unlink()
print(json.dumps({'removedFiles': len(removed), 'removedBytes': sum(row['bytes'] for row in removed),
                  'retainedFiles': len(retained), 'retainedBytes': sum(row['bytes'] for row in retained)}))
