"""Preserve cancellation reproductions, successive sources and final checks."""
import hashlib
import io
import json
from pathlib import Path
import tarfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
files = {Path(__file__).resolve()}
files.update(p for p in (HERE / 'unit07').rglob('*') if p.is_file())
files.update(ROOT / p for p in ['scripts/perf/sdk-optimization/record.py',
    'scripts/perf/sdk-optimization/record_test.py', 'scripts/perf/sdk-optimization/README.md',
    'scripts/perf/sdk-optimization/compare-apis.py', 'scripts/perf/sdk-optimization/compare-apis_test.py',
    'scripts/perf/sdk-optimization/compare-go_test.py', 'scripts/lib/redact.py'])
for name in ['final-freeze-recorder-tests', 'final-freeze-api-comparison-tests', 'final-freeze-go-comparison-tests']:
    assert json.loads((HERE / 'unit07' / name / 'result.json').read_text())['status'] == 'pass'
for name in ['baseline-cancellation-reproduction', 'nested-cancellation-reproduction', 'snapshot-race-reproduction']:
    assert json.loads((HERE / 'unit07' / name / 'result.json').read_text())['status'] == 'fail'
destination = ROOT / 'plans/performance-resource-loop/measurements/07-trial-cancellation.tar.gz'
index, content, unique_bytes = {}, {}, 0
with tarfile.open(destination, 'x:gz') as archive:
    for path in sorted(files):
        assert not path.is_symlink()
        data = path.read_bytes()
        name = str(path.relative_to(HERE)) if path.is_relative_to(HERE) else 'source/' + str(path.relative_to(ROOT))
        digest = hashlib.sha256(data).hexdigest()
        index[name] = {'bytes': len(data), 'sha256': digest}
        member = tarfile.TarInfo(name)
        member.mode = 0o600
        if digest in content:
            member.type, member.linkname = tarfile.LNKTYPE, content[digest]
            archive.addfile(member)
        else:
            unique_bytes += len(data)
            assert unique_bytes < 64 * 1024**2
            member.size = len(data)
            archive.addfile(member, io.BytesIO(data))
            content[digest] = name
    data = json.dumps(index, indent=2).encode()
    member = tarfile.TarInfo('evidence-index.json')
    member.size, member.mode = len(data), 0o600
    archive.addfile(member, io.BytesIO(data))
with tarfile.open(destination) as archive:
    expected = json.load(archive.extractfile('evidence-index.json'))
    assert len(archive.getmembers()) == len(expected) + 1
    for name, entry in expected.items():
        data = archive.extractfile(name).read()
        assert len(data) == entry['bytes'] and hashlib.sha256(data).hexdigest() == entry['sha256']
print(json.dumps({'entries': len(index), 'uniqueUncompressedBytes': unique_bytes,
                  'bytes': destination.stat().st_size,
                  'sha256': hashlib.sha256(destination.read_bytes()).hexdigest()}))
