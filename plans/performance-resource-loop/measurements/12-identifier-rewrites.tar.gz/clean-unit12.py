"""Keep release/current/previous binaries after final scratch validation."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
unit = HERE / 'unit12'
assert json.loads((unit / 'final-checks-driver/result.json').read_text())['status'] == 'pass'
assert json.loads((unit / 'verification.json').read_text())['status'] == 'pass'
known = {row['path']: row for row in json.loads((HERE / 'unit11/binary-retention.json').read_text())['retained']}
removed, retained = [], []


def describe(name):
    path = HERE / name
    assert path.is_file() and not path.is_symlink()
    with path.open('rb') as stream:
        assert stream.read(4) == b'\x7fELF'
        stream.seek(0)
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'path': name, 'bytes': path.stat().st_size, 'sha256': digest}


for name in ('unit09/bin/openapi-sdkgen', 'unit09/bin/profile-go'):
    row = describe(name)
    assert row == known[name]
    removed.append(row)
for name in ('bin/openapi-sdkgen', 'unit11/bin/openapi-sdkgen', 'unit11/bin/profile-go',
             'unit12/bin/openapi-sdkgen', 'unit12/bin/profile-go'):
    retained.append(describe(name))
with (unit / 'binary-retention.json').open('x') as stream:
    json.dump({'removed': removed, 'retained': retained}, stream, indent=2)
    stream.write('\n')
for row in removed:
    (HERE / row['path']).unlink()
print(json.dumps({'removedFiles': len(removed), 'removedBytes': sum(row['bytes'] for row in removed),
                  'retainedFiles': len(retained), 'retainedBytes': sum(row['bytes'] for row in retained)}))
