"""Check final scratch ownership, consumers, races and real CLI inventories."""
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
HERE = ROOT / '.tmp/perf-resource-loop'
sys.path.insert(0, str(ROOT / 'scripts/perf'))
from resources import cancellation_signals, owned_process

tasks = {
    'final-emission-tests': ['env', 'CGO_ENABLED=1', 'go', 'test', '-json', './internal/target/golang',
        '-run', '^(TestEmissionTemplate|TestPreparedSource|TestEmitStops|TestFormattingFailure|TestOwnedRuntimeBytes|TestGeneratedHealthConsumer|TestPartition|TestPack)',
        '-count=1', '-timeout=150s'],
    'final-ownership-race': ['env', 'CGO_ENABLED=1', 'go', 'test', '-race', './internal/target/golang',
        '-run', '^Test(PartitionFormatter|PartitionAST|PartitionFacadeViewDoesNotMutateImplementation|EmissionTemplatesKeepFileDataIndependent|PreparedSourceIsIndependentAndDeterministic)',
        '-count=1', '-timeout=150s'],
}
with cancellation_signals():
    for name, command in tasks.items():
        output = HERE / 'unit12' / name
        invocation = [sys.executable, str(ROOT / 'scripts/perf/sdk-optimization/record.py'),
            '--output', str(output), '--timeout', '180', '--max-rss-mib', '3072',
            '--input', str(Path(__file__)), '--', *command]
        with owned_process(invocation, cwd=ROOT) as process:
            assert process.wait(timeout=210) == 0
        assert json.loads((output / 'result.json').read_text())['status'] == 'pass'
    for provider in ('tvmaze', 'listennotes', 'github'):
        with owned_process([sys.executable, '-B', str(HERE / 'integrate-observed-unit.py'), 'unit12', provider], cwd=ROOT) as process:
            assert process.wait(timeout=210) == 0
    with owned_process([sys.executable, '-B', str(HERE / 'verify-observed-unit.py'), 'unit12',
        '.tmp/perf-resource-loop/unit11/candidate-build', '.tmp/perf-resource-loop/unit12/candidate-build',
        'internal/target/golang/emit.go', 'internal/target/golang/partition.go'], cwd=ROOT) as process:
        assert process.wait(timeout=60) == 0
print(json.dumps({'status': 'pass', 'consumerChecks': len(tasks), 'cliInputs': 3, 'matchedSamples': 10}))
