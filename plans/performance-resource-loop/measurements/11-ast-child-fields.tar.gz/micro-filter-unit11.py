"""Omit the testing package's personal CPU header before recorder storage."""
import subprocess
import sys

process = subprocess.Popen([sys.argv[1], '-test.run', '^$', '-test.bench', '^BenchmarkPartitionASTTransform$',
    '-test.benchtime', '300ms', '-test.count', '1', '-test.benchmem'], stdout=subprocess.PIPE, text=True)
# Keep the native benchmark in the recorder-owned command session and RSS scope.
for line in process.stdout:
    if not line.startswith('cpu: '):
        print(line, end='', flush=True)
sys.exit(process.wait())
