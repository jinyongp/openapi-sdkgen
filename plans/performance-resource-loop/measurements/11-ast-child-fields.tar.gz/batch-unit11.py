"""Finish the approved real-input comparisons serially after the pilot passes."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'scripts/perf'))
from resources import cancellation_signals, owned_process

runner = ROOT / '.tmp/perf-resource-loop/run-observed-pair.py'
with cancellation_signals():
    for provider, pair in [('github', 1), ('github', 2), ('tvmaze', 0), ('listennotes', 0)]:
        command = [sys.executable, '-B', str(runner), 'unit11', provider, str(pair),
            '.tmp/perf-resource-loop/unit09/bin/profile-go', '.tmp/perf-resource-loop/unit11/bin/profile-go',
            f'.tmp/perf-resource-loop/unit09/{provider}-pair-0/candidate/phases.jsonl.files.jsonl']
        with owned_process(command, cwd=ROOT) as process:
            assert process.wait(timeout=480) == 0
