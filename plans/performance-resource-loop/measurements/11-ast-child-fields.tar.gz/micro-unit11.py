"""Alternate three bounded benchmark pairs and verify identical node visits."""
import hashlib
import json
from pathlib import Path
import statistics
import sys

ROOT = Path(__file__).resolve().parents[2]
HERE = ROOT / '.tmp/perf-resource-loop'
unit = HERE / 'unit11'
sys.path.insert(0, str(ROOT / 'scripts/perf'))
from resources import cancellation_signals, owned_process


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


rows = []
with cancellation_signals():
    for pair in range(3):
        for variant in (['baseline', 'candidate'] if pair % 2 == 0 else ['candidate', 'baseline']):
            output = unit / f'micro-{pair}-{variant}'
            binary = unit / f'benchmark-{variant}.test'
            command = [sys.executable, str(ROOT / 'scripts/perf/sdk-optimization/record.py'), '--output', str(output),
                '--timeout', '60', '--max-rss-mib', '3072', '--input', str(Path(__file__)),
                '--input', str(HERE / 'micro-filter-unit11.py'), '--', sys.executable, '-B',
                str(HERE / 'micro-filter-unit11.py'), str(binary)]
            with owned_process(command, cwd=ROOT) as process:
                assert process.wait(timeout=90) == 0
            assert json.loads((output / 'result.json').read_text())['status'] == 'pass'
            text = (output / 'stdout.log').read_text()
            assert not any(line.startswith('cpu: ') for line in text.splitlines())
            values = [line.split() for line in text.splitlines() if line.startswith('BenchmarkPartitionASTTransform-')]
            assert len(values) == 1
            values = values[0]
            metrics = {name: float(number) for number, name in zip(values[2::2], values[3::2])}
            rows.append({'pair': pair, 'variant': variant, 'iterations': int(values[1]), **metrics,
                         'binarySha256': sha(binary)})
assert len({row['node-visits/op'] for row in rows}) == 1
summary = {'status': 'pass', 'rows': rows, 'scope': 'isolated same-AST traversal, not SDK generation'}
for variant in ('baseline', 'candidate'):
    values = [row for row in rows if row['variant'] == variant]
    summary[variant] = {key: {'median': statistics.median(row[key] for row in values),
                            'min': min(row[key] for row in values), 'max': max(row[key] for row in values)}
                        for key in ('ns/op', 'B/op', 'allocs/op', 'node-visits/op')}
with (unit / 'micro-verification.json').open('x') as stream:
    json.dump(summary, stream, indent=2)
    stream.write('\n')
print(json.dumps({key: value for key, value in summary.items() if key != 'rows'}))
