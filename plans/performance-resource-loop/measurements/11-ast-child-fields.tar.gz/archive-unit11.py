"""Archive AST field-layout provenance, matching work, final checks and cleanup."""
import hashlib
import io
import json
from pathlib import Path
import tarfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
unit = HERE / 'unit11'
files = {Path(__file__).resolve()}
files.update(HERE / name for name in ['micro-filter-unit11.py', 'micro-unit11.py', 'batch-unit11.py',
    'final-checks-unit11.py', 'clean-unit11.py', 'run-observed-pair.py',
    'verify-observed-unit.py', 'integrate-observed-unit.py'])
files.update(path for path in unit.rglob('*') if path.is_file() and not path.is_relative_to(unit / 'bin'))
for name in ('unit09/candidate-build', 'unit10/profile-record', 'unit10/reflection-cpu', 'unit10/reflection-allocation'):
    files.update(path for path in (HERE / name).rglob('*') if path.is_file())
files.update(HERE / name for name in ['unit10/cpu.pprof', 'unit10/heap.pprof', 'unit10/profile-verified.json',
    'unit09/github-pair-0/candidate/phases.jsonl.files.jsonl'])
files.update(ROOT / name for name in ['internal/target/golang/partition.go',
    'internal/target/golang/partition_transform_test.go', 'internal/target/golang/partition_benchmark_test.go',
    'internal/target/golang/emit.go', 'scripts/perf/resources.py',
    'scripts/perf/sdk-optimization/profile-go/main.go', 'scripts/perf/sdk-optimization/record.py',
    'scripts/perf/sdk-optimization/compare-apis.py', 'scripts/lib/redact.py',
    '.tmp/compatibility-regression/github/api.github.com.2022-11-28.json'])


def sha(data):
    return hashlib.sha256(data).hexdigest()


for name in ('baseline-benchmark-build', 'candidate-benchmark-build', 'candidate-build',
    'candidate-partition-tests', 'micro-driver', 'github-pair-0-driver', 'batch-driver',
    'final-checks-driver', 'final-emission-tests', 'final-ownership-race'):
    assert json.loads((unit / name / 'result.json').read_text())['status'] == 'pass'
verified = json.loads((unit / 'verification.json').read_text())
assert verified['status'] == 'pass' and verified['samples'] == 10
assert verified['changedRuntimeFiles'] == ['internal/target/golang/partition.go']
micro = json.loads((unit / 'micro-verification.json').read_text())
assert micro['status'] == 'pass' and len(micro['rows']) == 6
assert {row['node-visits/op'] for row in micro['rows']} == {4702}
for row in micro['rows']:
    text = (unit / f'micro-{row["pair"]}-{row["variant"]}/stdout.log').read_text()
    assert not any(line.startswith('cpu: ') for line in text.splitlines())
events = list(map(json.loads, (unit / 'final-emission-tests/stdout.log').read_text().splitlines()))
assert len([event for event in events if event.get('Action') == 'pass' and 'Test' in event and '/' not in event['Test']]) == 26
assert not any(event.get('Action') == 'fail' for event in events)
for provider in ('github', 'tvmaze', 'listennotes'):
    assert json.loads((unit / f'cli-integration/{provider}/verified.json').read_text())['actualOutputMatchesObservedCandidate']
    assert not (unit / f'cli-integration/{provider}/api').exists()
for row in json.loads((unit / 'binary-retention.json').read_text())['removed']:
    assert not (HERE / row['path']).exists()

destination = ROOT / 'plans/performance-resource-loop/measurements/11-ast-child-fields.tar.gz'
index, content, unique_bytes = {}, {}, 0
with tarfile.open(destination, 'x:gz') as archive:
    for path in sorted(files):
        assert not path.is_symlink()
        data = path.read_bytes()
        assert not data.startswith(b'\x7fELF')
        name = str(path.relative_to(HERE)) if path.is_relative_to(HERE) else 'source/' + str(path.relative_to(ROOT))
        digest = sha(data)
        index[name] = {'bytes': len(data), 'sha256': digest}
        member = tarfile.TarInfo(name)
        member.mode = 0o600
        if digest in content:
            member.type, member.linkname = tarfile.LNKTYPE, content[digest]
            archive.addfile(member)
        else:
            unique_bytes += len(data)
            assert unique_bytes < 64 * 1024**2
            member.size = len(data)
            archive.addfile(member, io.BytesIO(data))
            content[digest] = name
    data = json.dumps(index, indent=2).encode()
    member = tarfile.TarInfo('evidence-index.json')
    member.size, member.mode = len(data), 0o600
    archive.addfile(member, io.BytesIO(data))
with tarfile.open(destination) as archive:
    expected = json.load(archive.extractfile('evidence-index.json'))
    assert len(archive.getmembers()) == len(expected) + 1
    for name, entry in expected.items():
        data = archive.extractfile(name).read()
        assert len(data) == entry['bytes'] and sha(data) == entry['sha256']
print(json.dumps({'entries': len(index), 'uniqueUncompressedBytes': unique_bytes,
                  'bytes': destination.stat().st_size, 'sha256': sha(destination.read_bytes())}))
