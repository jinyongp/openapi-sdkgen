"""Verify retained-heap evidence, reclaim its binary, and archive reproducible inputs."""
import hashlib
import io
import json
from pathlib import Path
import tarfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
unit = HERE / 'unit13'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(name):
    return json.loads((unit / name).read_text())


for case in ('default', 'smoke', 'models'):
    assert read(f'{case}/verified.json')['status'] == 'pass'
    assert read(f'{case}-driver/result.json')['status'] == 'pass'
    assert not (unit / case / 'api').exists()
assert read('guard-verification.json')['status'] == 'pass'
assert len(read('guard-verification.json')['rows']) == 4
for name in ('guard-driver', 'observer-build', 'observer-format', 'retained-top',
             'retained-cumulative', 'retained-emission', 'after-publication-top'):
    assert read(f'{name}/result.json')['status'] == 'pass'
baseline = json.loads((HERE / 'unit12/candidate-build/source.json').read_text())
runtime = {name: value for name, value in baseline.items()
           if name.startswith(('internal/', 'cmd/')) and name.endswith('.go')}
assert runtime and all(sha((ROOT / name).read_bytes()) == value for name, value in runtime.items())
build = read('observer-build/source.json')
observer = 'scripts/perf/sdk-optimization/profile-go/main.go'
assert sha((ROOT / observer).read_bytes()) == build[observer]
binary = unit / 'bin/profile-go'
binary_bytes = binary.stat().st_size
binary_sha = sha(binary.read_bytes())
assert binary_sha == read('models/verified.json')['observerSha256']
assert not any((unit / name / 'api').exists() for name in
               ('guard-file-only', 'guard-prefix-only', 'guard-existing', 'guard-unmatched'))
verification = {'status': 'pass', 'unchangedRuntimeGoFiles': len(runtime),
    'outputCases': 3, 'optionGuards': 4,
    'scope': 'intrusive diagnostic at a selected checkpoint; no performance improvement claim',
    'removedDiagnosticBinary': {'bytes': binary_bytes, 'sha256': binary_sha}}
with (unit / 'verification.json').open('x') as stream:
    json.dump(verification, stream, indent=2)
    stream.write('\n')
binary.unlink()

files = {Path(__file__).resolve(), HERE / 'snapshot-unit13.py', HERE / 'check-snapshot-unit13.py'}
files.update(path for path in unit.rglob('*') if path.is_file())
files.add(HERE / 'unit12/candidate-build/source.json')
for provider in ('tvmaze', 'github'):
    files.add(HERE / f'unit12/{provider}-pair-0/candidate/phases.jsonl.files.jsonl')
files.update(ROOT / name for name in (observer, 'internal/target/golang/emit.go',
    'internal/target/golang/partition.go', 'scripts/perf/resources.py',
    'scripts/perf/sdk-optimization/record.py', 'scripts/perf/sdk-optimization/compare-apis.py',
    'scripts/lib/redact.py', '.tmp/compatibility-regression/github/api.github.com.2022-11-28.json',
    '.tmp/compatibility-holdout/APIs/tvmaze.com/1.0/openapi.yaml'))
destination = ROOT / 'plans/performance-resource-loop/measurements/13-live-package-memory.tar.gz'
index, content, unique_bytes = {}, {}, 0
with tarfile.open(destination, 'x:gz') as archive:
    for path in sorted(files):
        assert not path.is_symlink()
        data = path.read_bytes()
        assert not data.startswith(b'\x7fELF')
        name = str(path.relative_to(HERE)) if path.is_relative_to(HERE) else 'source/' + str(path.relative_to(ROOT))
        digest = sha(data)
        index[name] = {'bytes': len(data), 'sha256': digest}
        member = tarfile.TarInfo(name)
        member.mode = 0o600
        if digest in content:
            member.type, member.linkname = tarfile.LNKTYPE, content[digest]
            archive.addfile(member)
        else:
            unique_bytes += len(data)
            assert unique_bytes < 64 * 1024**2
            member.size = len(data)
            archive.addfile(member, io.BytesIO(data))
            content[digest] = name
    data = json.dumps(index, indent=2).encode()
    member = tarfile.TarInfo('evidence-index.json')
    member.size, member.mode = len(data), 0o600
    archive.addfile(member, io.BytesIO(data))
with tarfile.open(destination) as archive:
    expected = json.load(archive.extractfile('evidence-index.json'))
    assert len(archive.getmembers()) == len(expected) + 1
    for name, entry in expected.items():
        data = archive.extractfile(name).read()
        assert len(data) == entry['bytes'] and sha(data) == entry['sha256']
print(json.dumps({**verification, 'entries': len(index), 'uniqueUncompressedBytes': unique_bytes,
    'bytes': destination.stat().st_size, 'sha256': sha(destination.read_bytes())}))
