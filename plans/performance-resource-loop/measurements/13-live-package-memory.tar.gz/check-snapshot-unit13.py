"""Exercise paired flags, exclusive profile output and unmatched-prefix status."""
import hashlib
import json
from pathlib import Path
import shutil
import sys

ROOT = Path(__file__).resolve().parents[2]
HERE = ROOT / '.tmp/perf-resource-loop'
sys.path.insert(0, str(ROOT / 'scripts/perf'))
from resources import cancellation_signals, owned_process

unit = HERE / 'unit13'
binary = unit / 'bin/profile-go'
source = ROOT / '.tmp/compatibility-holdout/APIs/tvmaze.com/1.0/openapi.yaml'
rows = []
cases = [('file-only', ['-heap-during-emission', 'heap.pprof'], 'required together', False),
         ('prefix-only', ['-heap-on-prefix', 'models/'], 'required together', False),
         ('existing', ['-heap-on-prefix', 'models/', '-heap-during-emission', 'heap.pprof'], 'file exists', False),
         ('unmatched', ['-heap-on-prefix', 'absent/', '-heap-during-emission', 'heap.pprof'], 'no emitted artifact matched', True)]
with cancellation_signals():
    for name, flags, expected, generated in cases:
        case = unit / ('guard-' + name)
        case.mkdir(exist_ok=False)
        if name == 'existing':
            (case / 'heap.pprof').write_bytes(b'caller-owned profile sentinel')
        flags = [str(case / value) if value == 'heap.pprof' else value for value in flags]
        command = [str(binary), '-input', str(source), '-output', str(case / 'api'), '-report', str(case / 'phases.jsonl'), *flags]
        invocation = [sys.executable, str(ROOT / 'scripts/perf/sdk-optimization/record.py'),
            '--output', str(case / 'record'), '--input', str(Path(__file__)), '--timeout', '60',
            '--max-rss-mib', '3072', '--', *command]
        with owned_process(invocation, cwd=ROOT) as process:
            assert process.wait(timeout=90) != 0
        result = json.loads((case / 'record/result.json').read_text())
        assert result['status'] == 'fail' and result['exitCode'] != 0
        assert expected in (case / 'record/stderr.log').read_text()
        if name == 'existing':
            assert (case / 'heap.pprof').read_bytes() == b'caller-owned profile sentinel'
        assert (case / 'api').exists() == generated
        if generated:
            expected_files = {row['path']: row['sha256'] for row in map(json.loads,
                (HERE / 'unit12/tvmaze-pair-0/candidate/phases.jsonl.files.jsonl').read_text().splitlines())}
            actual = json.loads((case / 'api/.openapi-sdkgen-manifest.json').read_text())['files']
            assert actual == expected_files
            for path, digest in actual.items():
                with (case / 'api' / path).open('rb') as stream:
                    assert hashlib.file_digest(stream, 'sha256').hexdigest() == digest
            assert (case / 'heap.pprof').stat().st_size == 0
            shutil.rmtree(case / 'api')
        rows.append({'case': name, 'status': 'pass', 'expectedMessage': expected, 'generatedBeforeDiagnosticFailure': generated})
with (unit / 'guard-verification.json').open('x') as stream:
    json.dump({'status': 'pass', 'rows': rows}, stream, indent=2)
    stream.write('\n')
print(json.dumps({'status': 'pass', 'guards': len(rows)}))
