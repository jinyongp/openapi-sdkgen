"""Capture one retained-heap checkpoint and verify the entire unchanged output."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys

ROOT = Path(__file__).resolve().parents[2]
HERE = ROOT / '.tmp/perf-resource-loop'
sys.path.insert(0, str(ROOT / 'scripts/perf'))
from resources import cancellation_signals, owned_process

cases = {
    'default': ('tvmaze', '.tmp/compatibility-holdout/APIs/tvmaze.com/1.0/openapi.yaml',
        'd74e37b951a03b17ccd271777c0083053992f91b9c58e8681a51ca88af4eab62', ''),
    'smoke': ('tvmaze', '.tmp/compatibility-holdout/APIs/tvmaze.com/1.0/openapi.yaml',
        'd74e37b951a03b17ccd271777c0083053992f91b9c58e8681a51ca88af4eab62', 'models/'),
    'models': ('github', '.tmp/compatibility-regression/github/api.github.com.2022-11-28.json',
        'd39842ee4d43d701e8a8c5483b4afa7c23218518f943dea2e42d36a3798cbdcc', 'internal/modelsimpl/'),
}


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


name = sys.argv[1]
provider, source_name, expected, prefix = cases[name]
case = HERE / 'unit13' / name
case.mkdir(exist_ok=False)
source = ROOT / source_name
assert sha(source) == expected
binary = HERE / 'unit13/bin/profile-go'
output, report = case / 'api', case / 'phases.jsonl'
command = [binary, '-input', source, '-output', output, '-report', report]
if prefix:
    command += ['-heap-on-prefix', prefix, '-heap-during-emission', case / 'retained.pprof']
    command += ['-heap', case / 'after-publication.pprof']
perf = ROOT / 'scripts/perf/sdk-optimization'
invocation = [sys.executable, str(perf / 'record.py'), '--output', str(case / 'record'),
    '--input', str(Path(__file__)), '--input', str(source), '--timeout', '180', '--max-rss-mib', '3072',
    '--', sys.executable, '-B', str(perf / 'compare-apis.py'), '_child', str(case / 'metrics.json'), *map(str, command)]
with cancellation_signals(), owned_process(invocation, cwd=ROOT, env={**os.environ, 'GOMEMLIMIT': '2GiB'}) as process:
    assert process.wait(timeout=210) == 0
assert json.loads((case / 'record/result.json').read_text())['status'] == 'pass'
phases = list(map(json.loads, report.read_text().splitlines()))
assert phases[-1]['phase'] == 'publish-finished'
snapshots = [phase for phase in phases if phase['phase'] == 'emit-heap']
assert len(snapshots) == (1 if prefix else 0)
if prefix:
    assert snapshots[0]['heapArtifact'].startswith(prefix)
    assert (case / 'retained.pprof').stat().st_size > 0
frozen = HERE / f'unit12/{provider}-pair-0/candidate/phases.jsonl.files.jsonl'
inventory = {row['path']: (row['bytes'], row['sha256']) for row in map(json.loads, frozen.read_text().splitlines())}
current = {row['path']: (row['bytes'], row['sha256']) for row in map(json.loads, Path(str(report) + '.files.jsonl').read_text().splitlines())}
assert current == inventory
manifest = json.loads((output / '.openapi-sdkgen-manifest.json').read_text())['files']
assert manifest == {path: row[1] for path, row in inventory.items()}
assert all(sha(output / path) == digest for path, digest in manifest.items())
with (case / 'verified.json').open('x') as stream:
    json.dump({'status': 'pass', 'provider': provider, 'files': len(inventory),
        'bytes': sum(row[0] for row in inventory.values()), 'inputSha256': sha(source),
        'observerSha256': sha(binary), 'producerSha256': sha(Path(__file__)),
        'scope': 'intrusive retained-heap diagnostic; not a matched benchmark', 'snapshots': snapshots}, stream, indent=2)
    stream.write('\n')
shutil.rmtree(output)
print(json.dumps({'status': 'pass', 'case': name, 'files': len(inventory), 'snapshots': snapshots}))
