"""Verify stored-source retained-heap attribution at the same artifact checkpoint."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys

ROOT = Path(__file__).resolve().parents[2]
HERE = ROOT / '.tmp/perf-resource-loop'
sys.path.insert(0, str(ROOT / 'scripts/perf'))
from resources import cancellation_signals, owned_process


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


case = HERE / 'unit14/models'
case.mkdir(exist_ok=False)
source = ROOT / '.tmp/compatibility-regression/github/api.github.com.2022-11-28.json'
assert sha(source) == 'd39842ee4d43d701e8a8c5483b4afa7c23218518f943dea2e42d36a3798cbdcc'
binary = HERE / 'unit14/bin/profile-go'
output, report = case / 'api', case / 'phases.jsonl'
command = [binary, '-input', source, '-output', output, '-report', report,
    '-heap-on-prefix', 'internal/modelsimpl/', '-heap-during-emission', case / 'retained.pprof']
perf = ROOT / 'scripts/perf/sdk-optimization'
invocation = [sys.executable, str(perf / 'record.py'), '--output', str(case / 'record'),
    '--input', str(Path(__file__)), '--input', str(source), '--timeout', '180', '--max-rss-mib', '3072',
    '--', sys.executable, '-B', str(perf / 'compare-apis.py'), '_child', str(case / 'metrics.json'), *map(str, command)]
with cancellation_signals(), owned_process(invocation, cwd=ROOT, env={**os.environ, 'GOMEMLIMIT': '2GiB'}) as process:
    assert process.wait(timeout=210) == 0
assert json.loads((case / 'record/result.json').read_text())['status'] == 'pass'
phases = list(map(json.loads, report.read_text().splitlines()))
assert phases[-1]['phase'] == 'publish-finished'
snapshots = [phase for phase in phases if phase['phase'] == 'emit-heap']
prior = json.loads((HERE / 'unit13/models/verified.json').read_text())['snapshots']
assert len(snapshots) == 1 and snapshots[0]['heapArtifact'] == prior[0]['heapArtifact']
inventory = {row['path']: (row['bytes'], row['sha256']) for row in map(json.loads,
    (HERE / 'unit12/github-pair-0/candidate/phases.jsonl.files.jsonl').read_text().splitlines())}
current = {row['path']: (row['bytes'], row['sha256']) for row in
    map(json.loads, Path(str(report) + '.files.jsonl').read_text().splitlines())}
assert current == inventory
manifest = json.loads((output / '.openapi-sdkgen-manifest.json').read_text())['files']
assert manifest == {path: row[1] for path, row in inventory.items()}
assert all(sha(output / path) == digest for path, digest in manifest.items())
with (case / 'verified.json').open('x') as stream:
    json.dump({'status': 'pass', 'files': len(inventory), 'inputSha256': sha(source),
        'observerSha256': sha(binary), 'producerSha256': sha(Path(__file__)),
        'scope': 'intrusive selected-checkpoint diagnostic; not a benchmark', 'snapshots': snapshots,
        'baselineLiveHeapBytes': prior[0]['liveHeapBytes'],
        'liveHeapRatio': snapshots[0]['liveHeapBytes']/prior[0]['liveHeapBytes']}, stream, indent=2)
    stream.write('\n')
shutil.rmtree(output)
print(json.dumps({'status': 'pass', 'liveHeapBytes': snapshots[0]['liveHeapBytes'],
    'baselineLiveHeapBytes': prior[0]['liveHeapBytes']}))
