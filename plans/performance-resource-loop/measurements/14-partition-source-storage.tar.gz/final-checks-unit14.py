"""Bounded final integration: ownership/race, real CLI pairs and heap attribution."""
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
HERE = ROOT / '.tmp/perf-resource-loop'
sys.path.insert(0, str(ROOT / 'scripts/perf'))
from resources import cancellation_signals, owned_process


def run(command, timeout=210):
    with owned_process(command, cwd=ROOT) as process:
        assert process.wait(timeout=timeout) == 0


def record(name, command, limit=180):
    run([sys.executable, str(ROOT / 'scripts/perf/sdk-optimization/record.py'),
        '--output', str(HERE / 'unit14' / name), '--timeout', str(limit), '--max-rss-mib', '3072',
        '--input', str(Path(__file__)), '--', *command], timeout=limit+30)
    assert json.loads((HERE / 'unit14' / name / 'result.json').read_text())['status'] == 'pass'


with cancellation_signals():
    record('ownership-race', ['env', 'CGO_ENABLED=1', 'go', 'test', '-race', './internal/target/golang',
        '-run', '^Test(PartitionSource|PartitionStored|PartitionFormatter|PartitionAST|PartitionFacadeViewDoesNotMutateImplementation|EmissionTemplatesKeepFileDataIndependent|PreparedSourceIsIndependentAndDeterministic)',
        '-count=1', '-timeout=150s'])
    run([sys.executable, '-B', str(HERE / 'cli-pairs-unit14.py')], timeout=900)
    for provider in ('tvmaze', 'listennotes'):
        run([sys.executable, '-B', str(HERE / 'integrate-observed-unit.py'), 'unit14', provider])
    run([sys.executable, '-B', str(HERE / 'snapshot-unit14.py')])
    for name, options in [('retained-top', ['-top', '-nodecount=20']),
                          ('retained-cumulative', ['-top', '-cum', '-nodecount=20'])]:
        record(name, ['go', 'tool', 'pprof', '-inuse_space', *options,
            str(HERE / 'unit14/bin/profile-go'), str(HERE / 'unit14/models/retained.pprof')], limit=60)
    run([sys.executable, '-B', str(HERE / 'verify-observed-unit.py'), 'unit14',
        '.tmp/perf-resource-loop/unit14/baseline-build', '.tmp/perf-resource-loop/unit14/candidate-build',
        'internal/target/golang/emit.go', 'internal/target/golang/partition.go',
        'internal/target/golang/partition_source.go'], timeout=60)
print(json.dumps({'status': 'pass', 'realCliPairs': 3, 'smallCliInputs': 2,
                  'matchedObserverSamples': 10, 'intrusiveHeapSnapshots': 1}))
