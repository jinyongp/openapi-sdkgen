"""Verify real CLI provenance and summarize distinct measurement boundaries."""
import hashlib
import itertools
import json
import math
from pathlib import Path
import statistics

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
unit = HERE / 'unit14'


def read(path):
    return json.loads(path.read_text())


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def summarize(rows):
    result = {}
    for variant in ('baseline', 'candidate'):
        selected = [row for row in rows if row['variant'] == variant]
        result[variant] = {key: {'median': statistics.median(row[key] for row in selected),
            'min': min(row[key] for row in selected), 'max': max(row[key] for row in selected)}
            for key in ('seconds', 'peakProcessRSSBytes')}
        result[variant]['medianCPUSeconds'] = statistics.median(row['userSeconds']+row['systemSeconds'] for row in selected)
    ratios = {}
    for key in ('seconds', 'peakProcessRSSBytes'):
        by_pair = {(row['pair'], row['variant']): row[key] for row in rows}
        values = [by_pair[pair, 'candidate']/by_pair[pair, 'baseline'] for pair in range(3)]
        logs = list(map(math.log, values))
        samples = sorted(math.exp(statistics.mean(sample)) for sample in itertools.product(logs, repeat=3))
        def percentile(p):
            rank = (len(samples)-1)*p
            low, high = math.floor(rank), math.ceil(rank)
            return samples[low]+(samples[high]-samples[low])*(rank-low)
        ratios[key] = {'ratios': values, 'geometricMean': math.exp(statistics.mean(logs)),
            'bootstrapPercentile95Exact27': [percentile(.025), percentile(.975)]}
    result['paired'] = ratios
    return result


assert read(unit / 'final-checks-retry/result.json')['status'] == 'pass'
assert read(unit / 'verification.json')['status'] == 'pass'
assert read(unit / 'models/verified.json')['status'] == 'pass'
cli = read(unit / 'cli-verification.json')
assert cli['status'] == 'pass' and len(cli['rows']) == 6 and cli['pairs'] == 3
assert len({(row['pair'], row['variant']) for row in cli['rows']}) == 6
binary_paths = {'baseline': HERE / 'unit12/bin/openapi-sdkgen', 'candidate': unit / 'bin/openapi-sdkgen'}
input_path = ROOT / '.tmp/compatibility-regression/github/api.github.com.2022-11-28.json'
for row in cli['rows']:
    child = unit / f"cli-pair-{row['pair']}/{row['variant']}"
    record = read(child / 'record/result.json')
    assert row == read(child / 'verified.json') and row['outputMatches'] and row['exitCode'] == 0
    assert record['status'] == 'pass' and record['exitCode'] == 0
    assert all(row[key] == value for key, value in read(child / 'metrics.json').items())
    assert row['binarySha256'] == sha(binary_paths[row['variant']]) == record['commandFiles'][str(binary_paths[row['variant']])]
    assert row['producerSha256'] == sha(HERE / 'cli-pairs-unit14.py') == record['inputs'][str(HERE / 'cli-pairs-unit14.py')]
    assert row['sourceSha256'] == sha(input_path) == record['inputs'][str(input_path)]
    assert sha(child / 'record/source.json') == record['sourceManifestSha256']
    assert all(sha(child / 'record' / name) == record[name+'Sha256'] for name in ('stdout.log', 'stderr.log'))
    assert not (child / 'api').exists()
for provider in ('tvmaze', 'listennotes'):
    assert read(unit / f'cli-integration/{provider}/verified.json')['actualOutputMatchesObservedCandidate']
    assert not (unit / f'cli-integration/{provider}/api').exists()
events = list(map(json.loads, (unit / 'refined-partition-tests/stdout.log').read_text().splitlines()))
passed = {e['Test'] for e in events if e.get('Action') == 'pass' and 'Test' in e}
assert len([name for name in passed if '/' not in name]) == 31
assert not any(e.get('Action') == 'fail' for e in events)
for name in ('ownership-race', 'refined-partition-tests', 'candidate-build', 'baseline-build', 'batch-driver'):
    assert read(unit / name / 'result.json')['status'] == 'pass'
candidate = read(unit / 'candidate-build/source.json')
runtime = [name for name in candidate if name.startswith(('internal/', 'cmd/')) and name.endswith('.go')]
assert all(sha(ROOT / name) == candidate[name] for name in runtime)
observed = read(unit / 'verification.json')
summary = {'status': 'pass', 'realCli': summarize(cli['rows']),
    'observer': summarize([r for r in observed['rows'] if r['provider'] == 'github']),
    'observerAllocationRatio': observed['candidate']['allocatedBytes']['median']/observed['baseline']['allocatedBytes']['median'],
    'heapDiagnostic': read(unit / 'models/verified.json'), 'runtimeGoFiles': len(runtime),
    'scope': 'local matched generation; generated output unchanged; compiler cost not remeasured; not a public benchmark'}
with (unit / 'summary.json').open('x') as stream:
    json.dump(summary, stream, indent=2)
    stream.write('\n')
print(json.dumps(summary))
