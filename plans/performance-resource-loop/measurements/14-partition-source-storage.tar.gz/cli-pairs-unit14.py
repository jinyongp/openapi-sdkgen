"""Matched real CLI runs, without observer GC or phase instrumentation."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys

ROOT = Path(__file__).resolve().parents[2]
HERE = ROOT / '.tmp/perf-resource-loop'
PERF = ROOT / 'scripts/perf/sdk-optimization'
sys.path.insert(0, str(ROOT / 'scripts/perf'))
from resources import cancellation_signals, owned_process


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


source = ROOT / '.tmp/compatibility-regression/github/api.github.com.2022-11-28.json'
assert sha(source) == 'd39842ee4d43d701e8a8c5483b4afa7c23218518f943dea2e42d36a3798cbdcc'
binaries = {'baseline': HERE / 'unit12/bin/openapi-sdkgen', 'candidate': HERE / 'unit14/bin/openapi-sdkgen'}
inventory = {r['path']: (r['bytes'], r['sha256']) for r in map(json.loads,
    (HERE / 'unit12/github-pair-0/candidate/phases.jsonl.files.jsonl').read_text().splitlines())}
rows = []
with cancellation_signals():
    for pair in range(3):
        for variant in (['baseline', 'candidate'] if pair % 2 == 0 else ['candidate', 'baseline']):
            case = HERE / f'unit14/cli-pair-{pair}/{variant}'
            case.mkdir(parents=True, exist_ok=False)
            output, metrics = case / 'api', case / 'metrics.json'
            binary = binaries[variant]
            command = [binary, 'generate', '--target', 'golang', '--with', 'server', '--input', source,
                '--output', output, '--go-import-path', 'example.test/graph/api']
            invocation = [sys.executable, str(PERF / 'record.py'), '--output', str(case / 'record'),
                '--input', str(Path(__file__)), '--input', str(source), '--timeout', '180', '--max-rss-mib', '3072',
                '--', sys.executable, '-B', str(PERF / 'compare-apis.py'), '_child', str(metrics), *map(str, command)]
            with owned_process(invocation, cwd=ROOT, env={**os.environ, 'GOMEMLIMIT': '2GiB'}) as process:
                assert process.wait(timeout=210) == 0
            record = json.loads((case / 'record/result.json').read_text())
            measured = json.loads(metrics.read_text())
            assert record['status'] == 'pass' and measured['exitCode'] == 0
            managed = json.loads((output / '.openapi-sdkgen-manifest.json').read_text())['files']
            assert managed == {path: item[1] for path, item in inventory.items()}
            assert all((output / path).stat().st_size == inventory[path][0]
                and sha(output / path) == digest for path, digest in managed.items())
            row = {'pair': pair, 'variant': variant, **measured, 'files': len(inventory),
                'bytes': sum(item[0] for item in inventory.values()), 'outputMatches': True,
                'sourceSha256': sha(source), 'binarySha256': sha(binary), 'producerSha256': sha(Path(__file__)),
                'scope': 'matched actual CLI generation; no observer or profiler'}
            with (case / 'verified.json').open('x') as stream:
                json.dump(row, stream, indent=2)
                stream.write('\n')
            shutil.rmtree(output)
            rows.append(row)
            print(json.dumps(row), flush=True)
with (HERE / 'unit14/cli-verification.json').open('x') as stream:
    json.dump({'status': 'pass', 'pairs': 3, 'rows': rows}, stream, indent=2)
    stream.write('\n')
