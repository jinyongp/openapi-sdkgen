"""Close the rejected experiment and reclaim only its five owned executables."""
import hashlib
import io
import json
from pathlib import Path
import tarfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
unit = HERE / 'unit14'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(path.read_text())


for name in ('final-checks-retry', 'summary-final-driver', 'refined-partition-tests', 'ownership-race'):
    assert read(unit / name / 'result.json')['status'] == 'pass'
assert read(unit / 'summary.json')['status'] == 'pass'
baseline = read(unit / 'baseline-build/source.json')
restored = {name: digest for name, digest in baseline.items()
            if name.startswith(('internal/', 'cmd/')) and name.endswith('.go')}
assert all(sha((ROOT / name).read_bytes()) == digest for name, digest in restored.items())
assert not (ROOT / 'internal/target/golang/partition_source.go').exists()
assert not (ROOT / 'internal/target/golang/partition_source_test.go').exists()
for label, build in [('initial', 'initial-candidate-build'), ('final', 'candidate-build')]:
    manifest = read(unit / build / 'source.json')
    with tarfile.open(unit / f'{label}-storage-source.tar.gz') as archive:
        for name in ('emit.go', 'partition.go', 'partition_source.go'):
            key = 'internal/target/golang/' + name
            assert sha(archive.extractfile(key).read()) == manifest[key]
assert not any(path.is_dir() and path.name == 'api' for path in unit.rglob('api'))
retained = read(HERE / 'unit12/binary-retention.json')['retained']
for row in retained:
    path = HERE / row['path']
    assert path.stat().st_size == row['bytes'] and sha(path.read_bytes()) == row['sha256']
removed = []
for name in ('initial-bin/openapi-sdkgen', 'initial-bin/profile-go',
             'baseline-bin/profile-go', 'bin/openapi-sdkgen', 'bin/profile-go'):
    path = unit / name
    assert path.is_file() and not path.is_symlink()
    data = path.read_bytes()
    assert data.startswith(b'\x7fELF')
    removed.append({'path': 'unit14/' + name, 'bytes': len(data), 'sha256': sha(data)})
with (unit / 'closeout.json').open('x') as stream:
    json.dump({'status': 'pass', 'disposition': 'rejected; product runtime restored',
        'productCommit': '5b9312d7c191bb6117bbf67f466631f916dc97a6',
        'restoredRuntimeGoFiles': len(restored), 'removed': removed, 'retained': retained}, stream, indent=2)
    stream.write('\n')
for row in removed:
    (HERE / row['path']).unlink()

files = {Path(__file__).resolve()}
files.update(HERE / name for name in ('run-observed-pair.py', 'batch-unit14.py', 'final-checks-unit14.py',
    'cli-pairs-unit14.py', 'snapshot-unit14.py', 'summarize-unit14.py', 'verify-observed-unit.py', 'integrate-observed-unit.py'))
files.update(path for path in unit.rglob('*') if path.is_file())
files.update(path for path in (HERE / 'unit12/candidate-build').rglob('*') if path.is_file())
for provider in ('github', 'tvmaze', 'listennotes'):
    files.add(HERE / f'unit12/{provider}-pair-0/candidate/phases.jsonl.files.jsonl')
for name in ('models/verified.json', 'models/retained.pprof', 'retained-top/stdout.log', 'retained-cumulative/stdout.log'):
    files.add(HERE / 'unit13' / name)
files.update(ROOT / name for name in ('scripts/perf/sdk-optimization/profile-go/main.go',
    'internal/target/golang/emit.go', 'internal/target/golang/partition.go', 'scripts/perf/resources.py',
    'scripts/perf/sdk-optimization/record.py', 'scripts/perf/sdk-optimization/compare-apis.py',
    'scripts/lib/redact.py', '.tmp/compatibility-regression/github/api.github.com.2022-11-28.json',
    '.tmp/compatibility-holdout/APIs/tvmaze.com/1.0/openapi.yaml',
    '.tmp/compatibility-holdout/APIs/listennotes.com/2.0/openapi.yaml'))
destination = ROOT / 'plans/performance-resource-loop/measurements/14-partition-source-storage.tar.gz'
index, content, unique_bytes = {}, {}, 0
with tarfile.open(destination, 'x:gz') as archive:
    for path in sorted(files):
        assert not path.is_symlink()
        data = path.read_bytes()
        assert not data.startswith(b'\x7fELF')
        name = str(path.relative_to(HERE)) if path.is_relative_to(HERE) else 'source/' + str(path.relative_to(ROOT))
        digest = sha(data)
        index[name] = {'bytes': len(data), 'sha256': digest}
        member = tarfile.TarInfo(name)
        member.mode = 0o600
        if digest in content:
            member.type, member.linkname = tarfile.LNKTYPE, content[digest]
            archive.addfile(member)
        else:
            unique_bytes += len(data)
            assert unique_bytes < 64 * 1024**2
            member.size = len(data)
            archive.addfile(member, io.BytesIO(data))
            content[digest] = name
    data = json.dumps(index, indent=2).encode()
    member = tarfile.TarInfo('evidence-index.json')
    member.size, member.mode = len(data), 0o600
    archive.addfile(member, io.BytesIO(data))
with tarfile.open(destination) as archive:
    expected = json.load(archive.extractfile('evidence-index.json'))
    assert len(archive.getmembers()) == len(expected)+1
    for name, entry in expected.items():
        data = archive.extractfile(name).read()
        assert len(data) == entry['bytes'] and sha(data) == entry['sha256']
print(json.dumps({'status': 'pass', 'restoredRuntimeGoFiles': len(restored),
    'removedBinaryBytes': sum(row['bytes'] for row in removed), 'entries': len(index),
    'bytes': destination.stat().st_size, 'sha256': sha(destination.read_bytes())}))
