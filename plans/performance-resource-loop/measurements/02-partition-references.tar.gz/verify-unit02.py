"""Recheck all paired observers, inventories and relevant source identities."""
import hashlib
import json
from pathlib import Path
import statistics

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def load(path):
    return json.loads(path.read_text())


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def main():
    rows = []
    for provider, pairs in [('github', 3), ('tvmaze', 1), ('listennotes', 1)]:
        reference = None
        for pair in range(pairs):
            directory = HERE / 'unit02' / f'{provider}-pair-{pair}'
            summary, provenance = load(directory / 'summary.json'), load(directory / 'provenance.json')
            assert summary['status'] == 'pass' and len(summary['rows']) == 2
            assert provenance['producerSha256'] == sha(HERE / 'run-unit02-pair.py')
            for row in summary['rows']:
                assert row['pair'] == pair and row['provider'] == provider
                variant = row['variant']
                binary = HERE / ('bin/profile-unit02' if variant == 'baseline' else 'unit02/bin/profile-go')
                assert provenance['binaries'][variant] == sha(binary)
                case = directory / variant
                metrics, record = load(case / 'metrics.json'), load(case / 'record/result.json')
                assert row['exitCode'] == record['exitCode'] == 0 and record['status'] == 'pass' and row['outputMatches']
                assert row == load(case / 'verified.json')
                assert all(row[key] == value for key, value in metrics.items())
                assert record['commandFiles'][str(binary)] == provenance['binaries'][variant]
                assert record['inputs'][str(HERE / 'run-unit02-pair.py')] == provenance['producerSha256']
                assert record['sourceManifestSha256'] == sha(case / 'record/source.json')
                assert all(sha(case / 'record' / name) == record[name + 'Sha256'] for name in ('stdout.log', 'stderr.log'))
                phases = [json.loads(line) for line in (case / 'phases.jsonl').read_text().splitlines()]
                assert phases[-1]['phase'] == 'publish-finished'
                assert row['allocatedBytes'] == phases[-1]['totalAllocBytes']
                inventory = {item['path']: (item['bytes'], item['sha256']) for item in
                             (json.loads(line) for line in (case / 'phases.jsonl.files.jsonl').read_text().splitlines())}
                assert len(inventory) == row['files'] and sum(entry[0] for entry in inventory.values()) == row['bytes']
                if reference is None:
                    reference = inventory
                assert reference == inventory
                rows.append(row)
    assert len(rows) == 10 and len({(r['provider'], r['pair'], r['variant']) for r in rows}) == 10
    baseline = load(HERE / 'unit02-profile-build/source.json')
    candidate = load(HERE / 'unit02-candidate-build/source.json')
    product = {name for name in baseline if name.startswith(('cmd/', 'internal/')) or name in ('go.mod', 'go.sum')}
    assert {name for name in product if baseline[name] != candidate[name]} == {
        'internal/target/golang/partition.go', 'internal/target/golang/partition_test.go'}
    observer = 'scripts/perf/sdk-optimization/profile-go/main.go'
    assert baseline[observer] == candidate[observer] == sha(ROOT / observer)
    assert all(sha(ROOT / name) == candidate[name] for name in product)
    github = [row for row in rows if row['provider'] == 'github']
    result = {'status': 'pass', 'samples': len(rows), 'githubPairs': 3, 'smallApiPairs': 2,
              'scope': 'same phase observer without CPU/heap profiling; not pure CLI timings', 'rows': rows}
    for variant in ('baseline', 'candidate'):
        selected = [row for row in github if row['variant'] == variant]
        result[variant] = {key: {'median': statistics.median(row[key] for row in selected),
                                  'min': min(row[key] for row in selected), 'max': max(row[key] for row in selected)}
                           for key in ('seconds', 'allocatedBytes', 'peakProcessRSSBytes')}
        result[variant]['medianCPUSeconds'] = statistics.median(row['userSeconds'] + row['systemSeconds'] for row in selected)
    with (HERE / 'unit02-verification.json').open('w') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps({key: value for key, value in result.items() if key != 'rows'}))


if __name__ == '__main__':
    main()
