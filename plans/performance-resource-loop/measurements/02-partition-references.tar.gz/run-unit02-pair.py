"""One bounded, complete pair using identical phase/allocation observers."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
PERF = ROOT / 'scripts/perf/sdk-optimization'
sys.dont_write_bytecode = True
spec = importlib.util.spec_from_file_location('matched_inputs', PERF / 'compare-apis.py')
apis = importlib.util.module_from_spec(spec)
spec.loader.exec_module(apis)


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(path, data):
    with path.open('x') as stream:
        json.dump(data, stream, indent=2)
        stream.write('\n')


def inventory(path):
    return {row['path']: (row['bytes'], row['sha256']) for row in
            (json.loads(line) for line in path.read_text().splitlines())}


def verify_output(output, reference):
    manifest = json.loads((output / '.openapi-sdkgen-manifest.json').read_text())['files']
    assert manifest == {name: entry[1] for name, entry in reference.items()}
    assert all(sha(output / name) == digest for name, digest in manifest.items())


def main():
    provider, pair = sys.argv[1], int(sys.argv[2])
    assert provider in apis.PROVIDERS and 0 <= pair < 3
    directory = HERE / 'unit02' / f'{provider}-pair-{pair}'
    directory.mkdir(exist_ok=False)
    source = ROOT / apis.PROVIDERS[provider][0]
    assert sha(source) == apis.PROVIDERS[provider][1]
    binaries = {'baseline': HERE / 'bin/profile-unit02', 'candidate': HERE / 'unit02/bin/profile-go'}
    save(directory / 'provenance.json', {'producerSha256': sha(Path(__file__)),
         'sourceSha256': sha(source), 'binaries': {name: sha(path) for name, path in binaries.items()},
         'scope': 'phase observer including server; no CPU/heap profiling; not pure CLI timings'})
    reference = inventory(HERE / 'unit02-baseline.jsonl.files.jsonl') if provider == 'github' else None
    rows = []
    for variant in (['baseline', 'candidate'] if pair % 2 == 0 else ['candidate', 'baseline']):
        case = directory / variant
        case.mkdir()
        output, phases, metrics = case / 'api', case / 'phases.jsonl', case / 'metrics.json'
        command = [str(binaries[variant]), '-input', str(source), '-output', str(output), '-report', str(phases)]
        invocation = [sys.executable, str(PERF / 'record.py'), '--output', str(case / 'record'),
                      '--timeout', '180', '--max-rss-mib', '3072', '--input', str(Path(__file__)),
                      '--', sys.executable, str(PERF / 'compare-apis.py'), '_child', str(metrics), *command]
        subprocess.run(invocation, cwd=ROOT, check=True)
        result = json.loads(metrics.read_text())
        record = json.loads((case / 'record/result.json').read_text())
        assert result['exitCode'] == 0 and record['status'] == 'pass'
        checkpoints = [json.loads(line) for line in phases.read_text().splitlines()]
        assert checkpoints[-1]['phase'] == 'publish-finished'
        actual = inventory(Path(str(phases) + '.files.jsonl'))
        if reference is None:
            reference = actual
        assert actual == reference
        verify_output(output, reference)
        row = {'provider': provider, 'pair': pair, 'variant': variant, **result,
               'allocatedBytes': checkpoints[-1]['totalAllocBytes'], 'files': len(actual),
               'bytes': checkpoints[-1]['bytes'], 'outputMatches': True}
        save(case / 'verified.json', row)
        shutil.rmtree(output)
        rows.append(row)
        print(json.dumps(row), flush=True)
    save(directory / 'summary.json', {'status': 'pass', 'rows': rows})


if __name__ == '__main__':
    main()
