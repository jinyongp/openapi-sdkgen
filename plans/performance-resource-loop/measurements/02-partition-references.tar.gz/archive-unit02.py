"""Compact unit 02 evidence; no generated SDKs, executables or Go caches."""
import hashlib
import io
import json
from pathlib import Path
import tarfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
files = set()
directories = ['unit02-profile-build', 'unit02-baseline-profile-run', 'unit02-candidate-build',
               'unit02-candidate-pilot-run', 'unit02-partition-tests', 'unit02-partition-tests-fixed', 'unit02-pack-tests']
for name in directories:
    files.update(path for path in (HERE / name).rglob('*') if path.is_file())
files.update(path for path in (HERE / 'unit02').rglob('*')
             if path.is_file() and path.relative_to(HERE / 'unit02').parts[0] != 'bin')
for name in ['run-unit02-pair.py', 'verify-unit02.py', 'archive-unit02.py', 'unit02-verification.json',
             'unit02-baseline.jsonl', 'unit02-baseline.jsonl.files.jsonl', 'unit02-baseline.cpu.pprof',
             'unit02-baseline.heap.pprof', 'unit02-candidate.jsonl', 'unit02-candidate.jsonl.files.jsonl',
             'unit02-candidate-pilot-metrics.json']:
    files.add(HERE / name)
for name in ['internal/target/golang/partition.go', 'internal/target/golang/partition_test.go',
             'scripts/perf/sdk-optimization/profile-go/main.go', 'scripts/perf/sdk-optimization/record.py',
             'scripts/perf/sdk-optimization/compare-apis.py']:
    files.add(ROOT / name)
assert not list((HERE / 'unit02').glob('*-pair-*/*/api'))
assert sum(path.stat().st_size for path in files) < 64 * 1024**2
destination = ROOT / 'plans/performance-resource-loop/measurements/02-partition-references.tar.gz'
index, content = {}, {}
with tarfile.open(destination, 'x:gz') as archive:
    for path in sorted(files):
        assert not path.is_symlink()
        name = str(path.relative_to(HERE)) if path.is_relative_to(HERE) else 'source/' + str(path.relative_to(ROOT))
        data = path.read_bytes()
        digest = hashlib.sha256(data).hexdigest()
        index[name] = {'bytes': len(data), 'sha256': digest}
        member = tarfile.TarInfo(name)
        member.mode = 0o600
        if digest in content:
            member.type, member.linkname = tarfile.LNKTYPE, content[digest]
            archive.addfile(member)
        else:
            member.size = len(data)
            archive.addfile(member, io.BytesIO(data))
            content[digest] = name
    data = json.dumps(index, indent=2).encode()
    member = tarfile.TarInfo('evidence-index.json')
    member.size, member.mode = len(data), 0o600
    archive.addfile(member, io.BytesIO(data))
with tarfile.open(destination) as archive:
    expected = json.load(archive.extractfile('evidence-index.json'))
    assert len(archive.getmembers()) == len(expected) + 1
    for name, entry in expected.items():
        data = archive.extractfile(name).read()
        assert len(data) == entry['bytes'] and hashlib.sha256(data).hexdigest() == entry['sha256']
print(json.dumps({'path': str(destination.relative_to(ROOT)), 'entries': len(index),
                  'bytes': destination.stat().st_size,
                  'sha256': hashlib.sha256(destination.read_bytes()).hexdigest()}))
