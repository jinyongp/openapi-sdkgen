"""Actual CLI correctness against the first unit's original-release inventories."""
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
PERF = ROOT / 'scripts/perf/sdk-optimization'
sys.dont_write_bytecode = True
spec = importlib.util.spec_from_file_location('original_inputs', PERF / 'compare-apis.py')
apis = importlib.util.module_from_spec(spec)
spec.loader.exec_module(apis)


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def main():
    destination = HERE / 'unit02-cli-integration'
    destination.mkdir(exist_ok=False)
    rows = []
    for provider, (name, expected) in apis.PROVIDERS.items():
        source = ROOT / name
        assert sha(source) == expected
        case = destination / provider
        case.mkdir()
        sdk, metrics = case / 'api', case / 'metrics.json'
        binary = HERE / 'unit02/bin/openapi-sdkgen'
        command = [str(binary), 'generate', '--target', 'golang', '--with', 'server', '--input', str(source),
                   '--output', str(sdk), '--go-import-path', 'example.test/matched/api']
        subprocess.run([sys.executable, str(PERF / 'record.py'), '--output', str(case / 'record'),
                        '--timeout', '180', '--max-rss-mib', '3072', '--input', str(Path(__file__)), '--',
                        sys.executable, str(PERF / 'compare-apis.py'), '_child', str(metrics), *command], cwd=ROOT, check=True)
        original = HERE / 'comparison' / f'{provider}-0-baseline/inventory.json'
        reference = json.loads(original.read_text())
        actual = json.loads((sdk / '.openapi-sdkgen-manifest.json').read_text())['files']
        assert actual == reference
        assert all(sha(sdk / name) == digest for name, digest in actual.items())
        row = {'provider': provider, 'files': len(actual), 'originalInventorySha256': sha(original),
               'candidateBinarySha256': sha(binary), 'actualOutputMatchesOriginal': True,
               'scope': 'single correctness run; not a matched performance comparison'}
        (case / 'verified.json').write_text(json.dumps(row, indent=2) + '\n')
        shutil.rmtree(sdk)
        rows.append(row)
    (destination / 'summary.json').write_text(json.dumps({'status': 'pass', 'rows': rows}, indent=2) + '\n')
    print(json.dumps({'status': 'pass', 'rows': rows}))


if __name__ == '__main__':
    main()
