import hashlib
import io
import json
from pathlib import Path
import tarfile

root = Path(__file__).resolve().parent
files = {Path(__file__), root / 'integrate-unit02.py'}
for directory in ('unit02-cli-integration', 'unit02-cli-integration-driver'):
    files.update(path for path in (root / directory).rglob('*') if path.is_file())
for provider in ('tvmaze', 'listennotes', 'github'):
    files.add(root / 'comparison' / f'{provider}-0-baseline/inventory.json')
destination = root.parents[1] / 'plans/performance-resource-loop/measurements/integration-01-02.tar.gz'
index, content = {}, {}
with tarfile.open(destination, 'x:gz') as archive:
    for path in sorted(files):
        name, data = str(path.relative_to(root)), path.read_bytes()
        digest = hashlib.sha256(data).hexdigest()
        index[name] = {'bytes': len(data), 'sha256': digest}
        info = tarfile.TarInfo(name)
        info.mode = 0o600
        if digest in content:
            info.type, info.linkname = tarfile.LNKTYPE, content[digest]
            archive.addfile(info)
        else:
            info.size = len(data)
            archive.addfile(info, io.BytesIO(data))
            content[digest] = name
    data = json.dumps(index, indent=2).encode()
    info = tarfile.TarInfo('evidence-index.json')
    info.size, info.mode = len(data), 0o600
    archive.addfile(info, io.BytesIO(data))
with tarfile.open(destination) as archive:
    expected = json.load(archive.extractfile('evidence-index.json'))
    assert len(archive.getmembers()) == len(expected) + 1
    for name, entry in expected.items():
        data = archive.extractfile(name).read()
        assert len(data) == entry['bytes'] and hashlib.sha256(data).hexdigest() == entry['sha256']
print(json.dumps({'entries': len(index), 'bytes': destination.stat().st_size,
                  'sha256': hashlib.sha256(destination.read_bytes()).hexdigest()}))
