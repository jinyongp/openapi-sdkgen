"""Archive cache reproductions and final checks without caches or SDK binaries."""
import ast
import hashlib
import io
import json
from pathlib import Path
import tarfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
unit = HERE / 'unit08'
files = {Path(__file__).resolve(), HERE / 'smoke-unit08.py', HERE / 'validate-unit08.py'}
files.update(p for p in unit.rglob('*') if p.is_file())
files.update(ROOT / p for p in [
    'scripts/perf/resources.py', 'scripts/perf/resources_test.py',
    'scripts/perf/golang/measure.py', 'scripts/perf/golang/measure_test.py',
    'scripts/perf/golang/README.md', 'scripts/perf/sdk-optimization/README.md',
    'scripts/perf/sdk-optimization/record.py', 'scripts/perf/sdk-optimization/record_test.py',
    'scripts/perf/sdk-optimization/compare-apis.py', 'scripts/perf/sdk-optimization/compare-apis_test.py',
    'scripts/perf/sdk-optimization/resume-apis.py', 'scripts/perf/sdk-optimization/resume-apis_test.py',
    'scripts/perf/sdk-optimization/compare-go.py', 'scripts/perf/sdk-optimization/compare-go_test.py',
    'scripts/lib/redact.py'])
source = ROOT / '.tmp/compatibility-holdout/APIs/tvmaze.com/1.0/openapi.yaml'
files.add(source)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


policy = sha(ROOT / 'scripts/perf/resources.py')
validation = json.loads((unit / 'final-validation/verified.json').read_text())
assert validation['status'] == 'pass' and validation['tests'] == 25
assert validation['resourcePolicySha256'] == policy
for index, row in enumerate(validation['rows']):
    assert sha(ROOT / row['test']) == row['sourceSha256']
    for stream in ('stdout', 'stderr'):
        assert sha(unit / 'final-validation' / f'{index:02d}.{stream}') == row[stream + 'Sha256']
smoke = json.loads((unit / 'smoke-final/verified.json').read_text())
assert smoke['status'] == 'pass' and smoke['cacheRemoved']
assert smoke['resourcePolicySha256'] == policy and sha(source) == smoke['inputSha256']
assert smoke['generatedFiles'] == 143 and smoke['beforeCold'] == {'files': 0, 'bytes': 0}
assert not Path(smoke['cachePath']).exists() and not (unit / 'smoke-final/module').exists()
assert sha(HERE / 'unit06/bin/openapi-sdkgen') == smoke['generatorSha256']
for name in ('final-validation-driver', 'final-real-go-smoke-driver'):
    assert json.loads((unit / name / 'result.json').read_text())['status'] == 'pass'
assert json.loads((unit / 'baseline-cache-reproduction-2/result.json').read_text())['status'] == 'fail'
with tarfile.open(unit / 'baseline-source.tar') as baseline:
    before = baseline.extractfile('scripts/perf/sdk-optimization/compare-apis.py').read().decode()
def worker(text):
    return ast.dump(next(node for node in ast.parse(text).body
                        if isinstance(node, ast.FunctionDef) and node.name == 'measure_child'))
assert worker(before) == worker((ROOT / 'scripts/perf/sdk-optimization/compare-apis.py').read_text())

destination = ROOT / 'plans/performance-resource-loop/measurements/08-measurement-caches.tar.gz'
index, content, unique_bytes = {}, {}, 0
with tarfile.open(destination, 'x:gz') as archive:
    for path in sorted(files):
        assert not path.is_symlink()
        assert not any(part.startswith(('go-cache-', 'cold-warm-cache-', 'cache-')) for part in path.parts)
        data = path.read_bytes()
        name = str(path.relative_to(HERE)) if path.is_relative_to(HERE) else 'source/' + str(path.relative_to(ROOT))
        digest = hashlib.sha256(data).hexdigest()
        index[name] = {'bytes': len(data), 'sha256': digest}
        member = tarfile.TarInfo(name)
        member.mode = 0o600
        if digest in content:
            member.type, member.linkname = tarfile.LNKTYPE, content[digest]
            archive.addfile(member)
        else:
            unique_bytes += len(data)
            assert unique_bytes < 64 * 1024**2
            member.size = len(data)
            archive.addfile(member, io.BytesIO(data))
            content[digest] = name
    data = json.dumps(index, indent=2).encode()
    member = tarfile.TarInfo('evidence-index.json')
    member.size, member.mode = len(data), 0o600
    archive.addfile(member, io.BytesIO(data))
with tarfile.open(destination) as archive:
    expected = json.load(archive.extractfile('evidence-index.json'))
    assert len(archive.getmembers()) == len(expected) + 1
    for name, entry in expected.items():
        data = archive.extractfile(name).read()
        assert len(data) == entry['bytes'] and hashlib.sha256(data).hexdigest() == entry['sha256']
print(json.dumps({'entries': len(index), 'uniqueUncompressedBytes': unique_bytes,
                  'bytes': destination.stat().st_size, 'sha256': sha(destination)}))
