"""Cache boundary checks without compiling the entire optional benchmark matrix."""
import importlib.util
import os
from pathlib import Path
import tempfile
import unittest

SCRIPT = Path(__file__).with_name('measure.py')
spec = importlib.util.spec_from_file_location('go_measurement', SCRIPT)
measurement = importlib.util.module_from_spec(spec)
spec.loader.exec_module(measurement)


class CacheFixture(measurement.Measurement):
    def __init__(self, output, fail=None):
        self.output, self.fail, self.results = output, fail, []
        self.environment = {**os.environ, 'GOCACHE': str(output / 'caller-cache')}
        self.caches = []

    def generate(self, label, input_file, module, extra=()):
        sdk = module / 'api'
        sdk.mkdir(exist_ok=True)
        self.results.append({'output': {'sha256': 'identical-fixture'}})
        return sdk

    def run(self, label, argv, cwd, env=None, **kwargs):
        if label.startswith('build-full-static-'):
            cache = Path(env['GOCACHE'])
            marker = cache / 'compiled'
            if '-cold' in label:
                if any(cache.iterdir()):
                    raise AssertionError('cold cache was not empty')
                marker.write_bytes(b'cached object')
                self.caches.append(cache)
            elif marker.read_bytes() != b'cached object':
                raise AssertionError('warm build did not inherit cold cache')
            if self.fail and self.fail in label:
                raise SystemExit('controlled compiler failure')
        if argv[:2] == ['go', 'build'] and '-o' in argv:
            Path(argv[argv.index('-o') + 1]).write_bytes(b'consumer')
        self.results.append({'exitCode': 0})
        return self.results[-1]


class CacheLifetimeTests(unittest.TestCase):
    def test_build_pair_cache_is_reclaimed_after_cold_or_warm_failure(self):
        for failure in ('-cold0', '-warm0'):
            with self.subTest(failure=failure), tempfile.TemporaryDirectory() as directory:
                root = Path(directory)
                runner = CacheFixture(root, failure)
                with self.assertRaises(SystemExit):
                    runner.builds('full-static')
                self.assertTrue(runner.caches)
                self.assertFalse(any(path.exists() for path in runner.caches),
                                 'failed consumer left a dedicated Go cache')

    def test_successive_pairs_start_empty_and_reclaim_their_cache(self):
        with tempfile.TemporaryDirectory() as directory:
            runner = CacheFixture(Path(directory))
            runner.builds('full-static')
            self.assertEqual(len(runner.caches), 5)
            self.assertEqual(len(set(runner.caches)), 5)
            self.assertFalse(any(path.exists() for path in runner.caches))


if __name__ == '__main__':
    unittest.main()
