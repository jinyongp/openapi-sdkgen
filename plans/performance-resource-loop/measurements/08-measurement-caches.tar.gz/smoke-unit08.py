"""One real pinned TVMaze SDK cold/warm pair under the shared cache policy."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'scripts/perf'))
from resources import POLICY_PATH, cancellation_signals, go_cache, owned_process

name = sys.argv[1] if len(sys.argv) > 1 else 'smoke'
assert name in ('smoke', 'smoke-final')
HERE = ROOT / '.tmp/perf-resource-loop/unit08' / name
HERE.mkdir(exist_ok=False)
PERF = ROOT / 'scripts/perf/sdk-optimization'


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def recorded(name, command, environment, cwd):
    metrics = HERE / f'{name}-metrics.json'
    invocation = [sys.executable, str(PERF / 'record.py'), '--output', str(HERE / name),
        '--cwd', str(cwd), '--timeout', '180', '--max-rss-mib', '3072', '--input', str(Path(__file__)),
        '--', sys.executable, str(PERF / 'compare-apis.py'), '_child', str(metrics), *map(str, command)]
    with owned_process(invocation, cwd=ROOT, env=environment) as process:
        assert process.wait() == 0
    assert json.loads((HERE / name / 'result.json').read_text())['status'] == 'pass'
    result = json.loads(metrics.read_text())
    assert result['exitCode'] == 0
    return result


def cache_size(directory):
    files = [path for path in Path(directory).rglob('*') if path.is_file()]
    return {'files': len(files), 'bytes': sum(path.stat().st_size for path in files)}


def main():
    source = ROOT / '.tmp/compatibility-holdout/APIs/tvmaze.com/1.0/openapi.yaml'
    assert sha(source) == 'd74e37b951a03b17ccd271777c0083053992f91b9c58e8681a51ca88af4eab62'
    binary = ROOT / '.tmp/perf-resource-loop/unit06/bin/openapi-sdkgen'
    module = HERE / 'module'
    module.mkdir()
    (module / 'go.mod').write_text('module example.test/graph\n\ngo 1.27.0\n')
    sdk = module / 'api'
    environment = {**os.environ, 'GOTOOLCHAIN': 'local', 'GOWORK': 'off', 'CGO_ENABLED': '0',
                   'GOMAXPROCS': '4', 'GOMEMLIMIT': '2GiB', 'GOPROXY': 'off'}
    generation = recorded('generation', [binary, 'generate', '--target', 'golang', '--with', 'server',
        '--input', source, '--output', sdk, '--go-import-path', 'example.test/graph/api'], environment, ROOT)
    inventory = json.loads((sdk / '.openapi-sdkgen-manifest.json').read_text())['files']
    expected = {row['path']: row['sha256'] for row in map(json.loads,
        (ROOT / '.tmp/perf-resource-loop/unit06/tvmaze-pair-0/candidate/phases.jsonl.files.jsonl').read_text().splitlines())}
    assert inventory == expected and all(sha(sdk / name) == digest for name, digest in inventory.items())
    save(HERE / 'inventory.json', inventory)
    command = ['go', 'build', '-mod=readonly', '-p=1', '-trimpath', '-buildvcs=false', './api/...']
    report = {'scope': 'resource-policy smoke; not a matched product speed comparison',
              'inputSha256': sha(source), 'generatorSha256': sha(binary),
              'resourcePolicySha256': sha(POLICY_PATH), 'generation': generation, 'generatedFiles': len(inventory)}
    with cancellation_signals(), go_cache(HERE, prefix='cold-warm-cache-') as cache:
        report['cachePath'] = cache
        report['beforeCold'] = cache_size(cache)
        assert report['beforeCold']['files'] == 0
        environment['GOCACHE'] = cache
        report['cold'] = recorded('cold', command, environment, module)
        report['afterCold'] = cache_size(cache)
        assert report['afterCold']['files'] > 0 and report['afterCold']['bytes'] < 1024**3
        report['warm'] = recorded('warm', command, environment, module)
        report['afterWarm'] = cache_size(cache)
    report['cacheRemoved'] = not Path(cache).exists()
    assert report['cacheRemoved']
    assert all(sha(sdk / name) == digest for name, digest in inventory.items())
    save(HERE / 'verified.json', {'status': 'pass', **report})
    shutil.rmtree(module)
    print(json.dumps({'status': 'pass', 'cacheRemoved': True, 'cacheBytes': report['afterWarm']['bytes'],
                      'coldSeconds': report['cold']['seconds'], 'warmSeconds': report['warm']['seconds']}))


if __name__ == '__main__':
    main()
