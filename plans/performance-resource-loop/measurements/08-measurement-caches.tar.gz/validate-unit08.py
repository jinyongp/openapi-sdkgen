"""Capture every explicit Python test file; discovery skips hyphenated modules."""
import hashlib
import json
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'scripts/perf'))
from resources import POLICY_PATH, owned_process

output = ROOT / '.tmp/perf-resource-loop/unit08/final-validation'
output.mkdir(exist_ok=False)
rows = []
for index, name in enumerate(['scripts/perf/resources_test.py', 'scripts/perf/golang/measure_test.py',
    'scripts/perf/sdk-optimization/compare-apis_test.py', 'scripts/perf/sdk-optimization/resume-apis_test.py',
    'scripts/perf/sdk-optimization/record_test.py', 'scripts/perf/sdk-optimization/compare-go_test.py']):
    prefix = output / f'{index:02d}'
    out_path, err_path = prefix.with_suffix('.stdout'), prefix.with_suffix('.stderr')
    with out_path.open('w') as out, err_path.open('w') as err:
        with owned_process([sys.executable, '-B', str(ROOT / name)], cwd=ROOT, stdout=out, stderr=err) as process:
            status = process.wait(timeout=150)
    count = re.search(r'Ran (\d+) tests?', err_path.read_text())
    rows.append({'test': name, 'exitCode': status, 'tests': int(count[1]) if count else None,
                 'sourceSha256': hashlib.sha256((ROOT / name).read_bytes()).hexdigest(),
                 'stdoutSha256': hashlib.sha256(out_path.read_bytes()).hexdigest(),
                 'stderrSha256': hashlib.sha256(err_path.read_bytes()).hexdigest()})
    assert status == 0 and count, rows[-1]
    print(json.dumps(rows[-1]), flush=True)
with (output / 'verified.json').open('x') as stream:
    json.dump({'status': 'pass', 'tests': sum(row['tests'] for row in rows), 'rows': rows,
               'resourcePolicySha256': hashlib.sha256(POLICY_PATH.read_bytes()).hexdigest()}, stream, indent=2)
    stream.write('\n')
