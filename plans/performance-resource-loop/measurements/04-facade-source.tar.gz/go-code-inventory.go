// Compare parsed Go declarations independently of comments and file packing.
package main

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"go/ast"
	"go/parser"
	"go/token"
	"os"
	"path"
	"path/filepath"
	"reflect"
	"sort"
	"strconv"
	"strings"
)

var positionType = reflect.TypeOf(token.NoPos)

// Keep position validity: Assign and Ellipsis encode alias/spread semantics.
// Only physical offsets, comments and parser binding cycles are omitted.
func syntax(value reflect.Value) any {
	if !value.IsValid() {
		return nil
	}
	if value.Type() == positionType {
		return value.Int() != 0
	}
	switch value.Kind() {
	case reflect.Pointer, reflect.Interface:
		if value.IsNil() {
			return nil
		}
		return syntax(value.Elem())
	case reflect.Struct:
		result := map[string]any{"$type": value.Type().String()}
		for index := 0; index < value.NumField(); index++ {
			name := value.Type().Field(index).Name
			switch name {
			case "Doc", "Comment", "Comments", "Obj", "Scope", "Unresolved":
				continue
			}
			result[name] = syntax(value.Field(index))
		}
		return result
	case reflect.Slice, reflect.Array:
		result := make([]any, value.Len())
		for index := range result {
			result[index] = syntax(value.Index(index))
		}
		return result
	case reflect.String:
		return value.String()
	case reflect.Bool:
		return value.Bool()
	case reflect.Int, reflect.Int8, reflect.Int16, reflect.Int32, reflect.Int64:
		return value.Int()
	default:
		panic(fmt.Sprintf("unexpected AST field %s", value.Type()))
	}
}

func digest(value any) string {
	data, err := json.Marshal(value)
	if err != nil {
		panic(err)
	}
	sum := sha256.Sum256(data)
	return hex.EncodeToString(sum[:])
}

func declarationDigest(declaration ast.Decl, imports map[string]string) string {
	bindings := map[string]string{}
	for alias, target := range imports {
		if alias == "." {
			bindings[alias] = target
		}
	}
	ast.Inspect(declaration, func(node ast.Node) bool {
		if selector, ok := node.(*ast.SelectorExpr); ok {
			if name, ok := selector.X.(*ast.Ident); ok && name.Obj == nil {
				if target, ok := imports[name.Name]; ok {
					bindings[name.Name] = target
				}
			}
		}
		return true
	})
	return digest(struct {
		Syntax  any
		Imports map[string]string
	}{syntax(reflect.ValueOf(declaration)), bindings})
}

type packageInventory struct {
	Declarations map[string]int  `json:"declarations"`
	Initializers []string        `json:"initializers"`
	BlankImports map[string]bool `json:"blankImports"`
}

type inventory struct {
	Packages   map[string]*packageInventory `json:"packages"`
	Directives map[string][]string          `json:"directives"`
	OtherFiles map[string]string            `json:"otherFiles"`
}

func readInventory(root string) inventory {
	manifest, err := os.ReadFile(filepath.Join(root, ".openapi-sdkgen-manifest.json"))
	if err != nil {
		panic(err)
	}
	var managed struct {
		Files map[string]string `json:"files"`
	}
	if err := json.Unmarshal(manifest, &managed); err != nil {
		panic(err)
	}
	names := make([]string, 0, len(managed.Files))
	for name := range managed.Files {
		names = append(names, name)
	}
	sort.Strings(names)
	result := inventory{map[string]*packageInventory{}, map[string][]string{}, map[string]string{}}
	for _, name := range names {
		data, err := os.ReadFile(filepath.Join(root, name))
		if err != nil {
			panic(err)
		}
		sum := sha256.Sum256(data)
		if hex.EncodeToString(sum[:]) != managed.Files[name] {
			panic("managed file digest mismatch: " + name)
		}
		if !strings.HasSuffix(name, ".go") {
			result.OtherFiles[name] = managed.Files[name]
			continue
		}
		file, err := parser.ParseFile(token.NewFileSet(), name, data, parser.ParseComments)
		if err != nil {
			panic(err)
		}
		key := path.Dir(name) + "/" + file.Name.Name
		pkg := result.Packages[key]
		if pkg == nil {
			pkg = &packageInventory{map[string]int{}, []string{}, map[string]bool{}}
			result.Packages[key] = pkg
		}
		for _, group := range file.Comments {
			for _, comment := range group.List {
				text := comment.Text
				if strings.HasPrefix(text, "//go:") || strings.HasPrefix(text, "// +build") || strings.HasPrefix(text, "//line ") || strings.HasPrefix(text, "/*line ") {
					result.Directives[name] = append(result.Directives[name], text)
				}
			}
		}
		imports := map[string]string{}
		for _, spec := range file.Imports {
			target, err := strconv.Unquote(spec.Path.Value)
			if err != nil {
				panic(err)
			}
			alias := path.Base(target)
			if spec.Name != nil {
				alias = spec.Name.Name
			}
			imports[alias] = target
			if alias == "_" {
				pkg.BlankImports[target] = true
			}
		}
		for _, declaration := range file.Decls {
			if gen, ok := declaration.(*ast.GenDecl); ok && gen.Tok == token.IMPORT {
				continue
			}
			hash := declarationDigest(declaration, imports)
			pkg.Declarations[hash]++
			if gen, ok := declaration.(*ast.GenDecl); ok && gen.Tok == token.VAR {
				pkg.Initializers = append(pkg.Initializers, hash)
			}
			if function, ok := declaration.(*ast.FuncDecl); ok && function.Recv == nil && function.Name.Name == "init" {
				pkg.Initializers = append(pkg.Initializers, hash)
			}
		}
	}
	return result
}

func fixture(source string) string {
	file, err := parser.ParseFile(token.NewFileSet(), "test.go", "package sample\n"+source, 0)
	if err != nil {
		panic(err)
	}
	return declarationDigest(file.Decls[0], map[string]string{"dep": "example.test/a"})
}

func selfTest() {
	for _, pair := range [][2]string{
		{"type Item = int", "type Item int"},
		{"func Value() int { return 1 }", "func Value() int { return 2 }"},
		{"func Value(xs []int) { use(xs) }", "func Value(xs []int) { use(xs...) }"},
		{"func Value() { dep.One() }", "func Value() { dep.Two() }"},
	} {
		if fixture(pair[0]) == fixture(pair[1]) {
			panic("missed semantic mutation")
		}
	}
	if fixture("// Value documents it.\nfunc Value() int { return 1 }") != fixture("func Value() int {\nreturn 1\n}") {
		panic("comment/position false positive")
	}
	file, _ := parser.ParseFile(token.NewFileSet(), "test.go", "package sample\nfunc Value() { dep.One() }", 0)
	if declarationDigest(file.Decls[0], map[string]string{"dep": "example.test/a"}) == declarationDigest(file.Decls[0], map[string]string{"dep": "example.test/b"}) {
		panic("missed import mutation")
	}
	a := inventory{Packages: map[string]*packageInventory{"p": {Initializers: []string{"a", "b"}}}}
	b := inventory{Packages: map[string]*packageInventory{"p": {Initializers: []string{"b", "a"}}}}
	if digest(a) == digest(b) {
		panic("missed initializer order mutation")
	}
	fmt.Println("pass: alias, literal, spread, selector, import binding, initializer order; comments and positions")
}

func main() {
	if len(os.Args) == 2 && os.Args[1] == "-self-test" {
		selfTest()
		return
	}
	if len(os.Args) != 3 {
		panic("usage: go-code-inventory ROOT OUTPUT or -self-test")
	}
	result := readInventory(os.Args[1])
	file, err := os.OpenFile(os.Args[2], os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
	if err != nil {
		panic(err)
	}
	defer file.Close()
	if err := json.NewEncoder(file).Encode(result); err != nil {
		panic(err)
	}
	count := 0
	for _, pkg := range result.Packages {
		for _, n := range pkg.Declarations {
			count += n
		}
	}
	fmt.Printf("packages=%d declarations=%d directiveFiles=%d otherFiles=%d sha256=%s\n", len(result.Packages), count, len(result.Directives), len(result.OtherFiles), digest(result))
}
