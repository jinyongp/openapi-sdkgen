"""Retain the rejected source-position candidate before changing its code."""
import hashlib
import io
import json
from pathlib import Path
import shutil
import tarfile

root = Path(__file__).resolve().parents[2]
here = root / '.tmp/perf-resource-loop'
unit = here / 'unit04'
output = unit / 'github-pair-0/candidate/api'
assert output.is_dir()
sources = [root / name for name in ('internal/target/golang/partition.go',
                                   'internal/target/golang/partition_test.go')]
files = sources + [p for p in unit.rglob('*') if p.is_file()
                   and not p.is_relative_to(output) and not p.is_relative_to(unit / 'bin')]
index = {}
destination = unit / 'original-source-prototype.tar.gz'
with tarfile.open(destination, 'x:gz') as archive:
    for path in sorted(files):
        data = path.read_bytes()
        name = str(path.relative_to(root))
        index[name] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
        info = tarfile.TarInfo(name)
        info.mode, info.size = 0o600, len(data)
        archive.addfile(info, io.BytesIO(data))
    data = json.dumps(index, indent=2).encode()
    info = tarfile.TarInfo('evidence-index.json')
    info.mode, info.size = 0o600, len(data)
    archive.addfile(info, io.BytesIO(data))
with tarfile.open(destination) as archive:
    for name, entry in index.items():
        data = archive.extractfile(name).read()
        assert len(data) == entry['bytes'] and hashlib.sha256(data).hexdigest() == entry['sha256']
shutil.rmtree(output)
previous = unit / 'original-source-prototype'
previous.mkdir()
for path in list(unit.iterdir()):
    if path not in (previous, destination):
        path.rename(previous / path.name)
print(json.dumps({'entries': len(index), 'bytes': destination.stat().st_size,
                  'sha256': hashlib.sha256(destination.read_bytes()).hexdigest()}))
