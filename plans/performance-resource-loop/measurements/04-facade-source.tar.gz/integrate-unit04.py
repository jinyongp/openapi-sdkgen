"""Check final real CLI bytes against the independently observed final SDK."""
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
PERF = ROOT / 'scripts/perf/sdk-optimization'
sys.dont_write_bytecode = True
spec = importlib.util.spec_from_file_location('inputs', PERF / 'compare-apis.py')
apis = importlib.util.module_from_spec(spec)
spec.loader.exec_module(apis)


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def main():
    provider = sys.argv[1]
    name, expected = apis.PROVIDERS[provider]
    source = ROOT / name
    assert sha(source) == expected
    case = HERE / 'unit04/cli-integration' / provider
    case.mkdir(parents=True, exist_ok=False)
    sdk, metrics = case / 'api', case / 'metrics.json'
    binary = HERE / 'unit04/bin/openapi-sdkgen'
    command = [str(binary), 'generate', '--target', 'golang', '--with', 'server', '--input', str(source),
               '--output', str(sdk), '--go-import-path', 'example.test/graph/api']
    subprocess.run([sys.executable, str(PERF / 'record.py'), '--output', str(case / 'record'),
                    '--timeout', '180', '--max-rss-mib', '3072', '--input', str(Path(__file__)), '--',
                    sys.executable, str(PERF / 'compare-apis.py'), '_child', str(metrics), *command], cwd=ROOT, check=True)
    original = HERE / f'unit04/{provider}-pair-0/candidate/phases.jsonl.files.jsonl'
    reference = {r['path']:r['sha256'] for r in map(json.loads, original.read_text().splitlines())}
    actual = json.loads((sdk / '.openapi-sdkgen-manifest.json').read_text())['files']
    assert actual == reference and all(sha(sdk / name) == digest for name, digest in actual.items())
    row = {'provider': provider, 'files': len(actual), 'referenceInventorySha256': sha(original),
           'candidateBinarySha256': sha(binary), 'actualOutputMatchesObservedCandidate': True,
           'producerSha256': sha(Path(__file__)), 'scope': 'single correctness run; not a matched performance comparison'}
    with (case / 'verified.json').open('x') as stream:
        json.dump(row, stream, indent=2)
        stream.write('\n')
    shutil.rmtree(sdk)
    print(json.dumps(row))


if __name__ == '__main__':
    main()
