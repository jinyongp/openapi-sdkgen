"""Validate the facade unit's measurements and independent complete-code comparison."""
import hashlib
import itertools
import json
import math
from pathlib import Path
import statistics

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
UNIT = HERE / 'unit04'


def load(path):
    return json.loads(path.read_text())


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def inventory(path):
    return {r['path']: (r['bytes'], r['sha256']) for r in map(json.loads, path.read_text().splitlines())}


def main():
    rows = []
    for provider, pairs in [('github', 3), ('tvmaze', 1), ('listennotes', 1)]:
        reference = load(UNIT / f'{provider}-pair-0/baseline/code.json')
        frozen = {variant: inventory(UNIT / f'{provider}-pair-0/{variant}/phases.jsonl.files.jsonl')
                  for variant in ('baseline', 'candidate')}
        if provider == 'github':
            assert frozen['baseline'] == inventory(HERE / 'unit02-baseline.jsonl.files.jsonl')
        for pair in range(pairs):
            destination = UNIT / f'{provider}-pair-{pair}'
            summary, provenance = load(destination / 'summary.json'), load(destination / 'provenance.json')
            assert summary['status'] == 'pass' and len(summary['rows']) == 2
            assert provenance['producerSha256'] == sha(HERE / 'run-facade-pair.py')
            assert provenance['analyzerSha256'] == sha(UNIT / 'bin/go-code-inventory')
            for row in summary['rows']:
                variant, child = row['variant'], destination / row['variant']
                record = load(child / 'record/result.json')
                code_record = load(child / 'code-record/result.json')
                assert row == load(child / 'verified.json')
                assert row['pair'] == pair and row['provider'] == provider and row['codeMatches']
                assert record['status'] == code_record['status'] == 'pass' and record['exitCode'] == row['exitCode'] == 0
                assert all(row[key] == value for key, value in load(child / 'metrics.json').items())
                binary = provenance['binaries'][variant]
                assert sha(Path(binary['path'])) == binary['sha256'] == record['commandFiles'][binary['path']]
                assert record['inputs'][str(HERE / 'run-facade-pair.py')] == provenance['producerSha256']
                assert code_record['inputs'][str(HERE / 'go-code-inventory.go')] == sha(HERE / 'go-code-inventory.go')
                assert code_record['commandFiles'][str(UNIT / 'bin/go-code-inventory')] == provenance['analyzerSha256']
                for directory, result in [(child / 'record', record), (child / 'code-record', code_record)]:
                    assert result['sourceManifestSha256'] == sha(directory / 'source.json')
                    assert all(sha(directory / name) == result[name + 'Sha256'] for name in ('stdout.log', 'stderr.log'))
                source = Path(record['argv'][record['argv'].index('-input') + 1])
                assert sha(source) == provenance['sourceSha256']
                phases = [json.loads(line) for line in (child / 'phases.jsonl').read_text().splitlines()]
                assert phases[-1]['phase'] == 'publish-finished' and phases[-1]['totalAllocBytes'] == row['allocatedBytes']
                actual = inventory(child / 'phases.jsonl.files.jsonl')
                assert actual == frozen[variant]
                assert len(actual) == row['files'] and sum(value[0] for value in actual.values()) == row['bytes']
                assert row['outputMatches'] == (actual == frozen['baseline'])
                assert load(child / 'code.json') == reference and sha(child / 'code.json') == row['codeSha256']
                rows.append(row)
    assert len(rows) == len({(r['provider'], r['pair'], r['variant']) for r in rows}) == 10
    baseline = load(HERE / 'unit03/typed-generator-build/source.json')
    candidate = load(UNIT / 'candidate-generator-build-2/source.json')
    runtime = {name for name in baseline if (name.startswith(('cmd/', 'internal/')) or name in ('go.mod', 'go.sum'))
               and not name.endswith('_test.go')}
    assert {name for name in runtime if baseline[name] != candidate[name]} == {'internal/target/golang/partition.go'}
    observer = 'scripts/perf/sdk-optimization/profile-go/main.go'
    assert baseline[observer] == candidate[observer] == sha(ROOT / observer)
    assert all(sha(ROOT / name) == candidate[name] for name in runtime)
    report = {'status': 'pass', 'samples': len(rows), 'rows': rows}
    for variant in ('baseline', 'candidate'):
        selected = [r for r in rows if r['provider'] == 'github' and r['variant'] == variant]
        report[variant] = {key: {'median': statistics.median(r[key] for r in selected),
                                 'min': min(r[key] for r in selected), 'max': max(r[key] for r in selected)}
                           for key in ('seconds', 'allocatedBytes', 'peakProcessRSSBytes')}
        report[variant]['medianCPUSeconds'] = statistics.median(r['userSeconds'] + r['systemSeconds'] for r in selected)
    selected = {v: sorted([r for r in rows if r['provider'] == 'github' and r['variant'] == v], key=lambda r:r['pair'])
                for v in ('baseline', 'candidate')}
    ratios = [b['seconds']/a['seconds'] for a,b in zip(selected['baseline'], selected['candidate'])]
    logs = [math.log(r) for r in ratios]
    samples = sorted(math.exp(statistics.mean(sample)) for sample in itertools.product(logs, repeat=3))
    def percentile(fraction):
        rank = (len(samples) - 1) * fraction
        low, high = math.floor(rank), math.ceil(rank)
        return samples[low] + (samples[high] - samples[low]) * (rank - low)
    report['pairedTime'] = {'ratios': ratios, 'geometricMean': math.exp(statistics.mean(logs)),
                            'bootstrapPercentile95Exact27': [percentile(.025), percentile(.975)]}
    with (UNIT / 'verification.json').open('x') as stream:
        json.dump(report, stream, indent=2)
        stream.write('\n')
    print(json.dumps({key:value for key,value in report.items() if key != 'rows'}))


if __name__ == '__main__':
    main()
