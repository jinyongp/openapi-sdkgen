"""Bounded facade comparison: preserve executable ASTs, record intentional docs changes."""
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
PERF = ROOT / 'scripts/perf/sdk-optimization'
sys.dont_write_bytecode = True
spec = importlib.util.spec_from_file_location('fixed_provider_inputs', PERF / 'compare-apis.py')
apis = importlib.util.module_from_spec(spec)
spec.loader.exec_module(apis)


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def load(path):
    return json.loads(path.read_text())


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def inventory(path):
    return {r['path']: (r['bytes'], r['sha256']) for r in map(json.loads, path.read_text().splitlines())}


def run():
    provider, pair = sys.argv[1], int(sys.argv[2])
    assert provider in apis.PROVIDERS and 0 <= pair < 3
    unit = HERE / 'unit04'
    destination = unit / f'{provider}-pair-{pair}'
    destination.mkdir(exist_ok=False)
    binaries = {'baseline': HERE / 'unit03/bin/typed/profile-go', 'candidate': unit / 'bin/profile-go'}
    analyzer = unit / 'bin/go-code-inventory'
    source = ROOT / apis.PROVIDERS[provider][0]
    assert sha(source) == apis.PROVIDERS[provider][1]
    save(destination / 'provenance.json', {'producerSha256': sha(Path(__file__)), 'sourceSha256': sha(source),
         'analyzerSha256': sha(analyzer),
         'binaries': {k: {'path': str(v), 'sha256': sha(v)} for k, v in binaries.items()}})
    code_reference = load(unit / f'{provider}-pair-0/baseline/code.json') if pair else None
    bytes_reference = inventory(HERE / 'unit02-baseline.jsonl.files.jsonl') if provider == 'github' else None
    rows, outputs = [], {}
    for variant in (['baseline', 'candidate'] if pair % 2 == 0 else ['candidate', 'baseline']):
        case = destination / variant
        case.mkdir()
        output, phases, metrics = case / 'api', case / 'phases.jsonl', case / 'metrics.json'
        command = [str(binaries[variant]), '-input', str(source), '-output', str(output), '-report', str(phases)]
        subprocess.run([sys.executable, str(PERF / 'record.py'), '--output', str(case / 'record'),
                        '--timeout', '180', '--max-rss-mib', '3072', '--input', str(Path(__file__)), '--',
                        sys.executable, str(PERF / 'compare-apis.py'), '_child', str(metrics), *command], cwd=ROOT, check=True)
        measured, recorded = load(metrics), load(case / 'record/result.json')
        assert measured['exitCode'] == 0 and recorded['status'] == 'pass'
        checkpoints = [json.loads(line) for line in phases.read_text().splitlines()]
        assert checkpoints[-1]['phase'] == 'publish-finished'
        actual = inventory(Path(str(phases) + '.files.jsonl'))
        managed = load(output / '.openapi-sdkgen-manifest.json')['files']
        assert managed == {name: value[1] for name, value in actual.items()}
        assert all(sha(output / name) == digest for name, digest in managed.items())
        subprocess.run([sys.executable, str(PERF / 'record.py'), '--output', str(case / 'code-record'),
                        '--timeout', '60', '--max-rss-mib', '3072', '--input', str(HERE / 'go-code-inventory.go'), '--',
                        str(analyzer), str(output), str(case / 'code.json')], cwd=ROOT, check=True)
        code = load(case / 'code.json')
        if code_reference is None:
            code_reference = code
        if bytes_reference is None:
            bytes_reference = actual
        assert code == code_reference, 'executable AST/import/initializer/directive/non-Go difference'
        if variant == 'baseline':
            assert actual == bytes_reference
        elif pair:
            assert actual == inventory(unit / f'{provider}-pair-0/candidate/phases.jsonl.files.jsonl')
        outputs[variant] = actual
        row = {'provider': provider, 'pair': pair, 'variant': variant, **measured,
               'allocatedBytes': checkpoints[-1]['totalAllocBytes'], 'files': len(actual),
               'bytes': checkpoints[-1]['bytes'], 'outputMatches': actual == bytes_reference,
               'codeMatches': True, 'codeSha256': sha(case / 'code.json')}
        save(case / 'verified.json', row)
        shutil.rmtree(output)
        rows.append(row)
        print(json.dumps(row), flush=True)
    a, b = outputs['baseline'], outputs['candidate']
    save(destination / 'summary.json', {'status': 'pass', 'rows': rows,
         'changedCommonPaths': sum(a[k] != b[k] for k in a.keys() & b.keys()),
         'removedPaths': len(a.keys() - b.keys()), 'addedPaths': len(b.keys() - a.keys())})


if __name__ == '__main__':
    run()
