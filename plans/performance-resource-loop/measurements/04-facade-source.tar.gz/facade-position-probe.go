package main

import (
	"bytes"
	"fmt"
	"go/ast"
	"go/format"
	"go/parser"
	"go/token"
)

func main() {
	source := []byte(`// Package models is public.
package models

// Name describes an item.
type Name struct {
	// Value is the name.
	Value string
}

// Names forwards names.
func Names(values ...Name) []Name {
	return values
}
`)
	original, err := parser.ParseFile(token.NewFileSet(), "original.go", source, parser.ParseComments)
	if err != nil {
		panic(err)
	}
	var clone bytes.Buffer
	if err := format.Node(&clone, token.NewFileSet(), original); err != nil {
		panic(err)
	}
	fmt.Printf("CLONE SOURCE:\n%s\n", clone.Bytes())
	for _, input := range []struct {
		name string
		data []byte
	}{{"old", clone.Bytes()}, {"raw", source}} {
		set := token.NewFileSet()
		file, err := parser.ParseFile(set, "facade.go", input.data, parser.ParseComments)
		if err != nil {
			panic(err)
		}
		for _, decl := range file.Decls {
			switch decl := decl.(type) {
			case *ast.GenDecl:
				if spec, ok := decl.Specs[0].(*ast.TypeSpec); ok {
					spec.Assign = 1
					spec.Type = &ast.SelectorExpr{X: ast.NewIdent("sdkgenimpl"), Sel: ast.NewIdent(spec.Name.Name)}
				}
			case *ast.FuncDecl:
				decl.Body = &ast.BlockStmt{List: []ast.Stmt{&ast.ReturnStmt{Results: []ast.Expr{&ast.CallExpr{Fun: ast.NewIdent("forward")}}}}}
			}
		}
		file.Comments = nil
		var buffer bytes.Buffer
		if err := format.Node(&buffer, set, file); err != nil {
			panic(err)
		}
		fmt.Printf("%s WITH POSITIONS:\n%s\n", input.name, buffer.Bytes())
		buffer.Reset()
		if err := format.Node(&buffer, token.NewFileSet(), file); err != nil {
			panic(err)
		}
		fmt.Printf("%s WITHOUT POSITIONS:\n%s\n", input.name, buffer.Bytes())
	}
}
