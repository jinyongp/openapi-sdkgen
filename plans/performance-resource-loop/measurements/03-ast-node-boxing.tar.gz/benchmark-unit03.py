"""Keep benchmark rows while omitting the testing package's machine CPU header."""
import subprocess
import sys

process = subprocess.Popen([sys.argv[1], '-test.run', '^$', '-test.bench', '^BenchmarkPartitionASTTransform$',
                            '-test.benchtime', '300ms', '-test.count', '5', '-test.benchmem'],
                           stdout=subprocess.PIPE, text=True)
for line in process.stdout:
    if not line.startswith('cpu: '):
        print(line, end='', flush=True)
sys.exit(process.wait())
