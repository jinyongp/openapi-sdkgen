"""Discard rejected binaries, keeping measured hashes and build provenance."""
import hashlib
import json
from pathlib import Path
import tarfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
unit = HERE / 'unit10'
assert json.loads((unit / 'final-partition-tests/result.json').read_text())['status'] == 'pass'
with tarfile.open(unit / 'baseline-source.tar') as baseline:
    assert baseline.extractfile('internal/target/golang/partition.go').read() == (ROOT / 'internal/target/golang/partition.go').read_bytes()
expected = json.loads((unit / 'github-pair-0/provenance.json').read_text())['binaries']['candidate']['sha256']
removed = []
for name in ('openapi-sdkgen', 'profile-go'):
    path = unit / 'bin' / name
    assert path.is_file() and not path.is_symlink()
    with path.open('rb') as stream:
        assert stream.read(4) == b'\x7fELF'
        stream.seek(0)
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    if name == 'profile-go':
        assert digest == expected
    removed.append({'path': str(path.relative_to(HERE)), 'bytes': path.stat().st_size, 'sha256': digest})
with (unit / 'binary-retention.json').open('x') as stream:
    json.dump({'reason': 'candidate rejected; release/current/previous binaries remain unchanged', 'removed': removed}, stream, indent=2)
    stream.write('\n')
for row in removed:
    (HERE / row['path']).unlink()
print(json.dumps({'removedFiles': len(removed), 'removedBytes': sum(row['bytes'] for row in removed),
                  'runtimeRestoredExactly': True}))
