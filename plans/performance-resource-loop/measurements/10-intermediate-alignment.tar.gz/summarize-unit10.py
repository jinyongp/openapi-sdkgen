"""Attribute intermediate serialization separately from final go/format work."""
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'scripts/perf'))
from resources import owned_process

unit = ROOT / '.tmp/perf-resource-loop/unit10'
binary = ROOT / '.tmp/perf-resource-loop/unit09/bin/profile-go'
tasks = {
    'serialization-cpu': ['-top', '-cum', '-nodecount=24', '-focus=formatPartitionFile', '-ignore=go/format.Source', binary, unit / 'cpu.pprof'],
    'serialization-allocation': ['-top', '-cum', '-sample_index=alloc_space', '-nodecount=24', '-focus=formatPartitionFile', '-ignore=go/format.Source', binary, unit / 'heap.pprof'],
    'format-cpu': ['-list=formatPartitionFile', binary, unit / 'cpu.pprof'],
    'format-allocation': ['-list=formatPartitionFile', '-sample_index=alloc_space', binary, unit / 'heap.pprof'],
}
rows = []
for name, flags in tasks.items():
    command = ['go', 'tool', 'pprof', *map(str, flags)]
    with (unit / f'{name}.txt').open('x') as out, (unit / f'{name}.stderr').open('x') as err:
        with owned_process(command, cwd=ROOT, stdout=out, stderr=err) as process:
            status = process.wait(timeout=60)
    assert status == 0
    rows.append({'name': name, 'command': command, 'exitCode': status,
                 'sha256': hashlib.sha256((unit / f'{name}.txt').read_bytes()).hexdigest()})
with (unit / 'summaries.json').open('x') as stream:
    json.dump(rows, stream, indent=2)
    stream.write('\n')
print(json.dumps({'status': 'pass', 'summaries': len(rows)}))
