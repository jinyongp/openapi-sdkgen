"""Verify the current profile against its adopted product's entire inventory."""
import hashlib
import json
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parents[2]
unit = ROOT / '.tmp/perf-resource-loop/unit10'
reference = ROOT / '.tmp/perf-resource-loop/unit09/github-pair-0/candidate/phases.jsonl.files.jsonl'


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def inventory(path):
    return {row['path']: (row['bytes'], row['sha256']) for row in map(json.loads, path.read_text().splitlines())}


assert json.loads((unit / 'profile-record/result.json').read_text())['status'] == 'pass'
assert sha(ROOT / '.tmp/compatibility-regression/github/api.github.com.2022-11-28.json') == 'd39842ee4d43d701e8a8c5483b4afa7c23218518f943dea2e42d36a3798cbdcc'
assert inventory(reference) == inventory(unit / 'phases.jsonl.files.jsonl')
actual = inventory(reference)
sdk = unit / 'api'
manifest = json.loads((sdk / '.openapi-sdkgen-manifest.json').read_text())['files']
assert manifest == {name: value[1] for name, value in actual.items()}
assert all(sha(sdk / name) == digest for name, digest in manifest.items())
metrics = json.loads((unit / 'metrics.json').read_text())
assert metrics['exitCode'] == 0
phases = list(map(json.loads, (unit / 'phases.jsonl').read_text().splitlines()))
assert phases[-1]['phase'] == 'publish-finished'
with (unit / 'profile-verified.json').open('x') as stream:
    json.dump({'status': 'pass', 'files': len(actual), 'bytes': sum(value[0] for value in actual.values()),
        'inputSha256': sha(ROOT / '.tmp/compatibility-regression/github/api.github.com.2022-11-28.json'),
        'referenceInventorySha256': sha(reference), 'metrics': metrics,
        'allocatedBytes': phases[-1]['totalAllocBytes'], 'scope': 'intrusive attribution; not a matched sample'}, stream, indent=2)
    stream.write('\n')
shutil.rmtree(sdk)
print(json.dumps({'status': 'pass', 'files': len(actual), 'sdkRemoved': True}))
