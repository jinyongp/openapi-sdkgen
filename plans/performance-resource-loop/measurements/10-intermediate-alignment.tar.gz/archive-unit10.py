"""Archive rejected alignment trials, final contracts and runtime restoration."""
import hashlib
import io
import json
from pathlib import Path
import tarfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
unit = HERE / 'unit10'
files = {Path(__file__).resolve()}
files.update(HERE / name for name in ['verify-profile-unit10.py', 'summarize-unit10.py',
    'batch-unit10.py', 'clean-unit10.py', 'run-observed-pair.py', 'verify-observed-unit.py'])
files.update(p for p in unit.rglob('*') if p.is_file())
files.update(p for p in (HERE / 'unit09/candidate-build').rglob('*') if p.is_file())
files.add(HERE / 'unit09/github-pair-0/candidate/phases.jsonl.files.jsonl')
files.update(ROOT / name for name in ['internal/target/golang/partition.go',
    'internal/target/golang/partition_format_test.go', 'internal/target/golang/partition_test.go',
    'internal/target/golang/emit.go', 'scripts/perf/resources.py',
    'scripts/perf/sdk-optimization/profile-go/main.go', 'scripts/perf/sdk-optimization/record.py',
    'scripts/perf/sdk-optimization/compare-apis.py', 'scripts/lib/redact.py',
    '.tmp/compatibility-regression/github/api.github.com.2022-11-28.json'])


def sha(data):
    return hashlib.sha256(data).hexdigest()


for name in ('profile-record', 'summary-record', 'candidate-partition-tests', 'candidate-build',
             'github-pair-0-driver', 'batch-driver', 'final-partition-tests', 'reflection-cpu', 'reflection-allocation'):
    assert json.loads((unit / name / 'result.json').read_text())['status'] == 'pass'
verification = json.loads((unit / 'verification.json').read_text())
assert verification['status'] == 'pass' and verification['samples'] == 10
candidate = json.loads((unit / 'candidate-build/source.json').read_text())
with tarfile.open(unit / 'rejected-source.tar.gz') as rejected:
    for name in ('partition.go', 'partition_format_test.go'):
        key = 'internal/target/golang/' + name
        assert sha(rejected.extractfile(key).read()) == candidate[key]
baseline = json.loads((HERE / 'unit09/candidate-build/source.json').read_text())
runtime = [name for name in baseline if name.startswith(('internal/', 'cmd/'))
           and name.endswith('.go') and not name.endswith('_test.go')]
assert all(sha((ROOT / name).read_bytes()) == baseline[name] for name in runtime)
profile = json.loads((unit / 'profile-verified.json').read_text())
assert profile['status'] == 'pass' and profile['files'] == 6377
assert profile['inputSha256'] == 'd39842ee4d43d701e8a8c5483b4afa7c23218518f943dea2e42d36a3798cbdcc'
assert not (unit / 'api').exists()
events = list(map(json.loads, (unit / 'final-partition-tests/stdout.log').read_text().splitlines()))
assert len([event for event in events if event.get('Action') == 'pass' and 'Test' in event and '/' not in event['Test']]) == 10
assert not any(event.get('Action') == 'fail' for event in events)
for path in unit.glob('*-pair-*/*/api'):
    assert not path.exists()
assert not list((unit / 'bin').glob('*'))

destination = ROOT / 'plans/performance-resource-loop/measurements/10-intermediate-alignment.tar.gz'
index, content, unique_bytes = {}, {}, 0
with tarfile.open(destination, 'x:gz') as archive:
    for path in sorted(files):
        assert not path.is_symlink()
        data = path.read_bytes()
        assert not data.startswith(b'\x7fELF')
        name = str(path.relative_to(HERE)) if path.is_relative_to(HERE) else 'source/' + str(path.relative_to(ROOT))
        digest = sha(data)
        index[name] = {'bytes': len(data), 'sha256': digest}
        member = tarfile.TarInfo(name)
        member.mode = 0o600
        if digest in content:
            member.type, member.linkname = tarfile.LNKTYPE, content[digest]
            archive.addfile(member)
        else:
            unique_bytes += len(data)
            assert unique_bytes < 64 * 1024**2
            member.size = len(data)
            archive.addfile(member, io.BytesIO(data))
            content[digest] = name
    data = json.dumps(index, indent=2).encode()
    member = tarfile.TarInfo('evidence-index.json')
    member.size, member.mode = len(data), 0o600
    archive.addfile(member, io.BytesIO(data))
with tarfile.open(destination) as archive:
    expected = json.load(archive.extractfile('evidence-index.json'))
    assert len(archive.getmembers()) == len(expected) + 1
    for name, entry in expected.items():
        data = archive.extractfile(name).read()
        assert len(data) == entry['bytes'] and sha(data) == entry['sha256']
print(json.dumps({'entries': len(index), 'uniqueUncompressedBytes': unique_bytes,
                  'bytes': destination.stat().st_size, 'sha256': sha(destination.read_bytes())}))
