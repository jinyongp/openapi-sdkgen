"""Preserve the rejected one-print source and exact noncanonical example."""
import hashlib
import io
import json
from pathlib import Path
import shutil
import tarfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
unit = HERE / 'unit05'
sdk = unit / 'github-pair-0/candidate/api'
files = {'source/partition.go': ROOT / 'internal/target/golang/partition.go',
         'source/partition_test.go': ROOT / 'internal/target/golang/partition_test.go',
         'example/state.go': sdk / 'internal/modelsimpl/p0/state.go'}
destination = unit / 'one-print-prototype.tar.gz'
index = {}
with tarfile.open(destination, 'x:gz') as archive:
    for name, path in files.items():
        data = path.read_bytes()
        index[name] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
        info = tarfile.TarInfo(name)
        info.mode, info.size = 0o600, len(data)
        archive.addfile(info, io.BytesIO(data))
    data = json.dumps(index, indent=2).encode()
    info = tarfile.TarInfo('evidence-index.json')
    info.mode, info.size = 0o600, len(data)
    archive.addfile(info, io.BytesIO(data))
with tarfile.open(destination) as archive:
    for name, entry in index.items():
        data = archive.extractfile(name).read()
        assert len(data) == entry['bytes'] and hashlib.sha256(data).hexdigest() == entry['sha256']
assert sdk.is_relative_to(unit)
shutil.rmtree(sdk)
print(json.dumps({'entries': len(index), 'bytes': destination.stat().st_size,
                  'sha256': hashlib.sha256(destination.read_bytes()).hexdigest()}))
