"""Retain a fresh profile and rejected normalization experiment."""
import hashlib
import io
import json
from pathlib import Path
import tarfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
files = {HERE / name for name in ['archive-unit05.py', 'freeze-unit05-candidate.py', 'run-observed-pair.py']}
for folder in ['unit05', 'unit04/candidate-generator-build-2']:
    for path in (HERE / folder).rglob('*'):
        if path.is_file() and path.relative_to(HERE / folder).parts[0] != 'bin': files.add(path)
for name in ['internal/target/golang/partition.go', 'internal/target/golang/partition_test.go',
             'internal/target/golang/emit.go', 'scripts/perf/sdk-optimization/profile-go/main.go',
             'scripts/perf/sdk-optimization/record.py', 'scripts/perf/sdk-optimization/compare-apis.py']:
    files.add(ROOT / name)
assert not list((HERE / 'unit05').glob('*-pair-*/*/api'))
assert not (HERE / 'unit05/profile/api').exists()
destination = ROOT / 'plans/performance-resource-loop/measurements/05-post-facade-profile.tar.gz'
index, content, unique_bytes = {}, {}, 0
with tarfile.open(destination, 'x:gz') as archive:
    for path in sorted(files):
        assert not path.is_symlink()
        data = path.read_bytes()
        if path.suffix == '.log': assert not any(line.startswith(b'cpu: ') for line in data.splitlines())
        name = str(path.relative_to(HERE)) if path.is_relative_to(HERE) else 'source/' + str(path.relative_to(ROOT))
        digest = hashlib.sha256(data).hexdigest()
        index[name] = {'bytes': len(data), 'sha256': digest}
        member = tarfile.TarInfo(name)
        member.mode = 0o600
        if digest in content:
            member.type, member.linkname = tarfile.LNKTYPE, content[digest]
            archive.addfile(member)
        else:
            unique_bytes += len(data)
            assert unique_bytes < 64 * 1024**2
            member.size = len(data)
            archive.addfile(member, io.BytesIO(data))
            content[digest] = name
    data = json.dumps(index, indent=2).encode()
    member = tarfile.TarInfo('evidence-index.json')
    member.size, member.mode = len(data), 0o600
    archive.addfile(member, io.BytesIO(data))
with tarfile.open(destination) as archive:
    expected = json.load(archive.extractfile('evidence-index.json'))
    assert len(archive.getmembers()) == len(expected) + 1
    for name, entry in expected.items():
        data = archive.extractfile(name).read()
        assert len(data) == entry['bytes'] and hashlib.sha256(data).hexdigest() == entry['sha256']
print(json.dumps({'entries': len(index), 'uniqueUncompressedBytes': unique_bytes,
                  'bytes': destination.stat().st_size,
                  'sha256': hashlib.sha256(destination.read_bytes()).hexdigest()}))
