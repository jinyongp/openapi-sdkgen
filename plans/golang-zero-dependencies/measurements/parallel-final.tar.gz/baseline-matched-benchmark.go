package api_test

import (
	"context"
	"example.test/goperf/api/internal/schema"
	"fmt"
	"runtime"
	"testing"
)

func BenchmarkRegexConcurrent(b *testing.B) {
	for _, sample := range []struct{ name, pattern, input string }{{"ascii", "^[a-z]+$", "sdkgen"}, {"capture", `(?i:^(?<word>\p{L}+)-\k<word>$)`, "Go-go"}} {
		pattern, err := schema.PreparePattern(sample.pattern)
		if err != nil {
			b.Fatal(err)
		}
		for _, workers := range []int{1, 8, 64} {
			b.Run(fmt.Sprintf("%s/workers%d", sample.name, workers), func(b *testing.B) {
				previous := runtime.GOMAXPROCS(workers)
				defer runtime.GOMAXPROCS(previous)
				b.ReportAllocs()
				ctx := context.Background()
				b.RunParallel(func(pb *testing.PB) {
					for pb.Next() {
						if ok, err := pattern.Match(ctx, sample.input); err != nil || !ok {
							b.Error(ok, err)
							return
						}
					}
				})
			})
		}
	}
}
