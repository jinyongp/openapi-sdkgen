import json,subprocess,time
from pathlib import Path
args=['devtools','run','test:dev','-count=1','-timeout=20m','-run','^TestRuntimeFeature(Native|Declaration)MatrixRegression$'];log=Path('/tmp/sdkgen-zero/w11-typescript-matrices.log');start=time.monotonic();commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
with log.open('w') as f:r=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT)
Path('/tmp/sdkgen-zero/w11-typescript-matrices.json').write_text(json.dumps({'argv':args,'exitCode':r.returncode,'wallSeconds':time.monotonic()-start,'commit':commit,'log':str(log),'scope':'Fresh native/declaration TypeScript matrices after shared matcher optimizations; no matrix result inferred from older runs.'},indent=2)+'\n');print('TypeScript native/declaration matrices',r.returncode,flush=True);raise SystemExit(r.returncode)
